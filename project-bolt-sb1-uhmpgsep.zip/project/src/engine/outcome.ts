// Outcome engine: tracks each setup through its lifecycle after EXECUTE.
// Detects entry trigger, TP1/TP2/TP3, SL, breakeven, expiry, invalidation.
// Computes MFE, MAE, R realized, duration, spread at entry/exit.
// Uses correct Ask/Bid for realistic execution simulation.

import { Candle, Tick, SetupState, JournalEntry, Direction, LiquidityPool, MacroEvent } from './types';

export interface OutcomeConfig {
  slippagePips: number; // additional slippage in price units
  tp1Pct: number; // fraction of position closed at TP1 (0-1)
  tp2Pct: number;
  tp3Pct: number;
  moveToBreakevenAtTp1: boolean;
  expiryMs: number; // max time to hold
  sameBarRule: 'tp_first' | 'sl_first' | 'conservative_sl';
  pipSize: number;
}

export const DEFAULT_OUTCOME_CONFIG: OutcomeConfig = {
  slippagePips: 0.05,
  tp1Pct: 0.34,
  tp2Pct: 0.33,
  tp3Pct: 0.33,
  moveToBreakevenAtTp1: true,
  expiryMs: 24 * 3600 * 1000,
  sameBarRule: 'conservative_sl',
  pipSize: 0.01,
};

export interface OutcomeResult {
  setupId: string;
  status: 'pending' | 'entry_triggered' | 'tp1_hit' | 'tp2_hit' | 'tp3_hit' | 'sl_hit' | 'breakeven' | 'expired' | 'invalidated' | 'closed';
  direction: Direction;
  entryPrice: number | null;
  entryTime: number | null;
  exitPrice: number | null;
  exitTime: number | null;
  spreadAtEntry: number | null;
  spreadAtExit: number | null;
  mfe: number | null; // in R
  mae: number | null; // in R
  rRealized: number | null;
  duration: number | null;
  tp1Hit: boolean;
  tp2Hit: boolean;
  tp3Hit: boolean;
  slHit: boolean;
  breakevenHit: boolean;
  outcome: JournalEntry['outcome'];
  reason: string;
}

export function createOutcome(setupId: string, direction: Direction): OutcomeResult {
  return {
    setupId,
    status: 'pending',
    direction,
    entryPrice: null,
    entryTime: null,
    exitPrice: null,
    exitTime: null,
    spreadAtEntry: null,
    spreadAtExit: null,
    mfe: null,
    mae: null,
    rRealized: null,
    duration: null,
    tp1Hit: false,
    tp2Hit: false,
    tp3Hit: false,
    slHit: false,
    breakevenHit: false,
    outcome: 'pending',
    reason: '',
  };
}

// Process a single candle/tick to update the outcome
export function processOutcome(
  outcome: OutcomeResult,
  setup: SetupState,
  candle: Candle,
  tick: Tick | null,
  config: OutcomeConfig,
  currentTime: number,
): OutcomeResult {
  if (outcome.status === 'closed' || outcome.status === 'expired' || outcome.status === 'invalidated') {
    return outcome;
  }

  const direction = setup.direction;
  const entryMin = setup.entryZoneMin;
  const entryMax = setup.entryZoneMax;
  const sl = setup.stopLoss;
  const targets = setup.targets;
  const risk = Math.abs(setup.preferredEntry - sl);
  if (risk <= 0) return outcome;

  // For BUY: entry uses Ask, exit uses Bid
  // For SELL: entry uses Bid, exit uses Ask
  const bid = tick?.bid ?? candle.close;
  const ask = tick?.ask ?? candle.close;
  const spread = tick?.spread ?? ask - bid;

  // ─── Entry detection ──────────────────────────────────
  if (outcome.status === 'pending') {
    if (direction > 0) {
      // BUY: price needs to drop into entry zone (ask within zone)
      if (ask <= entryMax && ask >= entryMin) {
        const entryPrice = ask + config.slippagePips;
        return {
          ...outcome,
          status: 'entry_triggered',
          entryPrice: Math.round(entryPrice * 100) / 100,
          entryTime: currentTime,
          spreadAtEntry: Math.round(spread * 100) / 100,
        };
      }
    } else if (direction < 0) {
      // SELL: price needs to rise into entry zone (bid within zone)
      if (bid >= entryMin && bid <= entryMax) {
        const entryPrice = bid - config.slippagePips;
        return {
          ...outcome,
          status: 'entry_triggered',
          entryPrice: Math.round(entryPrice * 100) / 100,
          entryTime: currentTime,
          spreadAtEntry: Math.round(spread * 100) / 100,
        };
      }
    }
    // Check expiry
    if (currentTime - setup.createdAt > config.expiryMs) {
      return { ...outcome, status: 'expired', outcome: 'expired', reason: 'Entry not triggered within expiry window', exitTime: currentTime };
    }
    return outcome;
  }

  // ─── Post-entry: track TP/SL/MFE/MAE ──────────────────
  if (outcome.entryPrice === null) return outcome;
  const entry = outcome.entryPrice;

  // Compute MFE/MAE in R
  let mfe = outcome.mfe ?? 0;
  let mae = outcome.mae ?? 0;

  if (direction > 0) {
    // BUY: favorable = price goes up, adverse = price goes down
    const favorable = (candle.high - entry) / risk;
    const adverse = (entry - candle.low) / risk;
    mfe = Math.max(mfe, Math.round(favorable * 100) / 100);
    mae = Math.min(mae ?? 0, Math.round(adverse * 100) / 100);
    // MAE should be positive (adverse = losing)
    mae = Math.round(Math.abs(mae) * 100) / 100;
  } else {
    // SELL: favorable = price goes down, adverse = price goes up
    const favorable = (entry - candle.low) / risk;
    const adverse = (candle.high - entry) / risk;
    mfe = Math.max(mfe, Math.round(favorable * 100) / 100);
    mae = Math.max(mae ?? 0, Math.round(adverse * 100) / 100);
  }

  // Check TP/SL hits in this candle
  // For BUY: TP hit when Bid >= target, SL hit when Bid <= SL
  // For SELL: TP hit when Ask <= target, SL hit when Ask >= SL
  let tp1Hit = outcome.tp1Hit;
  let tp2Hit = outcome.tp2Hit;
  let tp3Hit = outcome.tp3Hit;
  let slHit = outcome.slHit;
  let breakevenHit = outcome.breakevenHit;
  let newStatus = outcome.status;

  if (direction > 0) {
    if (targets[0] && bid >= targets[0]) tp1Hit = true;
    if (targets[1] && bid >= targets[1]) tp2Hit = true;
    if (targets[2] && bid >= targets[2]) tp3Hit = true;
    if (bid <= sl) slHit = true;
    // Breakeven: if TP1 hit and moved to BE, check if price hit entry
    if (tp1Hit && config.moveToBreakevenAtTp1 && bid <= entry) breakevenHit = true;
  } else {
    if (targets[0] && ask <= targets[0]) tp1Hit = true;
    if (targets[1] && ask <= targets[1]) tp2Hit = true;
    if (targets[2] && ask <= targets[2]) tp3Hit = true;
    if (ask >= sl) slHit = true;
    if (tp1Hit && config.moveToBreakevenAtTp1 && ask >= entry) breakevenHit = true;
  }

  // Same-bar TP+SL rule
  if (slHit && (tp1Hit || tp2Hit || tp3Hit)) {
    // Conservative: assume SL hit first (worst case)
    if (config.sameBarRule === 'conservative_sl' || config.sameBarRule === 'sl_first') {
      slHit = true;
      tp1Hit = false;
      tp2Hit = false;
      tp3Hit = false;
    }
    // tp_first: assume TP hit first
    // In tick mode, we'd use actual tick order — here we use candle order
  }

  // Determine final status
  let exitPrice: number | null = outcome.exitPrice;
  let exitTime: number | null = outcome.exitTime;
  let spreadAtExit: number | null = outcome.spreadAtExit;
  let rRealized: number | null = outcome.rRealized;
  let finalOutcome: JournalEntry['outcome'] = outcome.outcome;
  let reason = outcome.reason;

  if (slHit && !outcome.slHit) {
    newStatus = 'sl_hit';
    exitPrice = direction > 0 ? sl - config.slippagePips : sl + config.slippagePips;
    exitTime = currentTime;
    spreadAtExit = spread;
    rRealized = direction > 0
      ? Math.round(((exitPrice - entry) / risk) * 100) / 100
      : Math.round(((entry - exitPrice) / risk) * 100) / 100;
    finalOutcome = 'sl';
    reason = 'Stop loss hit';
  } else if (tp3Hit && !outcome.tp3Hit) {
    newStatus = 'tp3_hit';
    exitPrice = direction > 0 ? targets[2] : targets[2];
    exitTime = currentTime;
    spreadAtExit = spread;
    rRealized = direction > 0
      ? Math.round(((targets[2] - entry) / risk) * 100) / 100
      : Math.round(((entry - targets[2]) / risk) * 100) / 100;
    finalOutcome = 'tp3';
    reason = 'TP3 hit';
  } else if (tp2Hit && !outcome.tp2Hit) {
    newStatus = 'tp2_hit';
    if (!tp3Hit) {
      // Partial close at TP2 — keep tracking for TP3
      // For simplicity, mark as closed at TP2 if no TP3 yet
      // In a real system this would track partial positions
    }
  } else if (tp1Hit && !outcome.tp1Hit) {
    newStatus = 'tp1_hit';
    // Continue tracking for TP2/TP3
    if (config.moveToBreakevenAtTp1) {
      breakevenHit = true;
    }
  }

  // Check if fully closed
  if (newStatus === 'sl_hit' || newStatus === 'tp3_hit' || (newStatus === 'tp2_hit' && !targets[2])) {
    newStatus = 'closed';
  }

  // Check expiry
  if (currentTime - (outcome.entryTime ?? setup.createdAt) > config.expiryMs && newStatus !== 'closed') {
    newStatus = 'expired';
    exitPrice = direction > 0 ? bid : ask;
    exitTime = currentTime;
    spreadAtExit = spread;
    rRealized = direction > 0
      ? Math.round(((exitPrice - entry) / risk) * 100) / 100
      : Math.round(((entry - exitPrice) / risk) * 100) / 100;
    finalOutcome = 'expired';
    reason = 'Setup expired before all targets hit';
  }

  const duration = outcome.entryTime !== null ? currentTime - outcome.entryTime : null;

  return {
    ...outcome,
    status: newStatus,
    mfe,
    mae,
    tp1Hit,
    tp2Hit,
    tp3Hit,
    slHit,
    breakevenHit,
    exitPrice: exitPrice !== null ? Math.round(exitPrice * 100) / 100 : null,
    exitTime,
    spreadAtExit,
    rRealized,
    duration,
    outcome: finalOutcome,
    reason,
  };
}

// Batch process outcome over a series of candles (for backtest)
export function runOutcomeSimulation(
  setup: SetupState,
  candles: Candle[],
  ticks: Tick[] | null,
  config: OutcomeConfig,
  startTime: number,
): OutcomeResult {
  let outcome = createOutcome(setup.setupId, setup.direction);

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (c.time < startTime) continue;
    const tick = ticks && ticks.length > 0 ? ticks[Math.min(i, ticks.length - 1)] : null;
    outcome = processOutcome(outcome, setup, c, tick, config, c.time);
    if (outcome.status === 'closed' || outcome.status === 'expired' || outcome.status === 'invalidated') break;
  }

  return outcome;
}
