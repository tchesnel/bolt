// Backtest / market replay engine.
// Uses EXACTLY the same pipeline as live — no special backtest logic.
// Walks chronologically through historical candles, never accessing future data.

import { Candle, Timeframe, TF_MINUTES, MarketSnapshot, SetupState, EngineMode } from './types';
import { runPipeline, createPipelineState } from './pipeline';
import { PriceState, FeedState } from './types';
import { createFeedState, dataOfflinePriceState, computePriceState } from './market';
import { mulberry32 } from './market';
import { OutcomeResult, runOutcomeSimulation, DEFAULT_OUTCOME_CONFIG, OutcomeConfig } from './outcome';
import { planToJournal } from './decision';
import { JournalEntry } from './types';

export interface BacktestConfig {
  candles: Record<Timeframe, Candle[]>;
  startTime: number;
  endTime: number;
  stepMs: number; // how often to evaluate (e.g., 60000 for M1 steps)
  mode: EngineMode;
  outcomeConfig?: OutcomeConfig;
}

export interface BacktestResult {
  setups: SetupState[];
  outcomes: OutcomeResult[];
  journals: JournalEntry[];
  metrics: BacktestMetrics;
  snapshots: MarketSnapshot[];
}

export interface BacktestMetrics {
  totalSetups: number;
  totalTrades: number;
  winRate: number;
  tp1Rate: number;
  tp2Rate: number;
  tp3Rate: number;
  slRate: number;
  expiredRate: number;
  averageR: number;
  expectancy: number;
  profitFactor: number;
  maxDrawdown: number;
  avgMFE: number;
  avgMAE: number;
  avgDuration: number;
  // Breakdowns
  byDirection: { buy: BacktestMetricsBreakdown; sell: BacktestMetricsBreakdown };
  bySession: Record<string, BacktestMetricsBreakdown>;
  bySetupType: Record<string, BacktestMetricsBreakdown>;
}

export interface BacktestMetricsBreakdown {
  count: number;
  wins: number;
  losses: number;
  totalR: number;
  winRate: number;
  avgR: number;
}

function sliceCandles(candles: Candle[], endTime: number): Candle[] {
  return candles.filter((c) => c.time <= endTime);
}

export function runBacktest(config: BacktestConfig): BacktestResult {
  const pipelineState = createPipelineState(config.mode);
  const setups: SetupState[] = [];
  const outcomes: OutcomeResult[] = [];
  const journals: JournalEntry[] = [];
  const snapshots: MarketSnapshot[] = [];

  const feed = createFeedState(config.mode, 'BACKTEST', 'XAUUSD', 5000);
  const rng = mulberry32(42);

  // Walk through time chronologically
  for (let t = config.startTime; t <= config.endTime; t += config.stepMs) {
    // Slice candles up to current time — NEVER access future data
    const slicedCandles: Record<Timeframe, Candle[]> = {} as Record<Timeframe, Candle[]>;
    for (const tf of Object.keys(config.candles) as Timeframe[]) {
      slicedCandles[tf] = sliceCandles(config.candles[tf], t);
    }

    // Create a price state from the most recent candle
    const lastH1 = slicedCandles.H1?.[slicedCandles.H1.length - 1];
    let price: PriceState;
    if (lastH1) {
      const bid = lastH1.close - 0.1;
      const ask = lastH1.close + 0.1;
      price = {
        median: lastH1.close,
        bestBid: bid,
        bestAsk: ask,
        spread: 0.2,
        maxDivergence: 0,
        quality: 100,
        stale: false,
        quotes: [],
        time: t,
        feed: { ...feed, status: 'CONNECTED', lastTickAt: t },
        lastTick: { time: t, bid, ask, mid: lastH1.close, spread: 0.2, volume: lastH1.volume, last: lastH1.close },
      };
    } else {
      price = dataOfflinePriceState(feed, t);
    }

    const snapshot = runPipeline(slicedCandles, price, t, pipelineState);
    snapshots.push(snapshot);

    // Track setups that reach EXECUTE
    if (snapshot.setup && snapshot.setup.status === 'EXECUTE') {
      const existing = setups.find((s) => s.setupId === snapshot.setup!.setupId);
      if (!existing) {
        setups.push({ ...snapshot.setup });
        // Run outcome simulation from this point forward
        const futureCandles = slicedCandles.M1 ?? [];
        const outcome = runOutcomeSimulation(
          snapshot.setup,
          futureCandles,
          null,
          config.outcomeConfig ?? DEFAULT_OUTCOME_CONFIG,
          t,
        );
        outcomes.push(outcome);
        journals.push(planToJournal(snapshot.plan));
      }
    }
  }

  const metrics = computeBacktestMetrics(setups, outcomes, journals);
  return { setups, outcomes, journals, metrics, snapshots };
}

function computeBacktestMetrics(
  setups: SetupState[],
  outcomes: OutcomeResult[],
  journals: JournalEntry[],
): BacktestMetrics {
  const trades = outcomes.filter((o) => o.entryPrice !== null);
  const totalTrades = trades.length;
  const wins = trades.filter((o) => (o.outcome === 'tp1' || o.outcome === 'tp2' || o.outcome === 'tp3' || o.outcome === 'breakeven'));
  const losses = trades.filter((o) => o.outcome === 'sl');
  const expired = trades.filter((o) => o.outcome === 'expired');
  const tp1 = trades.filter((o) => o.tp1Hit);
  const tp2 = trades.filter((o) => o.tp2Hit);
  const tp3 = trades.filter((o) => o.tp3Hit);
  const sl = trades.filter((o) => o.slHit);

  const totalR = trades.reduce((s, o) => s + (o.rRealized ?? 0), 0);
  const grossProfit = wins.reduce((s, o) => s + Math.max(0, o.rRealized ?? 0), 0);
  const grossLoss = Math.abs(losses.reduce((s, o) => s + Math.min(0, o.rRealized ?? 0), 0));

  // Max drawdown (simplified — based on R sequence)
  let peak = 0, cumulative = 0, maxDD = 0;
  for (const o of trades) {
    cumulative += o.rRealized ?? 0;
    peak = Math.max(peak, cumulative);
    maxDD = Math.max(maxDD, peak - cumulative);
  }

  const avgMFE = trades.length > 0 ? trades.reduce((s, o) => s + (o.mfe ?? 0), 0) / trades.length : 0;
  const avgMAE = trades.length > 0 ? trades.reduce((s, o) => s + (o.mae ?? 0), 0) / trades.length : 0;
  const avgDuration = trades.length > 0 ? trades.reduce((s, o) => s + (o.duration ?? 0), 0) / trades.length : 0;

  const emptyBreakdown: BacktestMetricsBreakdown = { count: 0, wins: 0, losses: 0, totalR: 0, winRate: 0, avgR: 0 };
  const buyTrades = trades.filter((o) => o.direction > 0);
  const sellTrades = trades.filter((o) => o.direction < 0);

  const makeBreakdown = (tradeList: OutcomeResult[]): BacktestMetricsBreakdown => {
    if (tradeList.length === 0) return { ...emptyBreakdown };
    const w = tradeList.filter((o) => (o.outcome === 'tp1' || o.outcome === 'tp2' || o.outcome === 'tp3' || o.outcome === 'breakeven'));
    const l = tradeList.filter((o) => o.outcome === 'sl');
    const tR = tradeList.reduce((s, o) => s + (o.rRealized ?? 0), 0);
    return {
      count: tradeList.length,
      wins: w.length,
      losses: l.length,
      totalR: tR,
      winRate: Math.round((w.length / tradeList.length) * 100) / 100,
      avgR: Math.round((tR / tradeList.length) * 100) / 100,
    };
  };

  return {
    totalSetups: setups.length,
    totalTrades,
    winRate: totalTrades > 0 ? Math.round((wins.length / totalTrades) * 100) / 100 : 0,
    tp1Rate: totalTrades > 0 ? Math.round((tp1.length / totalTrades) * 100) / 100 : 0,
    tp2Rate: totalTrades > 0 ? Math.round((tp2.length / totalTrades) * 100) / 100 : 0,
    tp3Rate: totalTrades > 0 ? Math.round((tp3.length / totalTrades) * 100) / 100 : 0,
    slRate: totalTrades > 0 ? Math.round((sl.length / totalTrades) * 100) / 100 : 0,
    expiredRate: totalTrades > 0 ? Math.round((expired.length / totalTrades) * 100) / 100 : 0,
    averageR: totalTrades > 0 ? Math.round((totalR / totalTrades) * 100) / 100 : 0,
    expectancy: totalTrades > 0 ? Math.round((totalR / totalTrades) * 100) / 100 : 0,
    profitFactor: grossLoss > 0 ? Math.round((grossProfit / grossLoss) * 100) / 100 : grossProfit > 0 ? 99 : 0,
    maxDrawdown: Math.round(maxDD * 100) / 100,
    avgMFE: Math.round(avgMFE * 100) / 100,
    avgMAE: Math.round(avgMAE * 100) / 100,
    avgDuration: Math.round(avgDuration / 60000), // in minutes
    byDirection: {
      buy: makeBreakdown(buyTrades),
      sell: makeBreakdown(sellTrades),
    },
    bySession: {},
    bySetupType: {},
  };
}

// ─── Walk-forward ───────────────────────────────────────────────
// Split data into train / validation / out-of-sample periods.
// Never train and test on the same period.

export interface WalkForwardConfig {
  candles: Record<Timeframe, Candle[]>;
  totalStartTime: number;
  totalEndTime: number;
  trainPct: number; // 0-1, fraction of data for training
  validationPct: number; // 0-1, fraction for validation
  mode: EngineMode;
}

export interface WalkForwardResult {
  trainMetrics: BacktestMetrics;
  validationMetrics: BacktestMetrics;
  oosMetrics: BacktestMetrics;
  calibration: CalibrationResult;
}

export interface CalibrationResult {
  predictedProb: number[];
  observedHitRate: number[];
  sampleSize: number[];
  brierScore: number;
  buckets: { range: string; predicted: number; observed: number; count: number }[];
}

export function runWalkForward(config: WalkForwardConfig): WalkForwardResult {
  const totalDuration = config.totalEndTime - config.totalStartTime;
  const trainEnd = config.totalStartTime + totalDuration * config.trainPct;
  const valEnd = trainEnd + totalDuration * config.validationPct;

  // Train
  const trainResult = runBacktest({
    candles: config.candles,
    startTime: config.totalStartTime,
    endTime: trainEnd,
    stepMs: 60000,
    mode: config.mode,
  });

  // Validation
  const valResult = runBacktest({
    candles: config.candles,
    startTime: trainEnd,
    endTime: valEnd,
    stepMs: 60000,
    mode: config.mode,
  });

  // Out-of-sample
  const oosResult = runBacktest({
    candles: config.candles,
    startTime: valEnd,
    endTime: config.totalEndTime,
    stepMs: 60000,
    mode: config.mode,
  });

  // Calibration
  const calibration = computeCalibration(trainResult, valResult);

  return {
    trainMetrics: trainResult.metrics,
    validationMetrics: valResult.metrics,
    oosMetrics: oosResult.metrics,
    calibration,
  };
}

function computeCalibration(train: BacktestResult, val: BacktestResult): CalibrationResult {
  // Bucket predictions by confidence and compare with observed hit rates
  const buckets = [
    { range: '0-20%', min: 0, max: 0.2 },
    { range: '20-40%', min: 0.2, max: 0.4 },
    { range: '40-60%', min: 0.4, max: 0.6 },
    { range: '60-80%', min: 0.6, max: 0.8 },
    { range: '80-100%', min: 0.8, max: 1.0 },
  ];

  const predicted: number[] = [];
  const observed: number[] = [];
  const sampleSize: number[] = [];
  const bucketResults: { range: string; predicted: number; observed: number; count: number }[] = [];

  // Use journals from validation as the test set
  const allJournals = [...train.journals, ...val.journals];
  for (const bucket of buckets) {
    const inBucket = allJournals.filter((j) => j.confidence >= bucket.min && j.confidence < bucket.max);
    const wins = inBucket.filter((j) => j.outcome === 'tp1' || j.outcome === 'tp2' || j.outcome === 'tp3' || j.outcome === 'breakeven');
    const avgPredicted = inBucket.length > 0 ? inBucket.reduce((s, j) => s + j.confidence, 0) / inBucket.length : 0;
    const observedRate = inBucket.length > 0 ? wins.length / inBucket.length : 0;
    predicted.push(Math.round(avgPredicted * 100) / 100);
    observed.push(Math.round(observedRate * 100) / 100);
    sampleSize.push(inBucket.length);
    bucketResults.push({ range: bucket.range, predicted: Math.round(avgPredicted * 100) / 100, observed: Math.round(observedRate * 100) / 100, count: inBucket.length });
  }

  // Brier score
  let brierSum = 0, brierCount = 0;
  for (const j of allJournals) {
    const actual = (j.outcome === 'tp1' || j.outcome === 'tp2' || j.outcome === 'tp3' || j.outcome === 'breakeven') ? 1 : 0;
    brierSum += (j.confidence - actual) ** 2;
    brierCount++;
  }
  const brierScore = brierCount > 0 ? Math.round((brierSum / brierCount) * 10000) / 10000 : 0;

  return { predictedProb: predicted, observedHitRate: observed, sampleSize, brierScore, buckets: bucketResults };
}
