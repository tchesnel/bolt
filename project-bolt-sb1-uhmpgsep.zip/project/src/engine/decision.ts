// Decision engine: setup state machine, structural entry/SL/TP,
// agent fusion (contextual only — not the trigger for EXECUTE),
// scenarios, conflicts, alerts.

import {
  Candle, MarketSnapshot, AgentSignal, Scenario, TradePlan, Regime, AlertItem,
  StructureState, MicrostructureState, CorrelationState, OptionsState,
  MacroEvent, NewsItem, GeoEvent, LiquidityPool, Timeframe, Direction,
  JournalEntry, SetupState, SetupStage, SetupStep, SetupStatus,
  FVG, OrderBlock, BreakerBlock, IFVG, StructureEvent, SessionInfo,
  QualityReport,
} from './types';
import { atr } from './indicators';
import { SetupState as SetupStateType } from './types';
import {
  generateSetupId, createSetup, advanceStage, invalidateSetup, isSameSetup,
  setupProgressSteps,
} from './setup';

interface AgentInput {
  regime: Regime;
  structure: Record<Timeframe, StructureState>;
  micro: MicrostructureState;
  correlations: CorrelationState;
  options: OptionsState;
  macro: MacroEvent[];
  news: NewsItem[];
  geo: GeoEvent[];
  price: number;
  candles: Record<Timeframe, Candle[]>;
  sessions: SessionInfo;
  quality: QualityReport;
}

function regimeWeights(regime: Regime): Record<string, number> {
  switch (regime) {
    case 'TREND_UP':
    case 'TREND_DOWN':
      return { structure: 0.3, micro: 0.25, correlations: 0.15, liquidity: 0.1, options: 0.1, macro: 0.05, geo: 0.05 };
    case 'RANGE_BALANCED':
    case 'RANGE_EXPANDING':
      return { structure: 0.2, liquidity: 0.25, volume: 0.2, micro: 0.15, correlations: 0.1, macro: 0.05, geo: 0.05 };
    case 'BREAKOUT':
      return { micro: 0.3, structure: 0.2, volume: 0.2, options: 0.15, correlations: 0.1, macro: 0.05 };
    case 'EVENT_DRIVEN':
    case 'HIGH_VOLATILITY':
      return { macro: 0.3, micro: 0.25, correlations: 0.15, structure: 0.15, options: 0.1, geo: 0.05 };
    case 'MEAN_REVERSION':
      return { volume: 0.25, liquidity: 0.25, structure: 0.2, micro: 0.15, correlations: 0.1, macro: 0.05 };
    case 'RISK_OFF':
      return { geo: 0.3, macro: 0.25, correlations: 0.2, structure: 0.15, micro: 0.1 };
    default:
      return { structure: 0.2, micro: 0.2, correlations: 0.15, liquidity: 0.15, options: 0.1, macro: 0.1, geo: 0.1 };
  }
}

function structureAgent(s: StructureState, price: number): AgentSignal {
  const bias = s.bias;
  const dir: Direction = bias === 'bullish' ? 1 : bias === 'bearish' ? -1 : 0;
  const lastEvent = s.lastEvent;
  const conf = lastEvent?.confirmed ? 0.8 : 0.5;
  const note = lastEvent ? `${lastEvent.type} ${lastEvent.direction} @ ${lastEvent.level}` : `${bias} structure`;
  return {
    agent: 'Structure', direction: dir, confidence: conf,
    dataQuality: 0.9, freshness: 0.95, regimeCompat: 0.8, weight: 0,
    note, raw: 0, available: true,
  };
}

function microAgent(m: MicrostructureState): AgentSignal {
  let dir: Direction = 0;
  let conf = 0.4;
  let note = 'Neutral order flow';
  let available = true;

  if (!m.ofiAvailable && !m.cvdAvailable) {
    return {
      agent: 'Microstructure', direction: 0, confidence: 0.15,
      dataQuality: 0.1, freshness: 0.1, regimeCompat: 0.3, weight: 0,
      note: 'Volume data not available — microstructure agent disabled', raw: 0, available: false,
    };
  }

  if (m.absorption) {
    dir = m.absorption.side === 'buyer' ? 1 : -1;
    conf = m.absorption.confidence;
    note = `Absorption ${m.absorption.side} @ ${m.absorption.zone[0]}-${m.absorption.zone[1]}`;
  } else if (m.sweep) {
    dir = m.sweep.side === 'buyer' ? 1 : -1;
    conf = 0.72;
    note = `Sweep ${m.sweep.side} @ ${m.sweep.level}`;
  } else if (m.exhaustion) {
    dir = m.exhaustion.side === 'buyer' ? -1 : 1;
    conf = m.exhaustion.confidence;
    note = `Exhaustion ${m.exhaustion.side} @ ${m.exhaustion.level}`;
  } else if (m.divergence !== 'none') {
    dir = m.divergence === 'bullish' ? 1 : -1;
    conf = 0.55;
    note = `CVD divergence ${m.divergence}`;
  } else {
    dir = m.ofi > 0.15 ? 1 : m.ofi < -0.15 ? -1 : 0;
    conf = 0.45;
    note = `OFI ${m.ofi}, CVD ${m.cvdTrend}`;
  }

  return {
    agent: 'Microstructure', direction: dir, confidence: conf,
    dataQuality: 0.85, freshness: 1.0, regimeCompat: 0.75, weight: 0,
    note, raw: 0, available,
  };
}

function correlationAgent(c: CorrelationState): AgentSignal {
  if (!c.available) {
    return {
      agent: 'Correlations', direction: 0, confidence: 0.15,
      dataQuality: 0.1, freshness: 0.1, regimeCompat: 0.3, weight: 0,
      note: 'External feeds not connected — correlation signal disabled', raw: 0, available: false,
    };
  }
  let dir: Direction = 0;
  let conf = 0.4;
  let note = `DXY ${c.dxy}, RealYields ${c.realYields10y}`;
  if (c.dxy < -0.6 && c.realYields10y < -0.5) {
    dir = 1; conf = 0.65;
    note = 'DXY & real yields both supportive of gold';
  } else if (c.dxy > -0.4 && c.realYields10y > -0.3) {
    dir = -1; conf = 0.6;
    note = 'DXY & real yields both headwind for gold';
  }
  if (c.broken) { conf *= 0.6; note += ' (correlation regime break)'; }
  return {
    agent: 'Correlations', direction: dir, confidence: conf,
    dataQuality: 0.8, freshness: 0.9, regimeCompat: 0.7, weight: 0,
    note, raw: 0, available: true,
  };
}

function optionsAgent(o: OptionsState): AgentSignal {
  if (!o.available) {
    return {
      agent: 'Options', direction: 0, confidence: 0.1,
      dataQuality: 0.1, freshness: 0.1, regimeCompat: 0.3, weight: 0,
      note: 'Options feed not connected — options signal disabled', raw: 0, available: false,
    };
  }
  let dir: Direction = 0;
  let conf = 0.35;
  let note = o.note;
  if (o.skew === 'bullish') { dir = 1; conf = 0.45; }
  else if (o.skew === 'bearish') { dir = -1; conf = 0.45; }
  return {
    agent: 'Options', direction: dir, confidence: conf,
    dataQuality: 0.75, freshness: 0.8, regimeCompat: 0.65, weight: 0,
    note, raw: 0, available: true,
  };
}

function macroAgent(macro: MacroEvent[], news: NewsItem[]): AgentSignal {
  let dir: Direction = 0;
  let conf = 0.4;
  let note = 'No imminent macro event';
  let available = true;

  if (macro.length === 0 && news.length === 0) {
    available = false;
    return {
      agent: 'Macro', direction: 0, confidence: 0.2,
      dataQuality: 0.2, freshness: 0.3, regimeCompat: 0.5, weight: 0,
      note: 'No economic calendar feed — macro context unavailable', raw: 0, available: false,
    };
  }

  const nextEvent = macro[0];
  if (nextEvent && nextEvent.minutesUntil < 60) {
    conf = 0.2;
    note = `${nextEvent.name} in ${nextEvent.minutesUntil}min — reduce confidence`;
  } else {
    const newsDir = news.slice(0, 3).reduce((s, n) => s + n.direction * (n.marketImpact / 100), 0);
    dir = newsDir > 0.3 ? 1 : newsDir < -0.3 ? -1 : 0;
    conf = 0.5;
    note = `News sentiment ${newsDir > 0 ? 'bullish' : newsDir < 0 ? 'bearish' : 'neutral'}`;
  }
  return {
    agent: 'Macro', direction: dir, confidence: conf,
    dataQuality: 0.8, freshness: 0.85, regimeCompat: 0.7, weight: 0,
    note, raw: 0, available,
  };
}

function geoAgent(geo: GeoEvent[]): AgentSignal {
  if (geo.length === 0) {
    return {
      agent: 'Geopolitical', direction: 0, confidence: 0.3,
      dataQuality: 0.7, freshness: 0.8, regimeCompat: 0.6, weight: 0,
      note: 'No geopolitical events feed', raw: 0, available: false,
    };
  }
  const top = geo[0];
  const dir: Direction = top.netImpact === 'bullish' ? 1 : top.netImpact === 'bearish' ? -1 : 0;
  const conf = top.score / 100;
  return {
    agent: 'Geopolitical', direction: dir, confidence: conf,
    dataQuality: top.credibility / 100, freshness: 0.7, regimeCompat: 0.6, weight: 0,
    note: `${top.eventType} — score ${top.score}, net ${top.netImpact}`, raw: 0, available: true,
  };
}

function liquidityAgent(structure: StructureState, price: number): AgentSignal {
  const pools = structure.liquidity;
  if (pools.length === 0) {
    return {
      agent: 'Liquidity', direction: 0, confidence: 0.3,
      dataQuality: 0.7, freshness: 0.9, regimeCompat: 0.7, weight: 0,
      note: 'No mapped liquidity', raw: 0, available: true,
    };
  }
  const above = pools.filter((p) => p.side === 'above');
  const below = pools.filter((p) => p.side === 'below');
  const nearestAbove = above[0];
  const nearestBelow = below[0];
  let dir: Direction = 0;
  let conf = 0.4;
  let note = 'Balanced liquidity';
  if (nearestAbove && nearestAbove.distance < (nearestBelow?.distance ?? Infinity)) {
    dir = 1;
    conf = nearestAbove.targetProb;
    note = `Targeting ${nearestAbove.type} @ ${nearestAbove.level} (above)`;
  } else if (nearestBelow) {
    dir = -1;
    conf = nearestBelow.targetProb;
    note = `Targeting ${nearestBelow.type} @ ${nearestBelow.level} (below)`;
  }
  return {
    agent: 'Liquidity', direction: dir, confidence: conf,
    dataQuality: 0.8, freshness: 0.95, regimeCompat: 0.75, weight: 0,
    note, raw: 0, available: true,
  };
}

export function fuseAgents(input: AgentInput): AgentSignal[] {
  const weights = regimeWeights(input.regime);
  const agents = [
    structureAgent(input.structure.H1, input.price),
    microAgent(input.micro),
    correlationAgent(input.correlations),
    optionsAgent(input.options),
    macroAgent(input.macro, input.news),
    geoAgent(input.geo),
    liquidityAgent(input.structure.H1, input.price),
  ];
  for (const a of agents) {
    const w = weights[a.agent.toLowerCase()] ?? 0.1;
    a.weight = w;
    a.raw = Math.round(a.direction * a.confidence * a.dataQuality * a.freshness * a.regimeCompat * 1000) / 1000;
  }
  return agents;
}

// ─── Setup state machine ────────────────────────────────────────
// This is the core of the engine. A trade is NOT created just because
// agents are bullish/bearish. Instead, a setup must progress through
// a strict sequence of structural stages.

export interface SetupContext {
  structure: Record<Timeframe, StructureState>;
  sessions: SessionInfo;
  micro: MicrostructureState;
  price: number;
  candles: Record<Timeframe, Candle[]>;
  macro: MacroEvent[];
  currentSetup: SetupState | null;
  quality: QualityReport;
}

export function evaluateSetupState(ctx: SetupContext, currentTime: number): SetupState | null {
  const { structure, sessions, micro, price, candles, macro, currentSetup, quality } = ctx;

  // Step 1: HTF bias confirmed
  const htfBias = structure.H4?.bias ?? structure.H1?.bias ?? 'neutral';
  if (htfBias === 'neutral' || htfBias === 'ranging') {
    // No HTF bias — no setup
    if (currentSetup && currentSetup.currentStage !== 'CLOSED' && currentSetup.currentStage !== 'INVALIDATED') {
      return invalidateSetup(currentSetup, 'HTF bias lost — no longer bullish or bearish', currentTime);
    }
    return null;
  }

  const direction: Direction = htfBias === 'bullish' ? 1 : -1;
  const htfTimeframe: Timeframe = 'H4';

  // Check if we should continue existing setup or create new one
  let setup: SetupState | null = null;
  if (isSameSetup(currentSetup, direction, htfBias, htfTimeframe, currentTime)) {
    setup = currentSetup!;
  } else {
    // Invalidate old setup if exists
    if (currentSetup && currentSetup.currentStage !== 'CLOSED' && currentSetup.currentStage !== 'INVALIDATED' && currentSetup.currentStage !== 'EXPIRED') {
      // Different direction or bias — old setup is invalidated
      // (caller handles this)
    }
    const sessionName = sessions.current === 'OFF' ? 'GLOBAL' : sessions.current === 'NEW_YORK' ? 'NY' : sessions.current === 'LONDON' ? 'LDN' : 'ASN';
    const setupId = generateSetupId('XAUUSD', sessionName, new Date(currentTime), direction);
    setup = createSetup(setupId, direction, htfBias, htfTimeframe, currentTime);
  }

  const allowReasons: string[] = [];
  const refuseReasons: string[] = [];

  // Step 2: Liquidity target identified
  const pools = structure.H1?.liquidity ?? [];
  const targetPools = direction > 0
    ? pools.filter((p) => p.side === 'above' && !p.swept)
    : pools.filter((p) => p.side === 'below' && !p.swept);
  const liquidityTarget = targetPools[0] ?? null;
  if (liquidityTarget) {
    setup.liquidityTarget = liquidityTarget;
    if (!setup.steps.find((s) => s.stage === 'LIQUIDITY_TARGET_IDENTIFIED')?.completed) {
      setup = advanceStage(setup, 'LIQUIDITY_TARGET_IDENTIFIED', `${liquidityTarget.type} @ ${liquidityTarget.level}`, currentTime);
    }
    allowReasons.push(`Liquidity target: ${liquidityTarget.type} @ ${liquidityTarget.level}`);
  } else {
    refuseReasons.push('No unswept liquidity target identified');
  }

  // Step 3: Liquidity swept
  const sweptPools = direction > 0
    ? pools.filter((p) => p.side === 'below' && p.swept && p.rejected)
    : pools.filter((p) => p.side === 'above' && p.swept && p.rejected);
  const sweep = sweptPools[0] ?? null;
  if (sweep) {
    setup.sweep = sweep;
    if (!setup.steps.find((s) => s.stage === 'LIQUIDITY_SWEPT')?.completed) {
      setup = advanceStage(setup, 'LIQUIDITY_SWEPT', `${sweep.type} swept @ ${sweep.level}, rejected`, currentTime);
    }
    allowReasons.push(`Liquidity sweep: ${sweep.type} @ ${sweep.level} (rejected)`);
  } else {
    refuseReasons.push('No liquidity sweep with rejection detected yet');
  }

  // Step 4: Displacement
  const m1Events = structure.M1?.events ?? [];
  const m5Events = structure.M5?.events ?? [];
  const allEvents = [...m1Events, ...m5Events];
  const displacementEvent = allEvents.find((e) =>
    e.confirmed && e.direction === (direction > 0 ? 'bullish' : 'bearish') && e.displacement > 0.8
  );
  if (displacementEvent) {
    setup.displacement = displacementEvent;
    if (!setup.steps.find((s) => s.stage === 'DISPLACEMENT')?.completed) {
      setup = advanceStage(setup, 'DISPLACEMENT', `${displacementEvent.type} ${displacementEvent.direction}, disp ${displacementEvent.displacement}x ATR`, currentTime);
    }
    allowReasons.push(`Displacement: ${displacementEvent.displacement}x ATR`);
  } else {
    refuseReasons.push('No displacement detected (need > 0.8x ATR)');
  }

  // Step 5: MSS
  const mssEvent = allEvents.find((e) => e.type === 'MSS' && e.confirmed && e.direction === (direction > 0 ? 'bullish' : 'bearish'));
  if (mssEvent) {
    setup.mss = mssEvent;
    if (!setup.steps.find((s) => s.stage === 'MSS')?.completed) {
      setup = advanceStage(setup, 'MSS', `MSS ${mssEvent.direction} @ ${mssEvent.level}`, currentTime);
    }
    allowReasons.push(`MSS confirmed: ${mssEvent.direction}`);
  } else if (displacementEvent && displacementEvent.type === 'MSS') {
    // Already handled above
    setup.mss = displacementEvent;
    if (!setup.steps.find((s) => s.stage === 'MSS')?.completed) {
      setup = advanceStage(setup, 'MSS', `MSS ${displacementEvent.direction} @ ${displacementEvent.level}`, currentTime);
    }
    allowReasons.push(`MSS confirmed: ${displacementEvent.direction}`);
  } else {
    refuseReasons.push('No MSS detected yet');
  }

  // Step 6: POI identified (FVG, OB, Breaker, IFVG, CE)
  const poiCandidates: { type: string; obj: FVG | OrderBlock | BreakerBlock | IFVG; top: number; bottom: number; ce: number; direction: string }[] = [];
  for (const fvg of structure.M5?.fvgs ?? []) {
    if ((fvg.status === 'fresh' || fvg.status === 'touched') && fvg.direction === (direction > 0 ? 'bullish' : 'bearish')) {
      poiCandidates.push({ type: 'FVG', obj: fvg, top: fvg.top, bottom: fvg.bottom, ce: fvg.ce, direction: fvg.direction });
    }
  }
  for (const ifvg of structure.M5?.ifvgs ?? []) {
    if (ifvg.status === 'fresh' && ifvg.direction === (direction > 0 ? 'bullish' : 'bearish')) {
      poiCandidates.push({ type: 'IFVG', obj: ifvg, top: ifvg.top, bottom: ifvg.bottom, ce: ifvg.ce, direction: ifvg.direction });
    }
  }
  for (const ob of structure.M5?.orderBlocks ?? []) {
    if (ob.status === 'fresh' && ob.direction === (direction > 0 ? 'bullish' : 'bearish')) {
      poiCandidates.push({ type: 'OB', obj: ob, top: ob.top, bottom: ob.bottom, ce: ob.ce, direction: ob.direction });
    }
  }
  for (const brk of structure.M5?.breakers ?? []) {
    if (brk.status === 'fresh' && brk.direction === (direction > 0 ? 'bullish' : 'bearish')) {
      poiCandidates.push({ type: 'Breaker', obj: brk, top: brk.top, bottom: brk.bottom, ce: brk.ce, direction: brk.direction });
    }
  }

  // Find POI that price is retracing toward
  const poi = poiCandidates.find((p) => {
    if (direction > 0) return price >= p.bottom && price <= p.top + atr(ctx.candles.M5, 14) * 0.5;
    return price <= p.top && price >= p.bottom - atr(ctx.candles.M5, 14) * 0.5;
  }) ?? poiCandidates[0] ?? null;

  if (poi) {
    setup.poi = poi.obj;
    setup.poiType = poi.type;
    setup.entryZoneMin = poi.bottom;
    setup.entryZoneMax = poi.top;
    setup.preferredEntry = poi.ce;
    if (!setup.steps.find((s) => s.stage === 'POI_IDENTIFIED')?.completed) {
      setup = advanceStage(setup, 'POI_IDENTIFIED', `${poi.type} @ ${poi.bottom}-${poi.top}, CE ${poi.ce}`, currentTime);
    }
    allowReasons.push(`POI: ${poi.type} @ ${poi.bottom}-${poi.top}`);
  } else {
    refuseReasons.push('No valid POI (FVG/OB/Breaker/IFVG) identified');
  }

  // Step 7: Retracement into POI
  if (poi) {
    const inPOI = price >= poi.bottom && price <= poi.top;
    if (inPOI) {
      if (!setup.steps.find((s) => s.stage === 'RETRACEMENT_INTO_POI')?.completed) {
        setup = advanceStage(setup, 'RETRACEMENT_INTO_POI', `Price @ ${price} inside POI ${poi.bottom}-${poi.top}`, currentTime);
      }
      allowReasons.push('Price retraced into POI');
    } else {
      refuseReasons.push(`Price not yet inside POI (current ${price}, POI ${poi.bottom}-${poi.top})`);
    }
  }

  // Step 8: M1 trigger
  const m1Trigger = micro.sweep && micro.sweep.side === (direction > 0 ? 'buyer' : 'seller');
  if (m1Trigger && micro.sweep) {
    setup.triggerPrice = price;
    if (!setup.steps.find((s) => s.stage === 'M1_TRIGGER')?.completed) {
      setup = advanceStage(setup, 'M1_TRIGGER', `M1 sweep trigger @ ${micro.sweep.level}`, currentTime);
    }
    allowReasons.push('M1 trigger: sweep detected');
  } else {
    // Also check for M1 displacement as trigger
    const m1Disp = structure.M1?.displacement?.isDisplacement ?? false;
    const m1Dir = structure.M1?.lastEvent?.direction;
    if (m1Disp && m1Dir === (direction > 0 ? 'bullish' : 'bearish')) {
      setup.triggerPrice = price;
      if (!setup.steps.find((s) => s.stage === 'M1_TRIGGER')?.completed) {
        setup = advanceStage(setup, 'M1_TRIGGER', `M1 displacement trigger`, currentTime);
      }
      allowReasons.push('M1 trigger: displacement detected');
    } else {
      refuseReasons.push('No M1 trigger detected (sweep or displacement)');
    }
  }

  // Compute SL and targets (structural)
  if (poi) {
    const atrVal = atr(ctx.candles.H1, 14) || 5;
    // SL behind the sweep extreme or structure invalidation
    const sweepExtreme = setup.sweep?.sweepExtreme;
    if (direction > 0) {
      // BUY: SL below sweep extreme or POI bottom
      setup.stopLoss = sweepExtreme ? sweepExtreme - atrVal * 0.2 : poi.bottom - atrVal * 0.3;
    } else {
      // SELL: SL above sweep extreme or POI top
      setup.stopLoss = sweepExtreme ? sweepExtreme + atrVal * 0.2 : poi.top + atrVal * 0.3;
    }
    setup.stopLoss = Math.round(setup.stopLoss * 100) / 100;

    // Targets from real liquidity
    const risk = Math.abs(setup.preferredEntry - setup.stopLoss);
    const liquidityTargets = direction > 0
      ? pools.filter((p) => p.side === 'above' && p.level > setup!.preferredEntry).sort((a, b) => a.level - b.level)
      : pools.filter((p) => p.side === 'below' && p.level < setup!.preferredEntry).sort((a, b) => b.level - a.level);

    const targets: number[] = [];
    if (liquidityTargets[0]) targets.push(Math.round(liquidityTargets[0].level * 100) / 100);
    if (liquidityTargets[1]) targets.push(Math.round(liquidityTargets[1].level * 100) / 100);
    if (liquidityTargets[2]) targets.push(Math.round(liquidityTargets[2].level * 100) / 100);

    // If not enough liquidity targets, use session levels
    if (targets.length < 3) {
      if (direction > 0) {
        if (sessions.pdh > 0 && !targets.includes(sessions.pdh)) targets.push(sessions.pdh);
        if (sessions.pwh > 0 && !targets.includes(sessions.pwh)) targets.push(sessions.pwh);
      } else {
        if (sessions.pdl > 0 && !targets.includes(sessions.pdl)) targets.push(sessions.pdl);
        if (sessions.pwl > 0 && !targets.includes(sessions.pwl)) targets.push(sessions.pwl);
      }
    }

    // If still not enough targets, we don't have structural targets
    setup.targets = targets.slice(0, 3);

    // Compute RR
    setup.rR = setup.targets.map((t) => Math.round(Math.abs(t - setup!.preferredEntry) / risk * 100) / 100);

    // Check if RR is sufficient (minimum 1R for TP1)
    if (setup.rR.length === 0 || setup.rR[0] < 1.0) {
      refuseReasons.push('Insufficient RR — nearest liquidity target does not provide 1R minimum');
    }
  }

  // Step 9: READY — all structural conditions met
  const allStepsComplete = setup.steps.filter((s) =>
    ['LIQUIDITY_TARGET_IDENTIFIED', 'LIQUIDITY_SWEPT', 'DISPLACEMENT', 'MSS', 'POI_IDENTIFIED', 'RETRACEMENT_INTO_POI', 'M1_TRIGGER'].includes(s.stage)
  ).every((s) => s.completed);

  // Check data quality and macro risk
  const qualityOK = ctx.quality.status === 'VALID' || ctx.quality.status === 'RECONSTRUCTED';
  const nextMacro = macro.find((m) => m.impact === 'high' && m.minutesUntil < 30);
  setup.nextMajorNews = nextMacro ?? null;

  if (!qualityOK) {
    refuseReasons.push(`Data quality: ${ctx.quality.status} — trading blocked`);
  }
  if (nextMacro) {
    refuseReasons.push(`High-impact news in ${nextMacro.minutesUntil}min — no new trades`);
  }

  if (allStepsComplete && qualityOK && !nextMacro && setup.rR.length > 0 && setup.rR[0] >= 1.0) {
    if (!setup.steps.find((s) => s.stage === 'READY')?.completed) {
      setup = advanceStage(setup, 'READY', 'All structural conditions met', currentTime);
    }
    allowReasons.push('All structural conditions met — READY');

    // Step 10: EXECUTE — trigger price reached
    if (setup.triggerPrice > 0 && setup.preferredEntry > 0) {
      const triggerHit = direction > 0
        ? price <= setup.preferredEntry && price >= setup.entryZoneMin
        : price >= setup.preferredEntry && price <= setup.entryZoneMax;
      if (triggerHit) {
        if (!setup.steps.find((s) => s.stage === 'EXECUTE')?.completed) {
          setup = advanceStage(setup, 'EXECUTE', `Entry triggered @ ${price}`, currentTime);
        }
        allowReasons.push(`EXECUTE: entry @ ${price}`);
      }
    }
  } else {
    if (allStepsComplete) {
      // Conditions met but quality or macro blocks
      setup.status = 'WAIT';
    } else {
      setup.status = 'MONITOR';
    }
  }

  // Determine final status
  const execStep = setup.steps.find((s) => s.stage === 'EXECUTE');
  const readyStep = setup.steps.find((s) => s.stage === 'READY');
  if (execStep?.completed) {
    setup.status = 'EXECUTE';
  } else if (readyStep?.completed) {
    setup.status = 'READY';
  } else if (setup.steps.filter((s) => ['LIQUIDITY_TARGET_IDENTIFIED', 'LIQUIDITY_SWEPT', 'DISPLACEMENT', 'MSS', 'POI_IDENTIFIED'].includes(s.stage) && s.completed).length >= 2) {
    setup.status = 'MONITOR';
  } else {
    setup.status = 'WAIT';
  }

  // If data quality is invalid, force NO_TRADE
  if (!qualityOK && ctx.quality.status === 'INVALID') {
    setup.status = 'NO_TRADE';
  }

  setup.allowReasons = allowReasons;
  setup.refuseReasons = refuseReasons;
  setup.updatedAt = currentTime;

  return setup;
}

// ─── Scenarios (for display only — not the trigger for trades) ──

export function buildScenarios(input: AgentInput, agents: AgentSignal[]): Scenario[] {
  const price = input.price;
  const atrVal = atr(input.candles.H1, 14) || 5;
  const totalSignal = agents.filter((a) => a.available).reduce((s, a) => s + a.raw * a.weight, 0);
  const totalWeight = agents.filter((a) => a.available).reduce((s, a) => s + a.weight, 0);
  const normalizedSignal = totalWeight > 0 ? totalSignal / totalWeight : 0;
  const bullProb = Math.max(0.05, Math.min(0.9, 0.5 + normalizedSignal * 1.2));
  const bearProb = Math.max(0.05, Math.min(0.9, 0.5 - normalizedSignal * 1.2));
  const neutralProb = Math.max(0.05, 1 - bullProb - bearProb);
  const sum = bullProb + bearProb + neutralProb;
  const pBull = Math.round((bullProb / sum) * 100) / 100;
  const pBear = Math.round((bearProb / sum) * 100) / 100;
  const pNeutral = Math.max(0, Math.round((1 - pBull - pBear) * 100) / 100);

  const bullScenario: Scenario = {
    name: 'Scénario haussier', probability: pBull, direction: 1,
    trigger: `Clôture M5 au-dessus de ${Math.round((price + atrVal * 0.3) * 100) / 100}`,
    entry: [Math.round((price - atrVal * 0.1) * 100) / 100, Math.round((price + atrVal * 0.2) * 100) / 100],
    invalidation: Math.round((price - atrVal * 1.2) * 100) / 100,
    targets: [Math.round((price + atrVal * 1.2) * 100) / 100, Math.round((price + atrVal * 2.5) * 100) / 100, Math.round((price + atrVal * 4) * 100) / 100],
    rR: [1.0, 2.1, 3.3], note: 'Continuation haussière',
  };
  const bearScenario: Scenario = {
    name: 'Scénario baissier', probability: pBear, direction: -1,
    trigger: `Clôture M5 sous ${Math.round((price - atrVal * 0.3) * 100) / 100}`,
    entry: [Math.round((price - atrVal * 0.2) * 100) / 100, Math.round((price + atrVal * 0.1) * 100) / 100],
    invalidation: Math.round((price + atrVal * 1.2) * 100) / 100,
    targets: [Math.round((price - atrVal * 1.2) * 100) / 100, Math.round((price - atrVal * 2.5) * 100) / 100, Math.round((price - atrVal * 4) * 100) / 100],
    rR: [1.0, 2.1, 3.3], note: 'Rejet baissier',
  };
  const neutral: Scenario = {
    name: 'Neutralité', probability: pNeutral, direction: 0,
    trigger: '', entry: [0, 0], invalidation: 0, targets: [], rR: [], note: 'Attendre résolution',
  };
  if (pBull >= pBear) { bullScenario.name = 'Scénario principal'; bearScenario.name = 'Scénario alternatif'; return [bullScenario, bearScenario, neutral]; }
  else { bearScenario.name = 'Scénario principal'; bullScenario.name = 'Scénario alternatif'; return [bearScenario, bullScenario, neutral]; }
}

export function computeEV(scenarios: Scenario[], stop: number, entry: number): number {
  const main = scenarios[0]; const alt = scenarios[1];
  if (!main || !alt) return 0;
  const risk = Math.abs(entry - stop);
  if (risk === 0) return 0;
  const ev = main.probability * (main.rR[0] || 1.5) - alt.probability * 1 - 0.05;
  return Math.round(ev * 1000) / 1000;
}

export function detectConflicts(agents: AgentSignal[]): string[] {
  const conflicts: string[] = [];
  const buyAgents = agents.filter((a) => a.available && a.direction > 0 && a.confidence > 0.5);
  const sellAgents = agents.filter((a) => a.available && a.direction < 0 && a.confidence > 0.5);
  if (buyAgents.length >= 2 && sellAgents.length >= 2) {
    conflicts.push(`Conflit: ${buyAgents.map((a) => a.agent).join(', ')} vs ${sellAgents.map((a) => a.agent).join(', ')}`);
  }
  return conflicts;
}

export function buildDecisionTree(input: AgentInput, agents: AgentSignal[], scenarios: Scenario[]): string[] {
  const tree: string[] = [];
  const s = input.structure;
  if (s.D?.bias !== 'neutral') tree.push(`Régime Daily ${s.D.bias}.`);
  if (s.H4?.bias !== 'neutral') tree.push(`Structure H4 ${s.H4.bias}.`);
  if (s.H1?.bias !== 'neutral') tree.push(`Structure H1 ${s.H1.bias}.`);
  if (s.H1?.dealingRange) {
    if (s.H1.discount) tree.push('Prix en discount du dealing range H1.');
    if (s.H1.premium) tree.push('Prix en premium du dealing range H1.');
  }
  if (s.H1?.lastEvent) tree.push(`${s.H1.lastEvent.type} ${s.H1.lastEvent.direction} sur H1.`);
  if (input.micro.absorption) tree.push(`Absorption ${input.micro.absorption.side}.`);
  if (input.micro.sweep) tree.push(`Sweep ${input.micro.sweep.side} @ ${input.micro.sweep.level}.`);
  const nextNews = input.macro[0];
  if (nextNews) tree.push(`Prochaine news: ${nextNews.name} dans ${nextNews.minutesUntil}min.`);
  const ev = scenarios[0]?.probability ? computeEV(scenarios, scenarios[0].invalidation, (scenarios[0].entry[0] + scenarios[0].entry[1]) / 2) : 0;
  if (ev > 0) tree.push(`Espérance positive: +${ev}R.`);
  return tree;
}

export function buildTradePlan(
  input: AgentInput, agents: AgentSignal[], scenarios: Scenario[],
  conflicts: string[], ev: number, setup: SetupState | null,
): TradePlan {
  const main = scenarios[0];
  const price = input.price;
  const nextNews = input.macro[0];
  const nextNewsStr = nextNews ? `dans ${nextNews.minutesUntil}min (${nextNews.name})` : 'aucune';

  // Status comes from the setup state machine, not from agent scores
  let status: TradePlan['status'] = 'WAIT';
  let action = 'En attente — pas de setup valide.';
  let direction: Direction = main?.direction ?? 0;
  let entry: [number, number] = [0, 0];
  let stop = 0;
  let targets: number[] = [];
  let rR: number[] = [];
  let setupId: string | null = null;
  let setupSteps: SetupStep[] = [];
  let allowReasons: string[] = [];
  let refuseReasons: string[] = [];
  let poiType = '';
  let preferredEntry = 0;
  let triggerPrice = 0;

  if (setup) {
    status = setup.status;
    direction = setup.direction;
    entry = [setup.entryZoneMin, setup.entryZoneMax];
    stop = setup.stopLoss;
    targets = setup.targets;
    rR = setup.rR;
    setupId = setup.setupId;
    setupSteps = setupProgressSteps(setup);
    allowReasons = setup.allowReasons;
    refuseReasons = setup.refuseReasons;
    poiType = setup.poiType;
    preferredEntry = setup.preferredEntry;
    triggerPrice = setup.triggerPrice;

    switch (setup.status) {
      case 'EXECUTE':
        action = `${direction > 0 ? 'BUY' : 'SELL'} — entrée déclenchée @ ${price}`;
        break;
      case 'READY':
        action = `Setup ${direction > 0 ? 'BUY' : 'SELL'} READY — attendre déclencheur M1`;
        break;
      case 'MONITOR':
        action = 'Setup en construction — surveiller les étapes';
        break;
      case 'WAIT':
        action = 'En attente — conditions structurelles incomplètes';
        break;
      case 'NO_TRADE':
        action = refuseReasons[0] || 'Trading désactivé';
        break;
    }
  }

  // Override to NO_TRADE if data quality is invalid
  if (input.quality.status === 'INVALID') {
    status = 'NO_TRADE';
    action = 'DATA OFFLINE — qualité invalide, trading bloqué';
  }

  const confidence = setup ? Math.min(0.95, 0.3 + setupProgressSteps(setup).filter((s) => s.completed).length * 0.08) : 0.3;
  const macroStr = input.macro[0]?.minutesUntil < 60
    ? `Risqué — ${input.macro[0].name} dans ${input.macro[0].minutesUntil}min`
    : 'Aucun risque macro immédiat';
  const geoStr = input.geo[0] ? (input.geo[0].netImpact === 'bullish' ? 'Haussier' : input.geo[0].netImpact === 'bearish' ? 'Baissier' : 'Neutre') : 'N/A';
  const orderFlowStr = input.micro.absorption
    ? `Absorption ${input.micro.absorption.side}`
    : input.micro.sweep ? `Sweep ${input.micro.sweep.side}`
    : input.micro.ofiAvailable ? `OFI ${input.micro.ofi}` : 'Volume indisponible';
  const liquidityStr = setup?.liquidityTarget ? `Objectif ${setup.liquidityTarget.type} @ ${setup.liquidityTarget.level}` : 'Aucun objectif';
  const invalidation = setup ? `SL structurel @ ${stop}. Invalidation: ${setup.invalidationReason || 'cassure du niveau de structure'}` : 'N/A';
  const decisionTree = buildDecisionTree(input, agents, scenarios);

  return {
    status, direction, confidence, regime: input.regime, regimeLabel: '',
    horizon: '45 à 180 minutes', zone: entry, trigger: main?.trigger ?? '',
    entry, stop, targets, rR, macro: macroStr, geopolitical: geoStr,
    orderFlow: orderFlowStr, liquidity: liquidityStr, invalidation,
    nextNews: nextNewsStr, action, decisionTree, conflicts, ev,
    scenarios, agents, timestamp: Date.now(),
    setupId, setupSteps, allowReasons, refuseReasons,
    poiType, preferredEntry, triggerPrice,
  };
}

export function generateAlerts(plan: TradePlan, input: AgentInput): AlertItem[] {
  const alerts: AlertItem[] = [];
  const now = Date.now();
  if (plan.status === 'EXECUTE') {
    alerts.push({ id: `a-${now}`, time: now, type: 'validated', message: `${plan.direction > 0 ? 'BUY' : 'SELL'} EXECUTE — entrée ${plan.entry[0]}-${plan.entry[1]}, SL ${plan.stop}`, severity: 'info' });
  }
  if (plan.status === 'READY') {
    alerts.push({ id: `a-${now}`, time: now, type: 'trigger', message: `Setup READY — attendre M1 trigger`, severity: 'warning' });
  }
  if (input.quality.status === 'INVALID') {
    alerts.push({ id: `a-${now + 1}`, time: now, type: 'feed', message: `DATA OFFLINE — ${input.quality.reason}`, severity: 'critical' });
  }
  const nextNews = input.macro[0];
  if (nextNews && nextNews.minutesUntil < 30) {
    alerts.push({ id: `a-${now + 2}`, time: now, type: 'news', message: `News critique: ${nextNews.name} dans ${nextNews.minutesUntil}min`, severity: 'critical' });
  }
  return alerts;
}

export function planToJournal(plan: TradePlan): JournalEntry {
  return {
    id: plan.setupId || `j-${plan.timestamp}`,
    time: plan.timestamp,
    direction: plan.direction,
    status: plan.status,
    confidence: plan.confidence,
    regime: plan.regime,
    entry: (plan.entry[0] + plan.entry[1]) / 2,
    stop: plan.stop,
    targets: plan.targets,
    outcome: 'pending',
    reasoning: plan.decisionTree.join(' '),
    conflicts: plan.conflicts,
    ev: plan.ev,
    setupId: plan.setupId,
    mfe: null, mae: null, rRealized: null,
  };
}
