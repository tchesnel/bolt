import { useState, useEffect, useRef } from 'react';
import { MarketSnapshot, Timeframe, Candle, ALL_TIMEFRAMES } from '@/engine/types';
import { simulateMarket, aggregateCandles, quotesFromTicks, computePriceState } from '@/engine/market';
import { runPipeline } from '@/engine/pipeline';
import { Dashboard } from '@/components/Dashboard';
import { recordSignal } from '@/lib/journal';

interface Tick { time: number; price: number; volume: number; buyVolume: number; sellVolume: number; }

export function useLiveEngine() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const ticksRef = useRef<Tick[]>([]);
  const momentumRef = useRef(0);
  const stepRef = useRef(0);

  useEffect(() => {
    // Seed with 3 days of historical ticks so all timeframes have data.
    const now = Date.now();
    const sim = simulateMarket({
      startTime: now - 3 * 24 * 60 * 60 * 1000,
      ticksPerMinute: 20,
      durationMinutes: 3 * 24 * 60,
      basePrice: 4025,
      seed: 42,
    });
    ticksRef.current = [...sim.ticks];
    momentumRef.current = 0;
    stepRef.current = 0;

    // Continue the price walk forward from the last simulated tick.
    const lastSimTick = sim.ticks[sim.ticks.length - 1];
    let price = lastSimTick.price;
    const tickIntervalMs = 3000;

    const compute = () => {
      const ticks = ticksRef.current;
      if (ticks.length === 0) return;
      const lastTick = ticks[ticks.length - 1];
      const quotes = quotesFromTicks(lastTick.price, lastTick.time, Math.random);
      const priceState = computePriceState(quotes, lastTick.time);
      const candles = {} as Record<Timeframe, Candle[]>;
      for (const tf of ALL_TIMEFRAMES) candles[tf] = aggregateCandles(ticks, tf);
      const snap = runPipeline(candles, priceState, lastTick.time);
      setSnapshot(snap);

      // Record to journal — one row per unique setup_id, prediction frozen at first detection.
      // No 60s duplicate snapshots. NO_TRADE setups are not recorded.
      recordSignal(snap);
    };

    compute();

    const interval = setInterval(() => {
      const last = ticksRef.current[ticksRef.current.length - 1];
      const regimes = [
        { vol: 0.35, drift: 0.0008 },
        { vol: 0.55, drift: -0.0012 },
        { vol: 0.7, drift: 0.0022 },
        { vol: 0.4, drift: 0.0005 },
      ];
      const regime = regimes[stepRef.current % regimes.length];
      const shock = (Math.random() - 0.5) * 2 * regime.vol;
      momentumRef.current = Math.max(-1.2, Math.min(1.2, momentumRef.current * 0.82 + shock * 0.35 + regime.drift));
      price += momentumRef.current;

      if (Math.random() < 0.004) price += (Math.random() - 0.5) * 4 * regime.vol;

      const buyBias = momentumRef.current > 0
        ? 0.55 + Math.abs(momentumRef.current) * 0.1
        : 0.45 - Math.abs(momentumRef.current) * 0.05;
      const vol = Math.max(0.5, 1 + Math.abs(momentumRef.current) * 3 + Math.random() * 2);
      const buy = vol * Math.min(0.85, Math.max(0.15, buyBias + (Math.random() - 0.5) * 0.2));

      ticksRef.current.push({
        time: last.time + tickIntervalMs,
        price: Math.round(price * 100) / 100,
        volume: vol,
        buyVolume: buy,
        sellVolume: vol - buy,
      });

      const cutoff = last.time - 4 * 24 * 60 * 60 * 1000;
      if (ticksRef.current.length > 200000) {
        ticksRef.current = ticksRef.current.filter((t) => t.time > cutoff);
      }

      stepRef.current++;
      compute();
    }, tickIntervalMs);

    return () => clearInterval(interval);
  }, []);

  return snapshot;
}

export default function App() {
  const snapshot = useLiveEngine();
  return <Dashboard snapshot={snapshot} />;
}
