import { createClient } from '@supabase/supabase-js';
import { MarketSnapshot, JournalEntry } from '@/engine/types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// ---------------------------------------------------------------------------
// Journal recording — stable setup_id, frozen prediction, no 60s duplicates
// ---------------------------------------------------------------------------

const recordedSetups = new Set<string>();

function snapshotToEntry(snap: MarketSnapshot): JournalEntry {
  const plan = snap.plan;
  const m5 = snap.structure['M5'];
  const m15 = snap.structure['M15'];
  const h1 = snap.structure['H1'];
  const h4 = snap.structure['H4'];

  const swept = (m5.liquidity || []).some(p => p.swept) || (m15.liquidity || []).some(p => p.swept);

  const bos = m5.lastEvent?.type === 'BOS' ? `${m5.lastEvent.direction} @ ${m5.lastEvent.price.toFixed(2)}` : null;
  const choch = m5.lastEvent?.type === 'CHOCH' ? `${m5.lastEvent.direction} @ ${m5.lastEvent.price.toFixed(2)}` : null;
  const mss = m5.lastEvent?.type === 'MSS' ? `${m5.lastEvent.direction} @ ${m5.lastEvent.price.toFixed(2)}` : null;

  const freshFvg = (m5.fvgs || []).find(f => f.fresh);
  const fvg = freshFvg ? `${freshFvg.direction} ${freshFvg.bottom.toFixed(2)}-${freshFvg.top.toFixed(2)}` : null;
  const ifvg = null; // IFVG detection not yet implemented
  const ob = (m5.orderBlocks || []).find(o => !o.mitigated);
  const obStr = ob ? `${ob.direction} ${ob.bottom.toFixed(2)}-${ob.top.toFixed(2)}` : null;
  const breaker = null;
  const bpr = null;

  return {
    setup_id: plan.setupId,
    symbol: 'XAUUSD',
    created_at: new Date(snap.timestamp).toISOString(),
    first_detected_at: new Date(snap.timestamp).toISOString(),
    direction: plan.direction > 0 ? 'BUY' : plan.direction < 0 ? 'SELL' : 'NEUTRAL',
    status_at_prediction: plan.status,
    price_at_prediction: snap.price.median,
    entry_min: plan.entry[0],
    entry_max: plan.entry[1],
    stop: plan.stop,
    tp1: plan.targets[0],
    tp2: plan.targets[1],
    tp3: plan.targets[2],
    confidence: plan.confidence,
    buy_score: plan.buyScore,
    sell_score: plan.sellScore,
    no_trade_score: plan.noTradeScore,
    regime: plan.regimeLabel,
    h4_bias: h4.bias,
    h1_bias: h1.bias,
    m15_structure: m15.bias,
    m5_trigger: m5.bias,
    liquidity_target: plan.drawOnLiquidity,
    liquidity_swept: swept,
    bos,
    choch,
    mss,
    fvg,
    ifvg,
    ob: obStr,
    breaker,
    bpr,
    dxy: snap.correlations.available ? snap.correlations.dxy : null,
    us10y: null,
    real_yield: snap.correlations.available ? snap.correlations.realYields10y : null,
    macro_risk: snap.macro.find(e => e.impact === 'high' && e.minutesUntil < 60)?.name ?? 'none',
    news_risk: 'low',
    agents_snapshot: plan.agents.map(a => ({ agent: a.agent, direction: a.direction, raw: a.raw, weight: a.weight, note: a.note, available: a.available })),
    predicted_ev: plan.ev,
    triggered_at: null,
    entry_price: null,
    outcome: 'PENDING',
    exit_price: null,
    closed_at: null,
    mfe: null,
    mae: null,
    tp1_hit: null,
    tp2_hit: null,
    tp3_hit: null,
    sl_hit: null,
    r_realized: null,
  };
}

// ---------------------------------------------------------------------------
// Record a signal to the journal — only once per unique setup_id
// The prediction is FROZEN at first detection and never modified afterward.
// ---------------------------------------------------------------------------

export async function recordSignal(snap: MarketSnapshot): Promise<void> {
  const setupId = snap.plan.setupId;

  // Only record each setup once — no 60s duplicate snapshots
  if (recordedSetups.has(setupId)) return;
  // Only record when there's an actual directional setup (not NO_TRADE)
  if (snap.plan.status === 'NO_TRADE') return;

  recordedSetups.add(setupId);
  const entry = snapshotToEntry(snap);

  try {
    const { error } = await supabase.from('signal_journal').upsert(entry, { onConflict: 'setup_id' });
    if (error) console.warn('[journal] insert error:', error.message);
  } catch (e) {
    console.warn('[journal] failed:', e);
  }
}

// ---------------------------------------------------------------------------
// Load journal history
// ---------------------------------------------------------------------------

export async function loadJournal(limit = 50): Promise<JournalEntry[]> {
  try {
    const { data, error } = await supabase
      .from('signal_journal')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(limit);
    if (error) { console.warn('[journal] load error:', error.message); return []; }
    return (data as JournalEntry[]) || [];
  } catch {
    return [];
  }
}
