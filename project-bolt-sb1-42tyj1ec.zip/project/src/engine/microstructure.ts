import { Candle, MicrostructureState, VolumeProfileState, VWAPState } from './types';

// ---------------------------------------------------------------------------
// Microstructure: OFI, delta, CVD, absorption, sweep, exhaustion
// NOTE: buy/sell volume comes from the simulation — treat with caution.
// A real iceberg requires order-book / execution-level data, not OHLC.
// ---------------------------------------------------------------------------

export function analyzeMicrostructure(candles: Candle[], currentPrice: number): MicrostructureState {
  const recent = candles.slice(-20);
  if (recent.length === 0) {
    return { ofi: 0, delta: 0, cvd: 0, divergence: 'none', absorption: null, sweep: null, exhaustion: null };
  }

  // OFI: order flow imbalance — compare buy vs sell volume pressure
  const totalBuy = recent.reduce((s, c) => s + c.buyVolume, 0);
  const totalSell = recent.reduce((s, c) => s + c.sellVolume, 0);
  const totalVol = totalBuy + totalSell;
  const ofi = totalVol > 0 ? (totalBuy - totalSell) / totalVol : 0;

  // Delta: recent window buy - sell
  const delta = totalBuy - totalSell;

  // CVD: cumulative across all candles
  const cvd = candles.reduce((s, c) => s + (c.buyVolume - c.sellVolume), 0);

  // Divergence: price making new high but CVD not confirming (or vice versa)
  let divergence: 'none' | 'bullish' | 'bearish' = 'none';
  if (recent.length >= 6) {
    const firstHalf = recent.slice(0, 10);
    const secondHalf = recent.slice(10);
    const priceUp = secondHalf.length > 0 && secondHalf[secondHalf.length - 1].close > firstHalf[0].open;
    const cvdFirst = firstHalf.reduce((s, c) => s + (c.buyVolume - c.sellVolume), 0);
    const cvdSecond = secondHalf.reduce((s, c) => s + (c.buyVolume - c.sellVolume), 0);
    if (priceUp && cvdSecond < cvdFirst) divergence = 'bearish';
    else if (!priceUp && cvdSecond > cvdFirst) divergence = 'bullish';
  }

  // Absorption: large volume candle with small body — someone absorbing the move
  let absorption: MicrostructureState['absorption'] = null;
  const lastCandle = recent[recent.length - 1];
  const avgRange = recent.reduce((s, c) => s + (c.high - c.low), 0) / recent.length;
  const body = Math.abs(lastCandle.close - lastCandle.open);
  if (avgRange > 0 && body < avgRange * 0.3 && lastCandle.volume > avgRange * 1.5) {
    const buyPressure = lastCandle.buyVolume > lastCandle.sellVolume;
    absorption = {
      side: buyPressure ? 'buy' : 'sell',
      zone: [lastCandle.low, lastCandle.high],
      confidence: Math.min(1, lastCandle.volume / (avgRange * 2)),
    };
  }

  // Sweep: quick wick beyond a recent extreme then rejection
  let sweep: MicrostructureState['sweep'] = null;
  if (recent.length >= 5) {
    const last = recent[recent.length - 1];
    const priorHigh = Math.max(...recent.slice(-6, -1).map(c => c.high));
    const priorLow = Math.min(...recent.slice(-6, -1).map(c => c.low));
    if (last.high > priorHigh && last.close < priorHigh) {
      sweep = { side: 'above', level: priorHigh };
    } else if (last.low < priorLow && last.close > priorLow) {
      sweep = { side: 'below', level: priorLow };
    }
  }

  // Exhaustion: volume climax + large body + at extreme
  let exhaustion: MicrostructureState['exhaustion'] = null;
  if (recent.length >= 3) {
    const last = recent[recent.length - 1];
    const avgVol = recent.slice(0, -1).reduce((s, c) => s + c.volume, 0) / (recent.length - 1);
    const body5 = Math.abs(last.close - last.open);
    const avgRange5 = recent.slice(0, -1).reduce((s, c) => s + (c.high - c.low), 0) / (recent.length - 1);
    if (last.volume > avgVol * 1.8 && body5 > avgRange5 * 0.7) {
      exhaustion = {
        side: last.close > last.open ? 'buy' : 'sell',
        level: last.close > last.open ? last.high : last.low,
      };
    }
  }

  return { ofi, delta, cvd, divergence, absorption, sweep, exhaustion };
}

// ---------------------------------------------------------------------------
// Volume profile
// ---------------------------------------------------------------------------

export function computeVolumeProfile(candles: Candle[]): VolumeProfileState {
  const recent = candles.slice(-100);
  if (recent.length === 0) {
    return { poc: 0, vah: 0, val: 0, valueArea: [0, 0], initialBalance: [0, 0], hvn: [], lvn: [] };
  }

  // Build price bins
  const minPrice = Math.min(...recent.map(c => c.low));
  const maxPrice = Math.max(...recent.map(c => c.high));
  const range = maxPrice - minPrice || 1;
  const numBins = 30;
  const binSize = range / numBins;
  const bins = new Array(numBins).fill(0);

  for (const c of recent) {
    const lowBin = Math.floor((c.low - minPrice) / binSize);
    const highBin = Math.floor((c.high - minPrice) / binSize);
    for (let b = lowBin; b <= highBin; b++) {
      bins[Math.min(numBins - 1, Math.max(0, b))] += c.volume / (highBin - lowBin + 1);
    }
  }

  const maxVol = Math.max(...bins);
  const pocBin = bins.indexOf(maxVol);
  const poc = minPrice + (pocBin + 0.5) * binSize;

  // Value area: 70% of volume around POC
  let vaVol = 0;
  let totalVol = bins.reduce((a, b) => a + b, 0);
  let vaLow = pocBin;
  let vaHigh = pocBin;
  while (vaVol < totalVol * 0.7 && (vaLow > 0 || vaHigh < numBins - 1)) {
    const below = vaLow > 0 ? bins[vaLow - 1] : -1;
    const above = vaHigh < numBins - 1 ? bins[vaHigh + 1] : -1;
    if (above >= below) { vaHigh++; vaVol += bins[vaHigh]; }
    else { vaLow--; vaVol += bins[vaLow]; }
  }
  const vah = minPrice + (vaHigh + 0.5) * binSize;
  const val = minPrice + (vaLow + 0.5) * binSize;

  // HVN / LVN
  const hvn: number[] = [];
  const lvn: number[] = [];
  const volThreshold = maxVol * 0.7;
  const lowThreshold = maxVol * 0.15;
  for (let i = 0; i < numBins; i++) {
    const price = minPrice + (i + 0.5) * binSize;
    if (bins[i] > volThreshold) hvn.push(price);
    if (bins[i] < lowThreshold && bins[i] > 0) lvn.push(price);
  }

  // Initial balance (first 30 min of session — approximated)
  const ibCandles = recent.slice(0, Math.min(5, recent.length));
  const ibHigh = Math.max(...ibCandles.map(c => c.high));
  const ibLow = Math.min(...ibCandles.map(c => c.low));

  return {
    poc, vah, val,
    valueArea: [val, vah],
    initialBalance: [ibLow, ibHigh],
    hvn: hvn.slice(0, 5),
    lvn: lvn.slice(0, 5),
  };
}

// ---------------------------------------------------------------------------
// VWAP
// ---------------------------------------------------------------------------

export function computeVWAP(candles: Candle[], period: 'daily' | 'weekly' | 'session' | 'anchored'): number {
  if (candles.length === 0) return 0;
  const now = candles[candles.length - 1].time;
  let start: number;
  switch (period) {
    case 'daily': start = now - 86400000; break;
    case 'weekly': start = now - 7 * 86400000; break;
    case 'session': start = now - 6 * 3600000; break;
    case 'anchored': start = now - 3 * 86400000; break;
  }
  const relevant = candles.filter(c => c.time >= start);
  if (relevant.length === 0) return candles[candles.length - 1].close;
  const totalVol = relevant.reduce((s, c) => s + c.volume, 0);
  if (totalVol === 0) return relevant[relevant.length - 1].close;
  const sumPV = relevant.reduce((s, c) => s + ((c.high + c.low + c.close) / 3) * c.volume, 0);
  return sumPV / totalVol;
}
