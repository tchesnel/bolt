import {
  MarketSnapshot, Timeframe, Candle, ALL_TIMEFRAMES,
  PriceState, DataQuality, StructureState, MicrostructureState,
  VolumeProfileState, VWAPState, CorrelationState, OptionsState,
  MacroEvent, NewsItem, GeoEvent, Alert, TradePlan,
} from './types';
import { aggregateCandles, computeDataQuality } from './market';
import { analyzeStructure } from './structure';
import { analyzeMicrostructure, computeVolumeProfile, computeVWAP } from './microstructure';
import { computeCorrelations, computeOptions, getMacroCalendar, getNewsFeed, getGeoEvents, generateAlerts } from './context';
import { runDecision } from './decision';

export function runPipeline(
  candles: Record<Timeframe, Candle[]>,
  priceState: PriceState,
  timestamp: number,
): MarketSnapshot {
  // Structure analysis for each timeframe
  const structure: Record<Timeframe, StructureState> = {} as Record<Timeframe, StructureState>;
  for (const tf of ALL_TIMEFRAMES) {
    structure[tf] = analyzeStructure(candles[tf] || [], tf);
  }

  // Microstructure from M1/M5
  const microstructure = analyzeMicrostructure(candles['M5'] || [], priceState.median);

  // Volume profile from M15
  const volumeProfile = computeVolumeProfile(candles['M15'] || []);

  // VWAP from M5
  const vwap: VWAPState = {
    daily: computeVWAP(candles['M5'] || [], 'daily'),
    weekly: computeVWAP(candles['M5'] || [], 'weekly'),
    session: computeVWAP(candles['M5'] || [], 'session'),
    anchored: computeVWAP(candles['M5'] || [], 'anchored'),
  };

  // Context (all honestly labeled as illustrative/unavailable)
  const correlations = computeCorrelations();
  const options = computeOptions();
  const macro = getMacroCalendar(timestamp);
  const news = getNewsFeed();
  const geo = getGeoEvents();

  // Data quality
  const quality = computeDataQuality(priceState.quotes);

  // Alerts
  const alerts = generateAlerts(quality.score, correlations, options, macro);

  // Decision
  const plan = runDecision(
    structure, microstructure, volumeProfile, vwap,
    correlations, options, macro, news, geo,
    priceState.median, timestamp,
  );

  return {
    timestamp,
    price: priceState,
    quality,
    candles,
    structure,
    microstructure,
    volumeProfile,
    vwap,
    correlations,
    options,
    macro,
    news,
    geo,
    alerts,
    plan,
  };
}
