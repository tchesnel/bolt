import { Candle, Tick, PriceState, Quote, DataQuality, Timeframe, TF_MINUTES } from './types';

// ---------------------------------------------------------------------------
// Market simulation — clearly labeled as simulated, NOT real XAUUSD data.
// This exists so the engine has something to analyze until a real feed is connected.
// ---------------------------------------------------------------------------

export interface SimConfig {
  startTime: number;
  ticksPerMinute: number;
  durationMinutes: number;
  basePrice: number;
  seed: number;
}

export interface SimResult {
  ticks: Tick[];
}

function mulberry32(seed: number): () => number {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function simulateMarket(config: SimConfig): SimResult {
  const rng = mulberry32(config.seed);
  const totalTicks = config.ticksPerMinute * config.durationMinutes;
  const tickMs = 60000 / config.ticksPerMinute;
  const ticks: Tick[] = [];

  let price = config.basePrice;
  let momentum = 0;
  const regimes = [
    { vol: 0.35, drift: 0.0008 },
    { vol: 0.55, drift: -0.0012 },
    { vol: 0.7, drift: 0.0022 },
    { vol: 0.4, drift: 0.0005 },
  ];

  for (let i = 0; i < totalTicks; i++) {
    const regime = regimes[Math.floor(i / (totalTicks / regimes.length)) % regimes.length];
    const shock = (rng() - 0.5) * 2 * regime.vol;
    momentum = Math.max(-1.2, Math.min(1.2, momentum * 0.82 + shock * 0.35 + regime.drift));
    price += momentum;

    // Occasional news spike
    if (rng() < 0.004) price += (rng() - 0.5) * 4 * regime.vol;

    const buyBias = momentum > 0
      ? 0.55 + Math.abs(momentum) * 0.1
      : 0.45 - Math.abs(momentum) * 0.05;
    const vol = Math.max(0.5, 1 + Math.abs(momentum) * 3 + rng() * 2);
    const buy = vol * Math.min(0.85, Math.max(0.15, buyBias + (rng() - 0.5) * 0.2));

    ticks.push({
      time: config.startTime + i * tickMs,
      price: Math.round(price * 100) / 100,
      volume: vol,
      buyVolume: buy,
      sellVolume: vol - buy,
    });
  }

  return { ticks };
}

// ---------------------------------------------------------------------------
// Aggregate ticks into candles for a given timeframe
// ---------------------------------------------------------------------------

export function aggregateCandles(ticks: Tick[], tf: Timeframe): Candle[] {
  const bucketMs = TF_MINUTES[tf] * 60 * 1000;
  const map = new Map<number, Candle>();
  for (const t of ticks) {
    const bucket = Math.floor(t.time / bucketMs) * bucketMs;
    let c = map.get(bucket);
    if (!c) {
      c = { time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: 0, buyVolume: 0, sellVolume: 0 };
      map.set(bucket, c);
    }
    c.close = t.price;
    c.high = Math.max(c.high, t.price);
    c.low = Math.min(c.low, t.price);
    c.volume += t.volume;
    c.buyVolume += t.buyVolume;
    c.sellVolume += t.sellVolume;
  }
  return Array.from(map.values()).sort((a, b) => a.time - b.time);
}

// ---------------------------------------------------------------------------
// Quotes / price state — simulated providers, clearly labeled
// ---------------------------------------------------------------------------

export function quotesFromTicks(price: number, time: number, rng: () => number): Quote[] {
  const spread = 0.18 + rng() * 0.12;
  return [
    { provider: 'BrokerA', bid: price - spread / 2, ask: price + spread / 2, quality: 82 + Math.round(rng() * 12), tickRate: 3 + rng() * 2, illustrative: true },
    { provider: 'BrokerB', bid: price - spread / 2 - 0.02, ask: price + spread / 2 - 0.01, quality: 78 + Math.round(rng() * 14), tickRate: 2.5 + rng() * 2, illustrative: true },
    { provider: 'BrokerC', bid: price - spread / 2 + 0.01, ask: price + spread / 2 + 0.02, quality: 75 + Math.round(rng() * 16), tickRate: 2 + rng() * 2, illustrative: true },
    { provider: 'RefDataX', bid: price - spread / 2 - 0.005, ask: price + spread / 2 + 0.005, quality: 85 + Math.round(rng() * 10), tickRate: 4 + rng() * 2, illustrative: true },
  ];
}

export function computePriceState(quotes: Quote[], time: number): PriceState {
  const bids = quotes.map(q => q.bid);
  const asks = quotes.map(q => q.ask);
  const median = (Math.max(...bids) + Math.min(...asks)) / 2;
  const spread = Math.min(...asks) - Math.max(...bids);
  const maxDivergence = Math.max(...asks) - Math.min(...bids);
  return { median, spread, maxDivergence, quotes };
}

export function computeDataQuality(quotes: Quote[]): DataQuality {
  const avgQuality = quotes.reduce((s, q) => s + q.quality, 0) / quotes.length;
  const allIllustrative = quotes.every(q => q.illustrative);
  if (allIllustrative) {
    return {
      score: Math.round(avgQuality * 0.6),
      status: 'DEGRADED',
      reason: 'All feeds are simulated — not real market data',
    };
  }
  if (avgQuality > 80) return { score: Math.round(avgQuality), status: 'VALID', reason: 'Feeds nominal' };
  if (avgQuality > 60) return { score: Math.round(avgQuality), status: 'DEGRADED', reason: 'Some feeds degraded' };
  return { score: Math.round(avgQuality), status: 'INVALID', reason: 'Feed quality critical' };
}
