import {
  MarketSnapshot, TradePlan, AgentOpinion, Scenario, StructureState,
  MicrostructureState, VolumeProfileState, VWAPState, CorrelationState,
  OptionsState, MacroEvent, NewsItem, GeoEvent, Alert, DecisionStatus,
  Timeframe, Candle, StructureBias,
} from './types';

// ---------------------------------------------------------------------------
// Agent opinions — each specialist produces an independent score
// ---------------------------------------------------------------------------

interface AgentInput {
  structure: Record<Timeframe, StructureState>;
  microstructure: MicrostructureState;
  volumeProfile: VolumeProfileState;
  vwap: VWAPState;
  correlations: CorrelationState;
  options: OptionsState;
  macro: MacroEvent[];
  news: NewsItem[];
  geo: GeoEvent[];
  currentPrice: number;
}

function structureAgent(input: AgentInput): AgentOpinion {
  const h4 = input.structure['H4'];
  const h1 = input.structure['H1'];
  const m15 = input.structure['M15'];
  const m5 = input.structure['M5'];

  let score = 0;
  let dir = 0;
  const notes: string[] = [];

  // HTF bias alignment
  if (h4.bias === 'bullish' && h1.bias === 'bullish') { score += 0.25; dir += 1; notes.push('H4+H1 bullish aligned'); }
  else if (h4.bias === 'bearish' && h1.bias === 'bearish') { score += 0.25; dir -= 1; notes.push('H4+H1 bearish aligned'); }
  else if (h4.bias === 'ranging' || h1.bias === 'ranging') { notes.push('HTF ranging'); }

  // LTF confirmation
  if (m15.bias === 'bullish' && m5.bias === 'bullish' && dir > 0) { score += 0.15; notes.push('M15+M5 confirm bullish'); }
  else if (m15.bias === 'bearish' && m5.bias === 'bearish' && dir < 0) { score += 0.15; notes.push('M15+M5 confirm bearish'); }
  else if (m15.bias !== 'undefined' && m5.bias !== 'undefined') {
    if (Math.sign(dir) !== Math.sign(m15.bias === 'bullish' ? 1 : m15.bias === 'bearish' ? -1 : 0)) {
      notes.push('LTF contradicts HTF');
      score *= 0.5;
    }
  }

  // Structure events
  if (m5.lastEvent) {
    if (m5.lastEvent.type === 'MSS' && m5.lastEvent.direction === 'bullish') { score += 0.2; dir += 0.5; notes.push('M5 MSS bullish'); }
    else if (m5.lastEvent.type === 'MSS' && m5.lastEvent.direction === 'bearish') { score += 0.2; dir -= 0.5; notes.push('M5 MSS bearish'); }
    else if (m5.lastEvent.type === 'CHOCH') { score += 0.1; notes.push(`M5 CHOCH ${m5.lastEvent.direction}`); }
    else if (m5.lastEvent.type === 'BOS') { score += 0.08; notes.push(`M5 BOS ${m5.lastEvent.direction}`); }
  }

  return {
    agent: 'Structure',
    direction: Math.sign(dir),
    raw: Math.max(-1, Math.min(1, dir * score)),
    weight: 0.25,
    note: notes.join('; ') || 'No clear structure',
    available: true,
  };
}

function liquidityAgent(input: AgentInput): AgentOpinion {
  // FIX: liquidity target (draw on liquidity) is SEPARATE from trade direction.
  // We identify WHERE the nearest unswept liquidity is, and whether it's been swept.
  // The DIRECTION comes from the full setup context, not from "nearest pool = direction".
  const m5 = input.structure['M5'];
  const m15 = input.structure['M15'];
  const pools = [...(m5.liquidity || []), ...(m15.liquidity || [])];
  const unswept = pools.filter(p => !p.swept);
  const swept = pools.filter(p => p.swept);

  if (unswept.length === 0) {
    return { agent: 'Liquidity', direction: 0, raw: 0, weight: 0.15, note: 'No unswept liquidity pools detected', available: true };
  }

  // Find nearest above and below
  const above = unswept.filter(p => p.side === 'above').sort((a, b) => a.price - b.price);
  const below = unswept.filter(p => p.side === 'below').sort((a, b) => b.price - a.price);
  const nearestAbove = above[0];
  const nearestBelow = below[0];

  let dir = 0;
  let score = 0;
  const notes: string[] = [];

  // Check if a sweep just occurred (pool was swept recently)
  if (swept.length > 0) {
    const recentSweep = swept[swept.length - 1];
    if (recentSweep.side === 'above') {
      // BSL swept — price likely heading down now toward SSL
      dir = -1;
      score = 0.3;
      notes.push('BSL swept — draw to SSL below');
    } else {
      // SSL swept — price likely heading up now toward BSL
      dir = 1;
      score = 0.3;
      notes.push('SSL swept — draw to BSL above');
    }
  } else {
    // No sweep yet — price tends to move toward the nearest unswept pool
    // But this is a TARGET, not a trade direction by itself
    if (nearestAbove && (!nearestBelow || Math.abs(nearestAbove.price - input.currentPrice) < Math.abs(nearestBelow.price - input.currentPrice))) {
      dir = 0.3; // mild bullish bias — draw on liquidity above
      score = 0.15;
      notes.push(`Draw on liquidity above @ ${nearestAbove.price.toFixed(1)} (${nearestAbove.type})`);
    } else if (nearestBelow) {
      dir = -0.3;
      score = 0.15;
      notes.push(`Draw on liquidity below @ ${nearestBelow.price.toFixed(1)} (${nearestBelow.type})`);
    }
  }

  return {
    agent: 'Liquidity',
    direction: Math.sign(dir),
    raw: dir * score,
    weight: 0.15,
    note: notes.join('; '),
    available: true,
  };
}

function microstructureAgent(input: AgentInput): AgentOpinion {
  const ms = input.microstructure;
  let dir = 0;
  let score = 0;
  const notes: string[] = [];

  if (ms.ofi > 0.15) { dir += 0.5; score += 0.2; notes.push('OFI bullish'); }
  else if (ms.ofi < -0.15) { dir -= 0.5; score += 0.2; notes.push('OFI bearish'); }

  if (ms.divergence === 'bearish' && dir > 0) { score *= 0.5; notes.push('CVD divergence (bearish)'); }
  else if (ms.divergence === 'bullish' && dir < 0) { score *= 0.5; notes.push('CVD divergence (bullish)'); }

  if (ms.absorption) {
    if (ms.absorption.side === 'buy') { dir += 0.3; score += 0.15; notes.push('Buy absorption'); }
    else { dir -= 0.3; score += 0.15; notes.push('Sell absorption'); }
  }

  if (ms.sweep) {
    if (ms.sweep.side === 'above') { dir -= 0.3; score += 0.1; notes.push('Sweep above (rejection)'); }
    else { dir += 0.3; score += 0.1; notes.push('Sweep below (rejection)'); }
  }

  if (ms.exhaustion) {
    if (ms.exhaustion.side === 'buy') { dir -= 0.2; notes.push('Buy exhaustion'); }
    else { dir += 0.2; notes.push('Sell exhaustion'); }
  }

  return {
    agent: 'Microstructure',
    direction: Math.sign(dir),
    raw: Math.max(-1, Math.min(1, dir * score)),
    weight: 0.15,
    note: notes.join('; ') || 'No significant microstructure events',
    available: true,
  };
}

function volumeProfileAgent(input: AgentInput): AgentOpinion {
  const vp = input.volumeProfile;
  const price = input.currentPrice;
  let dir = 0;
  let score = 0;
  const notes: string[] = [];

  if (price < vp.val) { dir += 0.3; score += 0.15; notes.push('Below VAL — discount'); }
  else if (price > vp.vah) { dir -= 0.3; score += 0.15; notes.push('Above VAH — premium'); }

  if (price < vp.poc) { dir += 0.1; notes.push('Below POC'); }
  else if (price > vp.poc) { dir -= 0.1; notes.push('Above POC'); }

  return {
    agent: 'VolumeProfile',
    direction: Math.sign(dir),
    raw: Math.max(-1, Math.min(1, dir * score)),
    weight: 0.1,
    note: notes.join('; ') || 'Price at value',
    available: true,
  };
}

function vwapAgent(input: AgentInput): AgentOpinion {
  const vwap = input.vwap.session;
  const price = input.currentPrice;
  let dir = 0;
  let score = 0;
  const notes: string[] = [];

  if (vwap > 0) {
    const dev = (price - vwap) / vwap;
    if (dev < -0.001) { dir = 0.5; score = 0.15; notes.push('Below session VWAP'); }
    else if (dev > 0.001) { dir = -0.5; score = 0.15; notes.push('Above session VWAP'); }
    else { notes.push('At session VWAP'); }
  }

  return {
    agent: 'VWAP',
    direction: Math.sign(dir),
    raw: Math.max(-1, Math.min(1, dir * score)),
    weight: 0.1,
    note: notes.join('; '),
    available: vwap > 0,
  };
}

function correlationAgent(input: AgentInput): AgentOpinion {
  // HONEST: no external feed → neutral, not fabricated confirmation
  if (!input.correlations.available) {
    return {
      agent: 'Correlations',
      direction: 0,
      raw: 0,
      weight: 0.1,
      note: 'Feed unavailable — neutral (no fabricated confirmation)',
      available: false,
    };
  }
  // When feed is connected, this will use real DXY/yields
  return { agent: 'Correlations', direction: 0, raw: 0, weight: 0.1, note: 'Feed connected', available: true };
}

function optionsAgent(input: AgentInput): AgentOpinion {
  // HONEST: no options feed → neutral
  if (!input.options.available) {
    return {
      agent: 'Options',
      direction: 0,
      raw: 0,
      weight: 0.08,
      note: 'Options feed unavailable — neutral',
      available: false,
    };
  }
  return { agent: 'Options', direction: 0, raw: 0, weight: 0.08, note: 'Options feed connected', available: true };
}

function macroAgent(input: AgentInput): AgentOpinion {
  const highImpact = input.macro.find(e => e.impact === 'high' && e.minutesUntil < 60);
  if (highImpact) {
    return {
      agent: 'Macro',
      direction: 0,
      raw: 0,
      weight: 0.07,
      note: `High-impact event ${highImpact.name} in ${highImpact.minutesUntil}min — reduce risk`,
      available: true,
    };
  }
  return { agent: 'Macro', direction: 0, raw: 0, weight: 0.07, note: 'No imminent high-impact events', available: true };
}

// ---------------------------------------------------------------------------
// Scenario builder — builds independent BULL and BEAR scenarios
// FIX: the principal scenario is whichever has the higher probability,
// not hardcoded BUY.
// ---------------------------------------------------------------------------

function buildScenarios(
  agents: AgentOpinion[],
  structure: Record<Timeframe, StructureState>,
  currentPrice: number,
): Scenario[] {
  const buyScore = agents.reduce((s, a) => s + (a.raw > 0 ? a.raw * a.weight : 0), 0);
  const sellScore = agents.reduce((s, a) => s + (s, 0) + (a.raw < 0 ? Math.abs(a.raw) * a.weight : 0), 0);

  // Normalize to probabilities
  const total = buyScore + sellScore;
  const buyProb = total > 0 ? buyScore / total : 0.5;
  const sellProb = total > 0 ? sellScore / total : 0.5;

  // Build targets from liquidity pools
  const m5 = structure['M5'];
  const m15 = structure['M15'];
  const pools = [...(m5.liquidity || []), ...(m15.liquidity || [])];

  const abovePools = pools.filter(p => p.side === 'above' && !p.swept).sort((a, b) => a.price - b.price);
  const belowPools = pools.filter(p => p.side === 'below' && !p.swept).sort((a, b) => b.price - a.price);

  const buyTargets = abovePools.slice(0, 3).map(p => p.price);
  const sellTargets = belowPools.slice(0, 3).map(p => p.price);

  // Fill targets if not enough pools
  while (buyTargets.length < 3) buyTargets.push(currentPrice + (3 - buyTargets.length) * 5);
  while (sellTargets.length < 3) sellTargets.push(currentPrice - (3 - sellTargets.length) * 5);

  const bullScenario: Scenario = {
    name: 'Bullish',
    direction: 1,
    probability: buyProb,
    trigger: 'M5 bullish MSS + FVG retest in discount zone',
    targets: buyTargets,
    note: buyProb > sellProb ? 'Principal scenario — higher probability' : 'Alternative scenario',
    isPrincipal: buyProb >= sellProb,
  };

  const bearScenario: Scenario = {
    name: 'Bearish',
    direction: -1,
    probability: sellProb,
    trigger: 'M5 bearish MSS + FVG retest in premium zone',
    targets: sellTargets,
    note: sellProb > buyProb ? 'Principal scenario — higher probability' : 'Alternative scenario',
    isPrincipal: sellProb > buyProb,
  };

  // Sort so principal is first
  return [bullScenario, bearScenario].sort((a, b) => {
    if (a.isPrincipal && !b.isPrincipal) return -1;
    if (!a.isPrincipal && b.isPrincipal) return 1;
    return b.probability - a.probability;
  });
}

// ---------------------------------------------------------------------------
// Trade plan builder
// ---------------------------------------------------------------------------

function determineRegime(structure: Record<Timeframe, StructureState>): string {
  const h4 = structure['H4'];
  const m15 = structure['M15'];
  if (h4.bias === 'bullish' && m15.bias === 'bullish') return 'Trend Up';
  if (h4.bias === 'bearish' && m15.bias === 'bearish') return 'Trend Down';
  if (h4.bias === 'ranging' || m15.bias === 'ranging') return 'Ranging';
  if (h4.bias === 'bullish' && m15.bias === 'bearish') return 'Mixed (HTF up, LTF down)';
  if (h4.bias === 'bearish' && m15.bias === 'bullish') return 'Mixed (HTF down, LTF up)';
  return 'Undefined';
}

function computeDrawOnLiquidity(structure: Record<Timeframe, StructureState>, currentPrice: number): 'above' | 'below' | 'none' {
  const m5 = structure['M5'];
  const m15 = structure['M15'];
  const pools = [...(m5.liquidity || []), ...(m15.liquidity || [])];
  const unswept = pools.filter(p => !p.swept);
  if (unswept.length === 0) return 'none';

  const above = unswept.filter(p => p.side === 'above').sort((a, b) => a.price - b.price);
  const below = unswept.filter(p => p.side === 'below').sort((a, b) => b.price - a.price);

  // Check if a sweep just happened — then the draw is to the opposite side
  const swept = pools.filter(p => p.swept);
  if (swept.length > 0) {
    const lastSwept = swept[swept.length - 1];
    if (lastSwept.side === 'above') return 'below'; // BSL swept → draw to SSL
    return 'above';
  }

  // Otherwise, nearest unswept pool
  if (above.length > 0 && below.length > 0) {
    return Math.abs(above[0].price - currentPrice) < Math.abs(below[0].price - currentPrice) ? 'above' : 'below';
  }
  if (above.length > 0) return 'above';
  if (below.length > 0) return 'below';
  return 'none';
}

export function buildTradePlan(
  agents: AgentOpinion[],
  scenarios: Scenario[],
  structure: Record<Timeframe, StructureState>,
  microstructure: MicrostructureState,
  correlations: CorrelationState,
  options: OptionsState,
  macro: MacroEvent[],
  news: NewsItem[],
  currentPrice: number,
  timestamp: number,
): TradePlan {
  // FIX: compute independent BUY, SELL, NO_TRADE scores
  const buyScore = Math.round(agents.reduce((s, a) => s + (a.raw > 0 ? a.raw * a.weight : 0), 0) * 100);
  const sellScore = Math.round(agents.reduce((s, a) => s + (a.raw < 0 ? Math.abs(a.raw) * a.weight : 0), 0) * 100);
  const maxScore = Math.max(buyScore, sellScore);
  const noTradeScore = Math.max(0, 100 - maxScore * 2);

  // The principal scenario is whichever has the higher probability
  const principal = scenarios.find(s => s.isPrincipal) ?? scenarios[0];
  const direction = principal.direction;
  const confidence = principal.probability;

  // Determine status
  let status: DecisionStatus = 'NO_TRADE';
  const conflicts: string[] = [];
  const decisionTree: string[] = [];

  // Decision tree
  const h4 = structure['H4'];
  const h1 = structure['H1'];
  const m15 = structure['M15'];
  const m5 = structure['M5'];

  decisionTree.push(`H4 bias: ${h4.bias.toUpperCase()}`);
  decisionTree.push(`H1 bias: ${h1.bias.toUpperCase()}`);
  decisionTree.push(`M15 structure: ${m15.bias.toUpperCase()}${m15.lastEvent ? ' — ' + m15.lastEvent.type + ' ' + m15.lastEvent.direction : ''}`);
  decisionTree.push(`M5 trigger: ${m5.bias.toUpperCase()}${m5.lastEvent ? ' — ' + m5.lastEvent.type + ' ' + m5.lastEvent.direction : ''}`);

  const drawOnLiquidity = computeDrawOnLiquidity(structure, currentPrice);
  decisionTree.push(`Draw on liquidity: ${drawOnLiquidity.toUpperCase()}`);

  // Check for conflicts
  if (h4.bias !== 'undefined' && h1.bias !== 'undefined' && h4.bias !== h1.bias) {
    conflicts.push(`HTF conflict: H4=${h4.bias} vs H1=${h1.bias}`);
  }
  if (m15.bias !== 'undefined' && m5.bias !== 'undefined' && m15.bias !== m5.bias) {
    conflicts.push(`LTF conflict: M15=${m15.bias} vs M5=${m5.bias}`);
  }

  // Check for fresh FVG in the trade direction
  const freshFvg = m5.fvgs.find(f => f.fresh && ((direction > 0 && f.direction === 'bullish') || (direction < 0 && f.direction === 'bearish')));
  if (!freshFvg) {
    conflicts.push('No fresh FVG in trade direction on M5');
  }

  // Check for displacement / MSS
  const hasMSS = m5.lastEvent?.type === 'MSS' && m5.lastEvent.direction === (direction > 0 ? 'bullish' : 'bearish');
  const hasCHOCH = m5.lastEvent?.type === 'CHOCH' && m5.lastEvent.direction === (direction > 0 ? 'bullish' : 'bearish');
  if (!hasMSS && !hasCHOCH) {
    conflicts.push('No MSS/CHOCH confirmation on M5');
  }

  // Macro risk
  const highImpactSoon = macro.find(e => e.impact === 'high' && e.minutesUntil < 60);
  if (highImpactSoon) {
    conflicts.push(`High-impact macro event in ${highImpactSoon.minutesUntil}min`);
  }

  // Determine status based on score and conflicts
  const strongEnough = maxScore >= 35;
  const noMajorConflicts = conflicts.length <= 1;

  if (strongEnough && conflicts.length === 0 && hasMSS) {
    status = 'EXECUTE';
  } else if (strongEnough && noMajorConflicts && (hasMSS || hasCHOCH)) {
    status = 'READY';
  } else if (maxScore >= 20 && conflicts.length <= 3) {
    status = 'MONITOR';
  } else if (maxScore >= 10) {
    status = 'WAIT';
  } else {
    status = 'NO_TRADE';
  }

  // If NO_TRADE, override direction to 0 but keep scores visible
  const planDirection = status === 'NO_TRADE' ? 0 : direction;

  // Build entry/stop/targets
  const atr = m5.dealingRange ? (m5.dealingRange.top - m5.dealingRange.bottom) * 0.1 : 2;
  const entry: [number, number] = direction > 0
    ? [currentPrice - atr * 0.3, currentPrice + atr * 0.2]
    : [currentPrice - atr * 0.2, currentPrice + atr * 0.3];
  const stop = direction > 0 ? currentPrice - atr * 1.5 : currentPrice + atr * 1.5;
  const risk = Math.abs(currentPrice - stop);
  const targets: [number, number, number] = direction > 0
    ? [currentPrice + risk * 1, currentPrice + risk * 2, currentPrice + risk * 3]
    : [currentPrice - risk * 1, currentPrice - risk * 2, currentPrice - risk * 3];
  const rR: [number, number, number] = [1, 2, 3];

  // Expected value (heuristic — NOT calibrated)
  const ev = confidence * (rR[0] * 0.4 + rR[1] * 0.3 + rR[2] * 0.3) - (1 - confidence) * 1;

  // Zone of interest
  const zone: [number, number] = direction > 0
    ? [currentPrice - atr * 0.5, currentPrice + atr * 0.5]
    : [currentPrice - atr * 0.5, currentPrice + atr * 0.5];

  // Trigger description
  const trigger = direction > 0
    ? 'M5 bullish MSS + FVG retest in discount, then M1 entry trigger'
    : direction < 0
    ? 'M5 bearish MSS + FVG retest in premium, then M1 entry trigger'
    : 'No valid trigger — insufficient confluence';

  // Invalidation
  const invalidation = direction > 0
    ? `Close below ${stop.toFixed(2)} (structure invalidation)`
    : direction < 0
    ? `Close above ${stop.toFixed(2)} (structure invalidation)`
    : 'N/A — no active setup';

  // Next news
  const nextNews = macro.length > 0
    ? `${macro[0].name} in ${macro[0].minutesUntil}min`
    : 'None scheduled';

  // Action
  let action = '';
  switch (status) {
    case 'EXECUTE': action = `Execute ${direction > 0 ? 'BUY' : 'SELL'} — all conditions met`; break;
    case 'READY': action = `Ready — awaiting final M1 trigger for ${direction > 0 ? 'BUY' : 'SELL'}`; break;
    case 'MONITOR': action = 'Monitor — setup forming but not yet complete'; break;
    case 'WAIT': action = 'Wait — insufficient confluence or pending confirmation'; break;
    case 'NO_TRADE': action = 'NO TRADE — conditions not met, do not force an entry'; break;
  }

  // Generate setup_id — stable identifier for this setup
  const session = new Date(timestamp).getUTCHours() < 12 ? 'LDN' : 'NY';
  const dateStr = new Date(timestamp).toISOString().slice(0, 10).replace(/-/g, '');
  const setupId = `XAUUSD-${session}-${dateStr}-${String(Math.floor(timestamp / 60000) % 1000).padStart(3, '0')}`;

  return {
    status,
    direction: planDirection,
    confidence,
    regimeLabel: determineRegime(structure),
    ev: Math.round(ev * 100) / 100,
    zone,
    trigger,
    entry,
    stop,
    targets,
    rR,
    invalidation,
    nextNews,
    action,
    agents,
    scenarios,
    conflicts,
    decisionTree,
    buyScore,
    sellScore,
    noTradeScore,
    setupId,
    drawOnLiquidity,
  };
}

// ---------------------------------------------------------------------------
// Main decision pipeline
// ---------------------------------------------------------------------------

export function runDecision(
  structure: Record<Timeframe, StructureState>,
  microstructure: MicrostructureState,
  volumeProfile: VolumeProfileState,
  vwap: VWAPState,
  correlations: CorrelationState,
  options: OptionsState,
  macro: MacroEvent[],
  news: NewsItem[],
  geo: GeoEvent[],
  currentPrice: number,
  timestamp: number,
): TradePlan {
  const input: AgentInput = {
    structure, microstructure, volumeProfile, vwap, correlations, options, macro, news, geo, currentPrice,
  };

  const agents: AgentOpinion[] = [
    structureAgent(input),
    liquidityAgent(input),
    microstructureAgent(input),
    volumeProfileAgent(input),
    vwapAgent(input),
    correlationAgent(input),
    optionsAgent(input),
    macroAgent(input),
  ];

  const scenarios = buildScenarios(agents, structure, currentPrice);
  const plan = buildTradePlan(agents, scenarios, structure, microstructure, correlations, options, macro, news, currentPrice, timestamp);

  return plan;
}
