// ============================================================================
// Core type definitions for the XAU/USD Quant Engine
// ============================================================================

export type Timeframe = 'M1' | 'M5' | 'M15' | 'M30' | 'H1' | 'H4' | 'D1' | 'W1';

export const ALL_TIMEFRAMES: Timeframe[] = ['M1', 'M5', 'M15', 'M30', 'H1', 'H4', 'D1', 'W1'];

export const TF_MINUTES: Record<Timeframe, number> = {
  M1: 1, M5: 5, M15: 15, M30: 30, H1: 60, H4: 240, D1: 1440, W1: 10080,
};

// ---------------------------------------------------------------------------
// Candle / Tick primitives
// ---------------------------------------------------------------------------

export interface Candle {
  time: number;       // bucket start time (ms epoch)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  buyVolume: number;
  sellVolume: number;
}

export interface Tick {
  time: number;
  price: number;
  volume: number;
  buyVolume: number;
  sellVolume: number;
}

// ---------------------------------------------------------------------------
// Market structure (ICT / SMC)
// ---------------------------------------------------------------------------

export type StructureBias = 'bullish' | 'bearish' | 'ranging' | 'undefined';
export type StructureEvent = 'BOS' | 'CHOCH' | 'MSS' | 'none';

export interface SwingPoint {
  time: number;
  price: number;
  type: 'high' | 'low';
  class: 'minor' | 'major' | 'intermediate';
  strength: number;   // 0..1 — how prominent the swing is
}

export interface FVG {
  id: string;
  top: number;
  bottom: number;
  direction: 'bullish' | 'bearish';
  createdAt: number;     // time of the gap's middle candle
  filled: boolean;
  fillRatio: number;     // 0..1 — how much of the gap has been mitigated
  fresh: boolean;       // true if not yet touched (fillRatio === 0)
}

export interface OrderBlock {
  id: string;
  top: number;
  bottom: number;
  direction: 'bullish' | 'bearish';
  createdAt: number;
  mitigated: boolean;
  type: 'OB' | 'breaker' | 'mitigation';
}

export interface LiquidityPool {
  id: string;
  price: number;
  side: 'above' | 'below';   // relative to current price
  type: 'BSL' | 'SSL' | 'PDH' | 'PDL' | 'PWH' | 'PWL' | 'session_high' | 'session_low' | 'EQH' | 'EQL';
  strength: number;   // 0..1
  swept: boolean;
  sweptAt?: number;
}

export interface StructureState {
  bias: StructureBias;
  lastEvent: { type: StructureEvent; direction: 'bullish' | 'bearish'; time: number; price: number } | null;
  swings: SwingPoint[];
  fvgs: FVG[];
  orderBlocks: OrderBlock[];
  liquidity: LiquidityPool[];
  dealingRange: { top: number; bottom: number } | null;
  premium: boolean;
  discount: boolean;
  equilibrium: number;
  noise: number;        // 0..1 — how choppy the structure is
}

// ---------------------------------------------------------------------------
// Microstructure
// ---------------------------------------------------------------------------

export interface MicrostructureState {
  ofi: number;          // order flow imbalance
  delta: number;        // buy - sell volume (recent window)
  cvd: number;          // cumulative volume delta
  divergence: 'none' | 'bullish' | 'bearish';
  absorption: { side: 'buy' | 'sell'; zone: [number, number]; confidence: number } | null;
  sweep: { side: 'above' | 'below'; level: number } | null;
  exhaustion: { side: 'buy' | 'sell'; level: number } | null;
}

// ---------------------------------------------------------------------------
// Volume profile
// ---------------------------------------------------------------------------

export interface VolumeProfileState {
  poc: number;           // point of control
  vah: number;           // value area high
  val: number;           // value area low
  valueArea: [number, number];
  initialBalance: [number, number];
  hvn: number[];         // high volume nodes
  lvn: number[];         // low volume nodes
}

// ---------------------------------------------------------------------------
// VWAP
// ---------------------------------------------------------------------------

export interface VWAPState {
  daily: number;
  weekly: number;
  session: number;
  anchored: number;
}

// ---------------------------------------------------------------------------
// Correlations (external — honest about availability)
// ---------------------------------------------------------------------------

export interface CorrelationState {
  dxy: number;            // 0 = unavailable
  realYields10y: number;  // 0 = unavailable
  silver: number;         // 0 = unavailable
  vix: number;            // 0 = unavailable
  broken: boolean;        // correlation regime break detected
  regimeNote: string;
  available: boolean;     // false when no external feed connected
}

// ---------------------------------------------------------------------------
// Options (external — honest about availability)
// ---------------------------------------------------------------------------

export interface OptionsState {
  ivATM: number;          // 0 = unavailable
  skew: 'bullish' | 'bearish' | 'neutral' | 'unavailable';
  skewChange24h: number;
  skewPercentile: number;
  walls: number[];
  pinning: number[];
  note: string;
  available: boolean;
}

// ---------------------------------------------------------------------------
// Macro / News / Geo (clearly labeled as illustrative)
// ---------------------------------------------------------------------------

export interface MacroEvent {
  name: string;
  impact: 'high' | 'medium' | 'low';
  minutesUntil: number;
  consensus: string;
  illustrative: boolean;
}

export interface NewsItem {
  headline: string;
  source: string;
  sourceLevel: 1 | 2 | 3;
  novelty: string;
  marketImpact: string;
  direction: number;   // -1, 0, +1
  illustrative: boolean;
}

export interface GeoEvent {
  eventType: string;
  location: string;
  source: string;
  score: number;        // 0..100 risk
  severity: number;     // 0..1
  escalationProbability: number;  // 0..1
  grossImpact: 'bullish' | 'bearish' | 'neutral';
  netImpact: 'bullish' | 'bearish' | 'neutral';
  illustrative: boolean;
}

// ---------------------------------------------------------------------------
// Price / Data quality
// ---------------------------------------------------------------------------

export interface Quote {
  provider: string;
  bid: number;
  ask: number;
  quality: number;     // 0..100
  tickRate: number;
  illustrative: boolean;
}

export interface PriceState {
  median: number;
  spread: number;
  maxDivergence: number;
  quotes: Quote[];
}

export interface DataQuality {
  score: number;
  status: 'VALID' | 'DEGRADED' | 'INVALID';
  reason: string;
}

// ---------------------------------------------------------------------------
// Alerts
// ---------------------------------------------------------------------------

export interface Alert {
  id: string;
  severity: 'critical' | 'warning' | 'info';
  message: string;
}

// ---------------------------------------------------------------------------
// Decision / Plan
// ---------------------------------------------------------------------------

export type DecisionStatus = 'NO_TRADE' | 'WAIT' | 'MONITOR' | 'READY' | 'EXECUTE';

export interface AgentOpinion {
  agent: string;
  direction: number;   // -1..+1
  raw: number;         // raw score
  weight: number;      // 0..1
  note: string;
  available: boolean;  // false if feed unavailable
}

export interface Scenario {
  name: string;
  direction: number;   // +1 buy, -1 sell
  probability: number; // 0..1 (heuristic)
  trigger: string;
  targets: number[];
  note: string;
  isPrincipal: boolean;
}

export interface TradePlan {
  status: DecisionStatus;
  direction: number;       // +1, -1, 0
  confidence: number;      // 0..1 (heuristic, NOT calibrated)
  regimeLabel: string;
  ev: number;              // expected value in R
  zone: [number, number];
  trigger: string;
  entry: [number, number];
  stop: number;
  targets: [number, number, number];
  rR: [number, number, number];
  invalidation: string;
  nextNews: string;
  action: string;
  agents: AgentOpinion[];
  scenarios: Scenario[];
  conflicts: string[];
  decisionTree: string[];
  buyScore: number;
  sellScore: number;
  noTradeScore: number;
  setupId: string;
  drawOnLiquidity: 'above' | 'below' | 'none';
}

// ---------------------------------------------------------------------------
// Full snapshot
// ---------------------------------------------------------------------------

export interface MarketSnapshot {
  timestamp: number;
  price: PriceState;
  quality: DataQuality;
  candles: Record<Timeframe, Candle[]>;
  structure: Record<Timeframe, StructureState>;
  microstructure: MicrostructureState;
  volumeProfile: VolumeProfileState;
  vwap: VWAPState;
  correlations: CorrelationState;
  options: OptionsState;
  macro: MacroEvent[];
  news: NewsItem[];
  geo: GeoEvent[];
  alerts: Alert[];
  plan: TradePlan;
}

// ---------------------------------------------------------------------------
// Journal (Supabase)
// ---------------------------------------------------------------------------

export interface JournalEntry {
  setup_id: string;
  symbol: string;
  created_at: string;
  first_detected_at: string;
  direction: 'BUY' | 'SELL' | 'NEUTRAL';
  status_at_prediction: string;
  price_at_prediction: number;
  entry_min: number;
  entry_max: number;
  stop: number;
  tp1: number;
  tp2: number;
  tp3: number;
  confidence: number;
  buy_score: number;
  sell_score: number;
  no_trade_score: number;
  regime: string;
  h4_bias: string;
  h1_bias: string;
  m15_structure: string;
  m5_trigger: string;
  liquidity_target: string;
  liquidity_swept: boolean;
  bos: string | null;
  choch: string | null;
  mss: string | null;
  fvg: string | null;
  ifvg: string | null;
  ob: string | null;
  breaker: string | null;
  bpr: string | null;
  dxy: number | null;
  us10y: number | null;
  real_yield: number | null;
  macro_risk: string;
  news_risk: string;
  agents_snapshot: object;
  predicted_ev: number;
  triggered_at: string | null;
  entry_price: number | null;
  outcome: 'PENDING' | 'WIN' | 'LOSS' | 'BREAKEVEN' | 'EXPIRED' | null;
  exit_price: number | null;
  closed_at: string | null;
  mfe: number | null;
  mae: number | null;
  tp1_hit: boolean | null;
  tp2_hit: boolean | null;
  tp3_hit: boolean | null;
  sl_hit: boolean | null;
  r_realized: number | null;
}
