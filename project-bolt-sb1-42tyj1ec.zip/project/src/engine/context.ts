import { Candle, CorrelationState, OptionsState, MacroEvent, NewsItem, GeoEvent, Alert } from './types';

// ---------------------------------------------------------------------------
// Correlations — HONEST: no external feed connected, so all report unavailable.
// The circular logic (deriving DXY from gold's own price) has been removed.
// When a feed is connected, these functions will return real values.
// ---------------------------------------------------------------------------

export function computeCorrelations(): CorrelationState {
  return {
    dxy: 0,
    realYields10y: 0,
    silver: 0,
    vix: 0,
    broken: false,
    regimeNote: 'External feed not connected — correlations unavailable (neutral)',
    available: false,
  };
}

// ---------------------------------------------------------------------------
// Options — HONEST: no options feed connected.
// The fake skew/gamma/walls derived from candle data have been removed.
// ---------------------------------------------------------------------------

export function computeOptions(): OptionsState {
  return {
    ivATM: 0,
    skew: 'unavailable',
    skewChange24h: 0,
    skewPercentile: 0,
    walls: [],
    pinning: [],
    note: 'Options feed not connected — data unavailable',
    available: false,
  };
}

// ---------------------------------------------------------------------------
// Macro calendar — clearly labeled [ILLUSTRATIVE]
// ---------------------------------------------------------------------------

export function getMacroCalendar(currentTime: number): MacroEvent[] {
  return [
    { name: 'CPI [ILLUSTRATIVE]', impact: 'high', minutesUntil: 72, consensus: '+0.3% m/m', illustrative: true },
    { name: 'NFP [ILLUSTRATIVE]', impact: 'high', minutesUntil: 180, consensus: '+185k', illustrative: true },
    { name: 'FOMC [ILLUSTRATIVE]', impact: 'high', minutesUntil: 432, consensus: 'hold', illustrative: true },
    { name: 'Jobless Claims [ILLUSTRATIVE]', impact: 'medium', minutesUntil: 30, consensus: '221k', illustrative: true },
  ];
}

// ---------------------------------------------------------------------------
// News feed — clearly labeled [ILLUSTRATIVE]
// ---------------------------------------------------------------------------

export function getNewsFeed(): NewsItem[] {
  return [
    { headline: '[ILLUSTRATIVE] Fed officials signal data-dependent approach to rate cuts', source: 'Reuters', sourceLevel: 1, novelty: 'medium', marketImpact: 'moderate', direction: 1, illustrative: true },
    { headline: '[ILLUSTRATIVE] Dollar steadies ahead of CPI data', source: 'Bloomberg', sourceLevel: 1, novelty: 'low', marketImpact: 'low', direction: 0, illustrative: true },
    { headline: '[ILLUSTRATIVE] Gold holds near record high as yields ease', source: 'AP', sourceLevel: 1, novelty: 'low', marketImpact: 'low', direction: 1, illustrative: true },
  ];
}

// ---------------------------------------------------------------------------
// Geopolitical monitor — clearly labeled [ILLUSTRATIVE]
// ---------------------------------------------------------------------------

export function getGeoEvents(): GeoEvent[] {
  return [
    {
      eventType: 'maritime_incident',
      location: 'Gulf of Oman [ILLUSTRATIVE]',
      source: 'Reuters [ILLUSTRATIVE]',
      score: 45,
      severity: 0.4,
      escalationProbability: 0.3,
      grossImpact: 'bullish',
      netImpact: 'bullish',
      illustrative: true,
    },
  ];
}

// ---------------------------------------------------------------------------
// Alerts
// ---------------------------------------------------------------------------

export function generateAlerts(
  qualityScore: number,
  correlationState: CorrelationState,
  optionsState: OptionsState,
  macroEvents: MacroEvent[],
): Alert[] {
  const alerts: Alert[] = [];

  if (qualityScore < 60) {
    alerts.push({ id: 'data-quality', severity: 'critical', message: 'Data quality degraded — all feeds are simulated' });
  }

  if (!correlationState.available) {
    alerts.push({ id: 'correlations', severity: 'info', message: 'Correlation feeds (DXY, yields) not connected — neutral' });
  }

  if (!optionsState.available) {
    alerts.push({ id: 'options', severity: 'info', message: 'Options feed not connected — neutral' });
  }

  const highImpact = macroEvents.find(e => e.impact === 'high' && e.minutesUntil < 60);
  if (highImpact) {
    alerts.push({ id: 'macro-risk', severity: 'warning', message: `High-impact event ${highImpact.name} in ${highImpact.minutesUntil}min` });
  }

  return alerts;
}
