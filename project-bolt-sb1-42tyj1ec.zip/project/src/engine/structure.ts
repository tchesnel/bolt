import { Candle, SwingPoint, FVG, OrderBlock, LiquidityPool, StructureState, StructureBias, StructureEvent } from './types';

// ---------------------------------------------------------------------------
// Swing detection — fractal-based with configurable lookback
// ---------------------------------------------------------------------------

export function detectSwings(candles: Candle[], lookback = 3): SwingPoint[] {
  const swings: SwingPoint[] = [];
  for (let i = lookback; i < candles.length - lookback; i++) {
    const c = candles[i];
    let isHigh = true;
    let isLow = true;
    for (let j = i - lookback; j <= i + lookback; j++) {
      if (j === i) continue;
      if (candles[j].high >= c.high) isHigh = false;
      if (candles[j].low <= c.low) isLow = false;
    }
    if (isHigh) {
      const strength = Math.min(1, (c.high - candles.slice(i - lookback, i + lookback + 1).map(x => x.low).reduce((a, b) => Math.min(a, b), c.high)) / (c.high * 0.001));
      swings.push({ time: c.time, price: c.high, type: 'high', class: lookback >= 5 ? 'major' : lookback >= 3 ? 'intermediate' : 'minor', strength });
    }
    if (isLow) {
      const strength = Math.min(1, (candles.slice(i - lookback, i + lookback + 1).map(x => x.high).reduce((a, b) => Math.max(a, b), c.low) - c.low) / (c.low * 0.001));
      swings.push({ time: c.time, price: c.low, type: 'low', class: lookback >= 5 ? 'major' : lookback >= 3 ? 'intermediate' : 'minor', strength });
    }
  }
  return swings;
}

// ---------------------------------------------------------------------------
// BOS / CHOCH / MSS detection
// ---------------------------------------------------------------------------

export function detectStructureEvents(
  candles: Candle[],
  swings: SwingPoint[],
): { type: StructureEvent; direction: 'bullish' | 'bearish'; time: number; price: number } | null {
  if (swings.length < 4 || candles.length < 10) return null;

  const recentSwings = swings.slice(-6);
  const highs = recentSwings.filter(s => s.type === 'high').sort((a, b) => a.time - b.time);
  const lows = recentSwings.filter(s => s.type === 'low').sort((a, b) => a.time - b.time);

  if (highs.length < 2 || lows.length < 2) return null;

  const prevHigh = highs[highs.length - 2];
  const lastHigh = highs[highs.length - 1];
  const prevLow = lows[lows.length - 2];
  const lastLow = lows[lows.length - 1];

  const currentPrice = candles[candles.length - 1].close;
  const currentTime = candles[candles.length - 1].time;

  // Bullish BOS: price breaks above previous swing high, and lastHigh is more recent than prevHigh
  if (currentPrice > prevHigh.price && lastHigh.time > prevHigh.time) {
    const wasBearish = prevLow.price < lows[0].price;
    return {
      type: wasBearish ? 'CHOCH' : 'BOS',
      direction: 'bullish',
      time: currentTime,
      price: prevHigh.price,
    };
  }

  // Bearish BOS: price breaks below previous swing low, and lastLow is MORE recent than prevLow
  // FIX: was `lastLow.time < prevLow.time` (wrong — lastLow is the most recent, so it should be >)
  if (currentPrice < prevLow.price && lastLow.time > prevLow.time) {
    const wasBullish = prevHigh.price > highs[0].price;
    return {
      type: wasBullish ? 'CHOCH' : 'BOS',
      direction: 'bearish',
      time: currentTime,
      price: prevLow.price,
    };
  }

  // MSS: strong displacement + structure break
  const recentCandles = candles.slice(-5);
  const displacement = Math.abs(recentCandles[recentCandles.length - 1].close - recentCandles[0].open);
  const avgRange = recentCandles.reduce((s, c) => s + (c.high - c.low), 0) / recentCandles.length;
  if (displacement > avgRange * 2.5) {
    if (currentPrice > prevHigh.price) {
      return { type: 'MSS', direction: 'bullish', time: currentTime, price: prevHigh.price };
    }
    if (currentPrice < prevLow.price) {
      return { type: 'MSS', direction: 'bearish', time: currentTime, price: prevLow.price };
    }
  }

  return null;
}

// ---------------------------------------------------------------------------
// FVG detection — fill counting starts at i+2 (not i+1)
// FIX: the candle at i+1 participates in creating the gap and must NOT count as a fill
// ---------------------------------------------------------------------------

export function detectFVGs(candles: Candle[]): FVG[] {
  const fvgs: FVG[] = [];
  for (let i = 1; i < candles.length - 1; i++) {
    const c1 = candles[i - 1]; // candle before the gap
    const c3 = candles[i + 1]; // candle after the gap
    // c1 and c3 define the gap; candle i is the middle (displacement) candle

    // Bullish FVG: c1.high < c3.low — gap up
    if (c1.high < c3.low) {
      const top = c3.low;
      const bottom = c1.high;
      let fillRatio = 0;
      let touched = false;
      // Start checking for fills from i+2 — NOT i+1 (i+1 is part of the gap creation)
      for (let j = i + 2; j < candles.length; j++) {
        if (candles[j].low <= top && candles[j].low >= bottom) {
          touched = true;
          const penetration = top - candles[j].low;
          fillRatio = Math.max(fillRatio, Math.min(1, penetration / (top - bottom)));
        }
        if (candles[j].low < bottom) {
          fillRatio = 1;
          touched = true;
        }
      }
      fvgs.push({
        id: `FVG-BULL-${candles[i].time}`,
        top,
        bottom,
        direction: 'bullish',
        createdAt: candles[i].time,
        filled: fillRatio >= 0.5,
        fillRatio,
        fresh: !touched,
      });
    }

    // Bearish FVG: c1.low > c3.high — gap down
    if (c1.low > c3.high) {
      const top = c1.low;
      const bottom = c3.high;
      let fillRatio = 0;
      let touched = false;
      for (let j = i + 2; j < candles.length; j++) {
        if (candles[j].high >= bottom && candles[j].high <= top) {
          touched = true;
          const penetration = candles[j].high - bottom;
          fillRatio = Math.max(fillRatio, Math.min(1, penetration / (top - bottom)));
        }
        if (candles[j].high > top) {
          fillRatio = 1;
          touched = true;
        }
      }
      fvgs.push({
        id: `FVG-BEAR-${candles[i].time}`,
        top,
        bottom,
        direction: 'bearish',
        createdAt: candles[i].time,
        filled: fillRatio >= 0.5,
        fillRatio,
        fresh: !touched,
      });
    }
  }
  return fvgs;
}

// ---------------------------------------------------------------------------
// Order Block detection
// ---------------------------------------------------------------------------

export function detectOrderBlocks(candles: Candle[]): OrderBlock[] {
  const obs: OrderBlock[] = [];
  for (let i = 2; i < candles.length - 1; i++) {
    const c = candles[i];
    const prev = candles[i - 1];
    const next = candles[i + 1];

    // Bullish OB: last down candle before a strong up move
    if (c.close < c.open && next.close > next.open && next.close > c.high) {
      const displacement = next.close - c.high;
      const avgRange = candles.slice(Math.max(0, i - 5), i + 2).reduce((s, x) => s + (x.high - x.low), 0) / Math.min(7, i + 2);
      if (displacement > avgRange * 1.2) {
        let mitigated = false;
        for (let j = i + 2; j < candles.length; j++) {
          if (candles[j].low <= c.high) { mitigated = true; break; }
        }
        obs.push({
          id: `OB-BULL-${c.time}`,
          top: c.open,
          bottom: c.low,
          direction: 'bullish',
          createdAt: c.time,
          mitigated,
          type: 'OB',
        });
      }
    }

    // Bearish OB: last up candle before a strong down move
    if (c.close > c.open && next.close < next.open && next.close < c.low) {
      const displacement = c.low - next.close;
      const avgRange = candles.slice(Math.max(0, i - 5), i + 2).reduce((s, x) => s + (x.high - x.low), 0) / Math.min(7, i + 2);
      if (displacement > avgRange * 1.2) {
        let mitigated = false;
        for (let j = i + 2; j < candles.length; j++) {
          if (candles[j].high >= c.low) { mitigated = true; break; }
        }
        obs.push({
          id: `OB-BEAR-${c.time}`,
          top: c.high,
          bottom: c.open,
          direction: 'bearish',
          createdAt: c.time,
          mitigated,
          type: 'OB',
        });
      }
    }
  }
  return obs;
}

// ---------------------------------------------------------------------------
// Liquidity pool detection
// ---------------------------------------------------------------------------

export function detectLiquidity(candles: Candle[], swings: SwingPoint[], currentPrice: number): LiquidityPool[] {
  const pools: LiquidityPool[] = [];
  const recent = candles.slice(-50);

  // Previous day high/low
  if (candles.length >= 48) {
    const dayAgo = candles.filter(c => c.time < candles[candles.length - 1].time - 86400000).slice(-48);
    if (dayAgo.length > 0) {
      const pdh = Math.max(...dayAgo.map(c => c.high));
      const pdl = Math.min(...dayAgo.map(c => c.low));
      pools.push({ id: 'PDH', price: pdh, side: pdh > currentPrice ? 'above' : 'below', type: 'PDH', strength: 0.8, swept: pdh < currentPrice });
      pools.push({ id: 'PDL', price: pdl, side: pdl > currentPrice ? 'above' : 'below', type: 'PDL', strength: 0.8, swept: pdl > currentPrice });
    }
  }

  // Session highs/lows (approximate)
  const sessionStart = recent[0]?.time ?? 0;
  const sessionHigh = Math.max(...recent.map(c => c.high));
  const sessionLow = Math.min(...recent.map(c => c.low));
  pools.push({ id: 'SESS-H', price: sessionHigh, side: sessionHigh > currentPrice ? 'above' : 'below', type: 'session_high', strength: 0.6, swept: sessionHigh < currentPrice });
  pools.push({ id: 'SESS-L', price: sessionLow, side: sessionLow > currentPrice ? 'above' : 'below', type: 'session_low', strength: 0.6, swept: sessionLow > currentPrice });

  // Equal highs/lows (EQH/EQL) — clusters of swings at similar prices
  const majorHighs = swings.filter(s => s.type === 'high' && s.strength > 0.3).slice(-10);
  const majorLows = swings.filter(s => s.type === 'low' && s.strength > 0.3).slice(-10);

  for (let i = 0; i < majorHighs.length; i++) {
    for (let j = i + 1; j < majorHighs.length; j++) {
      if (Math.abs(majorHighs[i].price - majorHighs[j].price) / majorHighs[i].price < 0.0008) {
        const price = (majorHighs[i].price + majorHighs[j].price) / 2;
        pools.push({ id: `EQH-${majorHighs[i].time}`, price, side: price > currentPrice ? 'above' : 'below', type: 'EQH', strength: 0.9, swept: price < currentPrice });
        break;
      }
    }
  }
  for (let i = 0; i < majorLows.length; i++) {
    for (let j = i + 1; j < majorLows.length; j++) {
      if (Math.abs(majorLows[i].price - majorLows[j].price) / majorLows[i].price < 0.0008) {
        const price = (majorLows[i].price + majorLows[j].price) / 2;
        pools.push({ id: `EQL-${majorLows[i].time}`, price, side: price > currentPrice ? 'above' : 'below', type: 'EQL', strength: 0.9, swept: price > currentPrice });
        break;
      }
    }
  }

  // BSL/SSL from most prominent swings
  const topHighs = majorHighs.slice(-3);
  const topLows = majorLows.slice(-3);
  for (const s of topHighs) {
    pools.push({ id: `BSL-${s.time}`, price: s.price, side: s.price > currentPrice ? 'above' : 'below', type: 'BSL', strength: s.strength, swept: s.price < currentPrice });
  }
  for (const s of topLows) {
    pools.push({ id: `SSL-${s.time}`, price: s.price, side: s.price > currentPrice ? 'above' : 'below', type: 'SSL', strength: s.strength, swept: s.price > currentPrice });
  }

  // Deduplicate by price proximity
  const deduped: LiquidityPool[] = [];
  for (const p of pools) {
    if (!deduped.some(d => Math.abs(d.price - p.price) / p.price < 0.0005 && d.type === p.type)) {
      deduped.push(p);
    }
  }
  return deduped;
}

// ---------------------------------------------------------------------------
// Dealing range / premium-discount
// ---------------------------------------------------------------------------

function computeDealingRange(swings: SwingPoint[], currentPrice: number) {
  const recentSwings = swings.slice(-20);
  const highs = recentSwings.filter(s => s.type === 'high');
  const lows = recentSwings.filter(s => s.type === 'low');
  if (highs.length === 0 || lows.length === 0) return null;
  const top = Math.max(...highs.map(s => s.price));
  const bottom = Math.min(...lows.map(s => s.price));
  const equilibrium = (top + bottom) / 2;
  return {
    top, bottom, equilibrium,
    premium: currentPrice > equilibrium,
    discount: currentPrice < equilibrium,
  };
}

// ---------------------------------------------------------------------------
// Noise estimation
// ---------------------------------------------------------------------------

function estimateNoise(candles: Candle[]): number {
  if (candles.length < 10) return 0.5;
  const recent = candles.slice(-20);
  const ranges = recent.map(c => c.high - c.low);
  const avgRange = ranges.reduce((a, b) => a + b, 0) / ranges.length;
  const bodyAvg = recent.map(c => Math.abs(c.close - c.open)).reduce((a, b) => a + b, 0) / recent.length;
  if (avgRange === 0) return 0.5;
  return Math.min(1, 1 - bodyAvg / avgRange);
}

// ---------------------------------------------------------------------------
// Full structure analysis for one timeframe
// ---------------------------------------------------------------------------

export function analyzeStructure(candles: Candle[], tf: string): StructureState {
  const lookback = tf === 'M1' || tf === 'M5' ? 2 : tf === 'M15' || tf === 'M30' ? 3 : 5;
  const swings = detectSwings(candles, lookback);
  const fvgs = detectFVGs(candles);
  const orderBlocks = detectOrderBlocks(candles);
  const currentPrice = candles.length > 0 ? candles[candles.length - 1].close : 0;
  const liquidity = detectLiquidity(candles, swings, currentPrice);
  const event = detectStructureEvents(candles, swings);
  const dealing = computeDealingRange(swings, currentPrice);
  const noise = estimateNoise(candles);

  // Determine bias from structure events and swing sequence
  let bias: StructureBias = 'undefined';
  if (event) {
    if (event.type === 'MSS') bias = event.direction;
    else if (event.type === 'CHOCH') bias = event.direction;
    else if (event.type === 'BOS') bias = event.direction;
  } else {
    // Infer from swing sequence
    const recentHighs = swings.filter(s => s.type === 'high').slice(-3);
    const recentLows = swings.filter(s => s.type === 'low').slice(-3);
    if (recentHighs.length >= 2 && recentLows.length >= 2) {
      const hh = recentHighs[recentHighs.length - 1].price > recentHighs[recentHighs.length - 2].price;
      const hl = recentLows[recentLows.length - 1].price > recentLows[recentLows.length - 2].price;
      const lh = recentHighs[recentHighs.length - 1].price < recentHighs[recentHighs.length - 2].price;
      const ll = recentLows[recentLows.length - 1].price < recentLows[recentLows.length - 2].price;
      if (hh && hl) bias = 'bullish';
      else if (lh && ll) bias = 'bearish';
      else bias = 'ranging';
    }
  }

  return {
    bias,
    lastEvent: event,
    swings,
    fvgs,
    orderBlocks,
    liquidity,
    dealingRange: dealing ? { top: dealing.top, bottom: dealing.bottom } : null,
    premium: dealing?.premium ?? false,
    discount: dealing?.discount ?? false,
    equilibrium: dealing?.equilibrium ?? currentPrice,
    noise,
  };
}
