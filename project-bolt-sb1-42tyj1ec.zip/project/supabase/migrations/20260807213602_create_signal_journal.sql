/*
# Create signal_journal and signal_snapshots tables

1. New Tables
- `signal_journal`: one row per unique setup (stable setup_id). The prediction is FROZEN
  at first detection — confidence, scores, structure, and EV are never modified after insert.
  Outcome columns (outcome, exit_price, mfe, mae, tp hits, sl_hit, r_realized) start NULL
  and are filled later by the outcome engine when the trade resolves.
- `signal_snapshots`: optional time-series of the engine's evolving view of the SAME setup_id,
  recorded every 60s. This keeps the main journal clean (one row per setup) while still
  allowing post-hoc analysis of how conviction evolved. The frozen prediction in
  signal_journal is the one used for calibration — never the snapshots.

2. Columns (signal_journal)
- setup_id (text, primary key) — stable identifier like XAUUSD-LDN-20260807-001
- symbol, created_at, first_detected_at
- direction (BUY/SELL/NEUTRAL), status_at_prediction
- price_at_prediction, entry_min, entry_max, stop, tp1, tp2, tp3
- confidence (frozen heuristic), buy_score, sell_score, no_trade_score
- regime, h4_bias, h1_bias, m15_structure, m5_trigger
- liquidity_target, liquidity_swept
- bos, choch, mss, fvg, ifvg, ob, breaker, bpr (nullable text)
- dxy, us10y, real_yield (nullable — null when feed unavailable)
- macro_risk, news_risk
- agents_snapshot (jsonb — full agent opinions at prediction time)
- predicted_ev
- triggered_at, entry_price (nullable — filled when trade triggers)
- outcome (PENDING/WIN/LOSS/BREAKEVEN/EXPIRED), exit_price, closed_at
- mfe, mae, tp1_hit, tp2_hit, tp3_hit, sl_hit, r_realized (nullable — filled by outcome engine)

3. Columns (signal_snapshots)
- id (uuid, primary key)
- setup_id (text, foreign key to signal_journal)
- captured_at (timestamptz)
- status, direction, confidence, buy_score, sell_score, price
- agents_snapshot (jsonb)

4. Security
- Enable RLS on both tables.
- Single-tenant no-auth app: allow anon + authenticated CRUD (data is intentionally shared).
*/

CREATE TABLE IF NOT EXISTS signal_journal (
  setup_id text PRIMARY KEY,
  symbol text NOT NULL DEFAULT 'XAUUSD',
  created_at timestamptz NOT NULL DEFAULT now(),
  first_detected_at timestamptz NOT NULL DEFAULT now(),
  direction text NOT NULL,
  status_at_prediction text NOT NULL,
  price_at_prediction numeric NOT NULL,
  entry_min numeric,
  entry_max numeric,
  stop numeric,
  tp1 numeric,
  tp2 numeric,
  tp3 numeric,
  confidence numeric NOT NULL,
  buy_score integer NOT NULL,
  sell_score integer NOT NULL,
  no_trade_score integer NOT NULL,
  regime text,
  h4_bias text,
  h1_bias text,
  m15_structure text,
  m5_trigger text,
  liquidity_target text,
  liquidity_swept boolean DEFAULT false,
  bos text,
  choch text,
  mss text,
  fvg text,
  ifvg text,
  ob text,
  breaker text,
  bpr text,
  dxy numeric,
  us10y numeric,
  real_yield numeric,
  macro_risk text,
  news_risk text,
  agents_snapshot jsonb,
  predicted_ev numeric,
  triggered_at timestamptz,
  entry_price numeric,
  outcome text DEFAULT 'PENDING',
  exit_price numeric,
  closed_at timestamptz,
  mfe numeric,
  mae numeric,
  tp1_hit boolean,
  tp2_hit boolean,
  tp3_hit boolean,
  sl_hit boolean,
  r_realized numeric
);

ALTER TABLE signal_journal ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_journal" ON signal_journal;
CREATE POLICY "anon_select_journal" ON signal_journal FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_journal" ON signal_journal;
CREATE POLICY "anon_insert_journal" ON signal_journal FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_journal" ON signal_journal;
CREATE POLICY "anon_update_journal" ON signal_journal FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_journal" ON signal_journal;
CREATE POLICY "anon_delete_journal" ON signal_journal FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS signal_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setup_id text NOT NULL REFERENCES signal_journal(setup_id) ON DELETE CASCADE,
  captured_at timestamptz NOT NULL DEFAULT now(),
  status text,
  direction text,
  confidence numeric,
  buy_score integer,
  sell_score integer,
  price numeric,
  agents_snapshot jsonb
);

ALTER TABLE signal_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_snapshots" ON signal_snapshots;
CREATE POLICY "anon_select_snapshots" ON signal_snapshots FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_snapshots" ON signal_snapshots;
CREATE POLICY "anon_insert_snapshots" ON signal_snapshots FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_snapshots" ON signal_snapshots;
CREATE POLICY "anon_update_snapshots" ON signal_snapshots FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_snapshots" ON signal_snapshots;
CREATE POLICY "anon_delete_snapshots" ON signal_snapshots FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_signal_journal_created_at ON signal_journal (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signal_journal_outcome ON signal_journal (outcome);
CREATE INDEX IF NOT EXISTS idx_signal_snapshots_setup_id ON signal_snapshots (setup_id);
