-- ─── Revoke excess privileges from anon/authenticated ───────────
-- The previous migration dropped UPDATE/DELETE policies but never
-- revoked the underlying column privileges. Anon could still UPDATE
-- or DELETE rows if any policy accidentally allowed it.

REVOKE UPDATE ON signal_journal FROM anon, authenticated;
REVOKE DELETE ON signal_journal FROM anon, authenticated;

REVOKE UPDATE ON signal_snapshots FROM anon, authenticated;
REVOKE DELETE ON signal_snapshots FROM anon, authenticated;

REVOKE INSERT ON price_ticks FROM anon, authenticated;
REVOKE UPDATE ON price_ticks FROM anon, authenticated;
REVOKE DELETE ON price_ticks FROM anon, authenticated;

-- ─── Add outcome guard columns to signal_journal ────────────────
-- Track whether outcome was already set to prevent double-updates.
ALTER TABLE signal_journal ADD COLUMN IF NOT EXISTS outcome_locked boolean DEFAULT false;
ALTER TABLE signal_journal ADD COLUMN IF NOT EXISTS outcome_set_at timestamptz;

-- ─── Create a SECURITY DEFINER function to update outcomes ─────
-- This is the ONLY way outcome fields can be updated. It verifies:
-- 1. The setup_id exists
-- 2. The outcome has not already been locked
-- 3. Only valid outcome transitions are allowed
-- The function runs with service role privileges but is called
-- from the record-outcome edge function which validates the request.

CREATE OR REPLACE FUNCTION update_signal_outcome(
  p_setup_id text,
  p_outcome text,
  p_outcome_price numeric DEFAULT NULL,
  p_mfe numeric DEFAULT NULL,
  p_mae numeric DEFAULT NULL,
  p_r_realized numeric DEFAULT NULL
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_current_outcome text;
  v_locked boolean;
  v_valid_outcomes text[] := ARRAY['pending', 'tp1', 'tp2', 'tp3', 'sl', 'breakeven', 'expired', 'invalidated'];
BEGIN
  -- Validate outcome value
  IF p_outcome = ANY(v_valid_outcomes) = false THEN
    RETURN jsonb_build_object('error', 'invalid_outcome', 'message', 'Outcome must be one of: ' || array_to_string(v_valid_outcomes, ', '));
  END IF;

  -- Check the setup exists and get current state
  SELECT outcome, outcome_locked INTO v_current_outcome, v_locked
  FROM signal_journal
  WHERE setup_id = p_setup_id
  FOR UPDATE;

  IF NOT FOUND THEN
    RETURN jsonb_build_object('error', 'setup_not_found', 'message', 'No signal found for setup_id: ' || p_setup_id);
  END IF;

  -- Prevent double-updates: once locked, no further changes
  IF v_locked = true THEN
    RETURN jsonb_build_object('error', 'already_locked', 'message', 'Outcome already recorded and locked for this setup');
  END IF;

  -- Only allow transition from 'pending' to a final outcome
  IF v_current_outcome <> 'pending' THEN
    RETURN jsonb_build_object('error', 'already_set', 'message', 'Outcome already set to: ' || v_current_outcome);
  END IF;

  -- Perform the update
  UPDATE signal_journal
  SET outcome = p_outcome,
      outcome_time = now(),
      outcome_price = p_outcome_price,
      mfe = p_mfe,
      mae = p_mae,
      r_realized = p_r_realized,
      outcome_locked = true,
      outcome_set_at = now()
  WHERE setup_id = p_setup_id;

  RETURN jsonb_build_object('success', true);
END;
$$;

-- Revoke execute from anon and authenticated; only service role can call
REVOKE EXECUTE ON FUNCTION update_signal_outcome(text, text, numeric, numeric, numeric, numeric) FROM anon, authenticated;
