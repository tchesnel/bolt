-- ─── signal_journal additions ──────────────────────────────────
-- Add setup_id, r_realized columns to existing signal_journal table
ALTER TABLE signal_journal ADD COLUMN IF NOT EXISTS setup_id text UNIQUE;
ALTER TABLE signal_journal ADD COLUMN IF NOT EXISTS r_realized numeric(8,4);

-- Remove UPDATE/DELETE policies from anon/authenticated on signal_journal.
-- Only the service role (server-side outcome engine via edge function) can update.
DROP POLICY IF EXISTS "anon_update_signals" ON signal_journal;
DROP POLICY IF EXISTS "anon_delete_signals" ON signal_journal;

CREATE INDEX IF NOT EXISTS idx_signal_journal_setup_id ON signal_journal (setup_id);

-- ─── signal_snapshots ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signal_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setup_id text,
  created_at timestamptz DEFAULT now(),
  status text,
  current_stage text,
  price numeric(12,4),
  mfe numeric(12,4),
  mae numeric(12,4),
  metadata jsonb DEFAULT '{}'
);

ALTER TABLE signal_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_snapshots" ON signal_snapshots;
CREATE POLICY "anon_select_snapshots" ON signal_snapshots FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_snapshots" ON signal_snapshots;
CREATE POLICY "anon_insert_snapshots" ON signal_snapshots FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_signal_snapshots_setup_id ON signal_snapshots (setup_id);
CREATE INDEX IF NOT EXISTS idx_signal_snapshots_created ON signal_snapshots (created_at DESC);

-- ─── price_ticks ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS price_ticks (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  bid numeric(12,4) NOT NULL,
  ask numeric(12,4) NOT NULL,
  last numeric(12,4) NOT NULL,
  spread numeric(10,4) NOT NULL,
  provider text NOT NULL DEFAULT 'MT5_BRIDGE',
  quality integer NOT NULL DEFAULT 100
);

ALTER TABLE price_ticks ENABLE ROW LEVEL SECURITY;

-- anon/authenticated can SELECT (read ticks for candle building)
DROP POLICY IF EXISTS "anon_select_ticks" ON price_ticks;
CREATE POLICY "anon_select_ticks" ON price_ticks FOR SELECT
  TO anon, authenticated USING (true);

-- NO INSERT policy for anon/authenticated.
-- Only the service role (MT5 bridge edge function) can insert ticks.

CREATE INDEX IF NOT EXISTS idx_price_ticks_created ON price_ticks (created_at DESC);
