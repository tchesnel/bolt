import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const { setup_id, outcome, exit_price, mfe, mae, r_realized } = await req.json();

    if (!setup_id || !outcome) {
      return new Response(JSON.stringify({ error: "setup_id and outcome required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Validate outcome value server-side
    const validOutcomes = ["tp1", "tp2", "tp3", "sl", "breakeven", "expired", "invalidated"];
    if (!validOutcomes.includes(outcome)) {
      return new Response(JSON.stringify({ error: `Invalid outcome: ${outcome}. Must be one of: ${validOutcomes.join(", ")}` }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Call the SECURITY DEFINER function instead of directly patching the table.
    // The function verifies the setup exists, outcome is still pending, and
    // locks the row after update to prevent any further modification.
    const resp = await fetch(
      `${supabaseUrl}/rest/v1/rpc/update_signal_outcome`,
      {
        method: "POST",
        headers: {
          "apikey": serviceKey,
          "Authorization": `Bearer ${serviceKey}`,
          "Content-Type": "application/json",
          "Prefer": "return=representation",
        },
        body: JSON.stringify({
          p_setup_id: setup_id,
          p_outcome: outcome,
          p_outcome_price: exit_price ?? null,
          p_mfe: mfe ?? null,
          p_mae: mae ?? null,
          p_r_realized: r_realized ?? null,
        }),
      },
    );

    const result = await resp.json();

    if (!resp.ok) {
      return new Response(JSON.stringify({ error: `Outcome update failed: ${JSON.stringify(result)}` }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if the function returned an error
    if (result?.error) {
      return new Response(JSON.stringify(result), {
        status: 409,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
