import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface MT5Quote {
  bid: number;
  ask: number;
  last: number;
  timestamp: number;
}

interface MT5Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

interface BridgeConfig {
  bridgeUrl: string;
  symbol: string;
}

function getConfig(): BridgeConfig | null {
  const bridgeUrl = Deno.env.get("MT5_BRIDGE_URL");
  if (!bridgeUrl) return null;
  return {
    bridgeUrl,
    symbol: Deno.env.get("MT5_SYMBOL") || "XAUUSD",
  };
}

async function fetchFromBridge(config: BridgeConfig): Promise<MT5Quote | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(`${config.bridgeUrl}/quote?symbol=${config.symbol}`, {
      signal: controller.signal,
      headers: { "Accept": "application/json" },
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (typeof data.bid !== "number" || typeof data.ask !== "number") return null;
    return {
      bid: data.bid,
      ask: data.ask,
      last: data.last ?? (data.bid + data.ask) / 2,
      timestamp: data.timestamp ?? Date.now(),
    };
  } catch {
    return null;
  }
}

async function fetchCandlesFromBridge(
  config: BridgeConfig,
  timeframe: string,
  count: number,
): Promise<MT5Candle[] | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    const resp = await fetch(
      `${config.bridgeUrl}/candles?symbol=${config.symbol}&timeframe=${timeframe}&count=${count}`,
      { signal: controller.signal, headers: { "Accept": "application/json" } },
    );
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (!Array.isArray(data.candles)) return null;
    return data.candles as MT5Candle[];
  } catch {
    return null;
  }
}

async function storeTick(supabase: any, quote: MT5Quote, provider: string, quality: number) {
  const { error } = await supabase
    .from("price_ticks")
    .insert({
      bid: quote.bid,
      ask: quote.ask,
      last: quote.last,
      spread: quote.ask - quote.bid,
      provider,
      quality,
    });
  if (error) console.error("Failed to store tick:", error.message);
}

const TF_MAP: Record<string, string> = {
  M1: "M1",
  M5: "M5",
  M15: "M15",
  M30: "M30",
  H1: "H1",
  H4: "H4",
  D1: "D1",
  W1: "W1",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "quote";
    const limit = parseInt(url.searchParams.get("limit") || "1");

    // ─── GET /quote — fetch latest tick from MT5 bridge only ───
    if (action === "quote" || action === "latest") {
      const config = getConfig();

      if (!config) {
        return new Response(
          JSON.stringify({
            status: "DATA_OFFLINE",
            message: "MT5 bridge not configured. Set MT5_BRIDGE_URL to enable live data.",
            bid: null,
            ask: null,
            last: null,
            spread: null,
            provider: null,
            quality: 0,
            timestamp: Date.now(),
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const quote = await fetchFromBridge(config);

      if (!quote) {
        return new Response(
          JSON.stringify({
            status: "DATA_OFFLINE",
            message: "MT5 bridge unreachable. No fallback data source — trading blocked.",
            bid: null,
            ask: null,
            last: null,
            spread: null,
            provider: null,
            quality: 0,
            timestamp: Date.now(),
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // Store tick in database
      await storeTick(supabase, quote, "MT5_BRIDGE", 100);

      return new Response(
        JSON.stringify({
          status: "CONNECTED",
          bid: quote.bid,
          ask: quote.ask,
          last: quote.last,
          spread: quote.ask - quote.bid,
          provider: "MT5_BRIDGE",
          quality: 100,
          timestamp: quote.timestamp,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── GET /history — fetch recent ticks from database ───
    if (action === "history") {
      const { data, error } = await supabase
        .from("price_ticks")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(Math.min(limit, 5000));

      if (error) {
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({
          status: "CONNECTED",
          ticks: (data || []).reverse().map((t: any) => {
            const bid = parseFloat(t.bid);
            const ask = parseFloat(t.ask);
            return {
              time: new Date(t.created_at).getTime(),
              bid,
              ask,
              mid: (bid + ask) / 2,
              last: parseFloat(t.last),
              spread: parseFloat(t.spread),
              volume: 0,
              provider: t.provider,
              quality: t.quality,
            };
          }),
          count: data?.length || 0,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── GET /candles — fetch historical candles from MT5 bridge ───
    // Returns months/years of real OHLC data for all timeframes.
    // The bridge must support: GET /candles?symbol=XAUUSD&timeframe=M1&count=500000
    if (action === "candles") {
      const config = getConfig();
      if (!config) {
        return new Response(
          JSON.stringify({
            status: "DATA_OFFLINE",
            message: "MT5 bridge not configured.",
            candles: [],
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      const timeframe = url.searchParams.get("timeframe") || "M1";
      const count = Math.min(parseInt(url.searchParams.get("count") || "5000"), 500000);
      const mt5Tf = TF_MAP[timeframe] || timeframe;

      const candles = await fetchCandlesFromBridge(config, mt5Tf, count);

      if (!candles || candles.length === 0) {
        return new Response(
          JSON.stringify({
            status: "DATA_OFFLINE",
            message: "MT5 bridge returned no candles.",
            candles: [],
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({
          status: "CONNECTED",
          timeframe,
          candles,
          count: candles.length,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── GET /status — check feed connectivity ───
    if (action === "status") {
      const config = getConfig();
      return new Response(
        JSON.stringify({
          mt5Bridge: !!config,
          ready: !!config,
          symbol: config?.symbol || "XAUUSD",
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action. Use ?action=quote|history|candles|status" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
