import { Tick, FeedState, EngineMode, PriceState, ProviderQuote } from '@/engine/types';
import { supabase } from '@/lib/supabase';

const FEED_URL = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/xauusd-feed`;
const HEADERS = {
  Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
  'Content-Type': 'application/json',
};

export interface FeedQuote {
  status: string;
  bid: number | null;
  ask: number | null;
  last: number | null;
  spread: number | null;
  provider: string | null;
  quality: number;
  timestamp: number;
}

export interface FeedHistoryResponse {
  status: string;
  ticks: Tick[];
  count: number;
}

export async function fetchLatestQuote(): Promise<FeedQuote> {
  try {
    const resp = await fetch(`${FEED_URL}?action=quote`, { headers: HEADERS });
    if (!resp.ok) throw new Error(`Feed request failed (${resp.status})`);
    const data = await resp.json();
    if (!data || typeof data.status !== 'string') {
      throw new Error('Invalid feed response');
    }
    return data;
  } catch (err) {
    return {
      status: 'DISCONNECTED',
      bid: null,
      ask: null,
      last: null,
      spread: null,
      provider: null,
      quality: 0,
      timestamp: Date.now(),
    };
  }
}

export async function fetchTickHistory(limit: number = 1000): Promise<Tick[]> {
  try {
    const resp = await fetch(`${FEED_URL}?action=history&limit=${limit}`, { headers: HEADERS });
    if (!resp.ok) return [];
    const data: FeedHistoryResponse = await resp.json();
    if (!data.ticks || !Array.isArray(data.ticks)) return [];
    return data.ticks;
  } catch {
    return [];
  }
}

export interface FeedCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface FeedCandleResponse {
  status: string;
  timeframe: string;
  candles: FeedCandle[];
  count: number;
}

export async function fetchCandleHistory(timeframe: string, count: number = 5000): Promise<FeedCandle[]> {
  try {
    const resp = await fetch(`${FEED_URL}?action=candles&timeframe=${timeframe}&count=${count}`, { headers: HEADERS });
    if (!resp.ok) return [];
    const data: FeedCandleResponse = await resp.json();
    if (!data.candles || !Array.isArray(data.candles)) return [];
    return data.candles;
  } catch {
    return [];
  }
}

export interface FeedStatusResponse {
  mt5Bridge: boolean;
  ready: boolean;
  symbol: string;
}

export async function fetchFeedStatus(): Promise<FeedStatusResponse> {
  try {
    const resp = await fetch(`${FEED_URL}?action=status`, { headers: HEADERS });
    if (!resp.ok) return { mt5Bridge: false, ready: false, symbol: 'XAUUSD' };
    return await resp.json();
  } catch {
    return { mt5Bridge: false, ready: false, symbol: 'XAUUSD' };
  }
}

export function quoteToPriceState(quote: FeedQuote, feed: FeedState): PriceState {
  const now = Date.now();
  const connected = quote.status === 'CONNECTED' && quote.bid != null && quote.ask != null;

  const bid = quote.bid ?? 0;
  const ask = quote.ask ?? 0;
  const mid = quote.last ?? (bid + ask) / 2;
  const spread = quote.spread ?? ask - bid;

  const providerQuote: ProviderQuote = {
    provider: quote.provider ?? 'UNKNOWN',
    bid,
    ask,
    last: mid,
    timestamp: quote.timestamp,
    receiveTime: now,
    tickRate: 0,
    quality: quote.quality,
  };

  const lastTick: Tick | null = connected
    ? {
        time: quote.timestamp,
        bid,
        ask,
        mid,
        spread,
        volume: 0,
        last: mid,
      }
    : null;

  const stale = !connected || now - quote.timestamp > feed.staleThresholdMs;

  return {
    median: mid,
    bestBid: bid,
    bestAsk: ask,
    spread,
    maxDivergence: 0,
    quality: connected ? quote.quality : 0,
    stale,
    quotes: connected ? [providerQuote] : [],
    time: now,
    feed: {
      ...feed,
      status: stale ? 'STALE' : connected ? 'CONNECTED' : 'DISCONNECTED',
      provider: quote.provider ?? 'NONE',
      lastTickAt: quote.timestamp,
      heartbeat: connected ? 1 : 0,
      lastHeartbeatAt: now,
    },
    lastTick,
  };
}
