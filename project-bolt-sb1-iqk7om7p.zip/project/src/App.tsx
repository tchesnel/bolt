import { useState, useEffect, useRef } from 'react';
import { MarketSnapshot, Timeframe, Candle, Tick as EngineTick, EngineMode, SetupState } from '@/engine/types';
import { createFeedState, priceStateFromTick, updateFeedState, dataOfflinePriceState } from '@/engine/market';
import { runPipeline, createPipelineState } from '@/engine/pipeline';
import { Dashboard } from '@/components/Dashboard';
import { recordSignal, recordSnapshot, recordOutcome } from '@/lib/journal';
import { fetchLatestQuote, fetchTickHistory, fetchFeedStatus, fetchCandleHistory, FeedCandle } from '@/lib/feed';
import { createOutcome, processOutcome, DEFAULT_OUTCOME_CONFIG, OutcomeResult } from '@/engine/outcome';

const TIMEFRAMES: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D', 'W'];
const TF_MIN: Record<Timeframe, number> = { M1: 1, M5: 5, M15: 15, H1: 60, H4: 240, D: 1440, W: 10080 };

interface SimTick { time: number; price: number; volume: number; buyVolume: number; sellVolume: number; }

function aggregateCandles(ticks: SimTick[], tf: Timeframe): Candle[] {
  const bucketMs = TF_MIN[tf] * 60 * 1000;
  const map = new Map<number, Candle>();
  for (const t of ticks) {
    const bucket = Math.floor(t.time / bucketMs) * bucketMs;
    let c = map.get(bucket);
    if (!c) {
      c = { time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: 0, buyVolume: 0, sellVolume: 0, hasRealVolume: false };
      map.set(bucket, c);
    }
    c.close = t.price;
    c.high = Math.max(c.high, t.price);
    c.low = Math.min(c.low, t.price);
    c.volume += t.volume;
    c.buyVolume += t.buyVolume;
    c.sellVolume += t.sellVolume;
  }
  return Array.from(map.values()).sort((a, b) => a.time - b.time);
}

function ticksFromFeed(feedTicks: EngineTick[]): SimTick[] {
  return feedTicks.map((t) => ({
    time: t.time,
    price: t.mid,
    volume: t.volume,
    buyVolume: t.buyVolume ?? 0,
    sellVolume: t.sellVolume ?? 0,
  }));
}

function feedCandleToEngineCandle(c: FeedCandle): Candle {
  return {
    time: c.time,
    open: c.open,
    high: c.high,
    low: c.low,
    close: c.close,
    volume: c.volume,
    buyVolume: 0,
    sellVolume: 0,
    hasRealVolume: c.volume > 0,
  };
}

export function useLiveEngine() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const [feedReady, setFeedReady] = useState<boolean | null>(null);
  const ticksRef = useRef<SimTick[]>([]);
  const historicalCandlesRef = useRef<Record<Timeframe, Candle[]>>({} as Record<Timeframe, Candle[]>);
  const lastRecordRef = useRef<string>('');
  const lastSnapshotTimeRef = useRef(0);
  const pipelineStateRef = useRef(createPipelineState('PRODUCTION' as EngineMode));
  const feedRef = useRef(createFeedState('PRODUCTION' as EngineMode, 'MT5_BRIDGE', 'XAUUSD', 5000));
  const lastSetupIdRef = useRef<string | null>(null);
  const lastRealTickRef = useRef<EngineTick | null>(null);
  const outcomeRef = useRef<OutcomeResult | null>(null);
  const outcomeSetupRef = useRef<SetupState | null>(null);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    let mounted = true;

    async function init() {
      const status = await fetchFeedStatus();
      if (!mounted) return;

      setFeedReady(status.ready);

      if (status.ready) {
        // Fetch real historical candles from MT5 bridge for all timeframes.
        // This provides months/years of H1/H4/D/W data that tick polling
        // could never accumulate.
        const tfCounts: Record<string, number> = {
          M1: 50000, M5: 50000, M15: 50000, H1: 50000, H4: 20000, D: 10000, W: 1000,
        };
        const tfMap: Record<string, Timeframe> = {
          M1: 'M1', M5: 'M5', M15: 'M15', H1: 'H1', H4: 'H4', D: 'D', W: 'W',
        };
        const fetches = Object.entries(tfCounts).map(async ([tf, count]) => {
          const candles = await fetchCandleHistory(tf, count);
          if (!mounted) return;
          if (candles.length > 0) {
            const engineTf = tfMap[tf];
            historicalCandlesRef.current[engineTf] = candles.map(feedCandleToEngineCandle);
          }
        });
        await Promise.all(fetches);
        if (!mounted) return;

        // Also fetch recent ticks for live price
        const history = await fetchTickHistory(2000);
        if (!mounted) return;
        if (history.length > 0) {
          ticksRef.current = ticksFromFeed(history);
          lastRealTickRef.current = history[history.length - 1];
        }
      }

      startLoop();
    }

    function compute() {
      const ticks = ticksRef.current;
      const now = Date.now();

      let priceState;
      if (lastRealTickRef.current) {
        const feed = updateFeedState(feedRef.current, lastRealTickRef.current.time, now);
        feedRef.current = feed;
        priceState = priceStateFromTick(lastRealTickRef.current, feed, now);
      } else {
        priceState = dataOfflinePriceState(feedRef.current, now);
      }

      if (ticks.length === 0) {
        const snap = runPipeline({} as Record<Timeframe, Candle[]>, priceState, now, pipelineStateRef.current);
        setSnapshot(snap);
        return;
      }

      const candles = {} as Record<Timeframe, Candle[]>;
      // Start with historical candles from MT5 bridge, then append any live ticks
      const histCandles = historicalCandlesRef.current;
      for (const tf of TIMEFRAMES) {
        const hist = histCandles[tf] ?? [];
        const liveCandles = aggregateCandles(ticks, tf);
        if (hist.length > 0 && liveCandles.length > 0) {
          // Merge: use historical candles up to the first live candle, then live
          const firstLiveTime = liveCandles[0].time;
          const histFiltered = hist.filter((c) => c.time < firstLiveTime);
          candles[tf] = [...histFiltered, ...liveCandles];
        } else if (hist.length > 0) {
          candles[tf] = hist;
        } else {
          candles[tf] = liveCandles;
        }
      }
      const snap = runPipeline(candles, priceState, now, pipelineStateRef.current);
      setSnapshot(snap);

      const setupId = snap.setup?.setupId ?? null;
      const isExecute = snap.plan.status === 'EXECUTE';

      if (isExecute && setupId && setupId !== lastSetupIdRef.current) {
        lastSetupIdRef.current = setupId;
        recordSignal(snap, setupId);
        if (snap.setup) {
          outcomeRef.current = createOutcome(setupId, snap.setup.direction);
          outcomeSetupRef.current = snap.setup;
        }
      }

      if (outcomeRef.current && outcomeSetupRef.current && lastRealTickRef.current) {
        const m1Candles = candles.M1;
        const currentCandle = m1Candles[m1Candles.length - 1];
        if (currentCandle) {
          // FROZEN SETUP: Do NOT overwrite outcomeSetupRef with the latest snap.setup.
          // The setup at EXECUTE time is immutable — entry, SL, TP, POI, direction
          // are frozen and must never change. The outcome engine tracks against
          // these fixed values until the trade closes.
          outcomeRef.current = processOutcome(
            outcomeRef.current,
            outcomeSetupRef.current,
            currentCandle,
            lastRealTickRef.current,
            DEFAULT_OUTCOME_CONFIG,
            now,
          );

          const o = outcomeRef.current;
          if (o.status === 'closed' || o.status === 'expired' || o.status === 'invalidated') {
            recordOutcome(o);
            outcomeRef.current = null;
            outcomeSetupRef.current = null;
          }
        }
      }

      if (setupId && snap.setup && now - lastSnapshotTimeRef.current > 60000) {
        lastSnapshotTimeRef.current = now;
        recordSnapshot(snap, setupId);
      }
    }

    function startLoop() {
      compute();

      interval = setInterval(async () => {
        if (lastRealTickRef.current) {
          const quote = await fetchLatestQuote();
          if (!mounted) return;
          if (quote.status === 'CONNECTED' && quote.last != null && quote.bid != null && quote.ask != null) {
            const tick: EngineTick = {
              time: quote.timestamp,
              bid: quote.bid,
              ask: quote.ask,
              mid: (quote.bid + quote.ask) / 2,
              spread: quote.spread ?? quote.ask - quote.bid,
              volume: 0,
              last: quote.last,
            };
            lastRealTickRef.current = tick;
            ticksRef.current.push({
              time: tick.time,
              price: tick.mid,
              volume: 0,
              buyVolume: 0,
              sellVolume: 0,
            });
            if (ticksRef.current.length > 50000) {
              ticksRef.current = ticksRef.current.slice(-30000);
            }
          }
        }
        compute();
      }, 3000);
    }

    init();

    return () => {
      mounted = false;
      if (interval) clearInterval(interval);
    };
  }, []);

  return { snapshot, feedReady };
}

export default function App() {
  const { snapshot, feedReady } = useLiveEngine();
  return <Dashboard snapshot={snapshot} feedReady={feedReady} />;
}
