// Tests for structure detection: MSS, FVG, IFVG, BPR, sweep, BOS/CHOCH
import { computeStructure } from '../structure';
import { detectSwings, detectStructureEvents, computeDisplacement } from '../structure';
import { makeCandle, makeBullishMSSTest, makeBearishMSSTest, makeBullishFVGTest, makeBearishFVGTest, TestSuite } from './test-helpers';

const suite = new TestSuite();

// ─── MSS Detection ─────────────────────────────────────────────

suite.test('Bullish MSS: sweep below low + displacement up + close above high', () => {
  const { candles, mssTime, mssLevel } = makeBullishMSSTest(1700000000000);
  const swings = detectSwings(candles, 2, 2);
  const { events, bias } = detectStructureEvents(candles, swings);

  const mssEvents = events.filter((e) => e.type === 'MSS' && e.direction === 'bullish');
  suite.expectTrue(mssEvents.length > 0, 'Should detect at least one bullish MSS event');
  const mss = mssEvents[0];
  suite.expectTrue(mss.confirmed, 'MSS should be confirmed');
  suite.expectEqual(mss.direction, 'bullish');
  suite.expectGreaterThan(mss.time, 0, 'MSS should have a timestamp');
});

suite.test('Bearish MSS: sweep above high + displacement down + close below low', () => {
  const { candles } = makeBearishMSSTest(1700000000000);
  const swings = detectSwings(candles, 2, 2);
  const { events } = detectStructureEvents(candles, swings);

  const mssEvents = events.filter((e) => e.type === 'MSS' && e.direction === 'bearish');
  suite.expectTrue(mssEvents.length > 0, 'Should detect at least one bearish MSS event');
  const mss = mssEvents[0];
  suite.expectTrue(mss.confirmed, 'MSS should be confirmed');
  suite.expectEqual(mss.direction, 'bearish');
});

suite.test('MSS requires displacement — small candle should not trigger MSS', () => {
  const candles: typeof makeCandle[] = [];
  let t = 1700000000000;
  const interval = 60000;

  // Establish range
  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2005, 2010, 2000, 2005, 100) as never);
    t += interval;
  }
  // Small sweep (no displacement)
  candles.push(makeCandle(t, 2005, 2007, 1998, 2003, 50) as never);
  t += interval;
  // Small candle (no displacement)
  candles.push(makeCandle(t, 2003, 2006, 2001, 2004, 50) as never);

  const swings = detectSwings(candles as never, 2, 2);
  const { events } = detectStructureEvents(candles as never, swings);
  const mssEvents = events.filter((e) => e.type === 'MSS');
  suite.expectEqual(mssEvents.length, 0, 'Should not detect MSS without displacement');
});

// ─── FVG Detection ─────────────────────────────────────────────

suite.test('Bullish FVG: gap between candle 1 high and candle 3 low', () => {
  const { candles, fvgTop, fvgBottom } = makeBullishFVGTest(1700000000000);
  const structure = computeStructure(candles, 'M5', 2022, []);
  const fvgs = structure.fvgs.filter((f) => f.direction === 'bullish' && f.status === 'fresh');
  suite.expectTrue(fvgs.length > 0, 'Should detect at least one bullish FVG');
  const fvg = fvgs[0];
  suite.expectTrue(fvg.top >= fvgBottom, `FVG top ${fvg.top} should be >= ${fvgBottom}`);
  suite.expectTrue(fvg.bottom <= fvgTop, `FVG bottom ${fvg.bottom} should be <= ${fvgTop}`);
  suite.expectTrue(fvg.top > fvg.bottom, 'FVG top should be above bottom');
});

suite.test('Bearish FVG: gap between candle 1 low and candle 3 high', () => {
  const { candles, fvgTop, fvgBottom } = makeBearishFVGTest(1700000000000);
  const structure = computeStructure(candles, 'M5', 2005, []);
  const fvgs = structure.fvgs.filter((f) => f.direction === 'bearish' && f.status === 'fresh');
  suite.expectTrue(fvgs.length > 0, 'Should detect at least one bearish FVG');
  const fvg = fvgs[0];
  suite.expectTrue(fvg.top >= fvgBottom, `FVG top ${fvg.top} should be >= ${fvgBottom}`);
  suite.expectTrue(fvg.bottom <= fvgTop, `FVG bottom ${fvg.bottom} should be <= ${fvgTop}`);
});

suite.test('FVG should have correct CE (consequent entry) at 50% of gap', () => {
  const { candles } = makeBullishFVGTest(1700000000000);
  const structure = computeStructure(candles, 'M5', 2022, []);
  const fvgs = structure.fvgs.filter((f) => f.direction === 'bullish' && f.status === 'fresh');
  if (fvgs.length === 0) return; // skip if no FVG detected
  const fvg = fvgs[0];
  const expectedCE = (fvg.top + fvg.bottom) / 2;
  const tolerance = 0.01;
  suite.expectTrue(
    Math.abs(fvg.ce - expectedCE) < tolerance,
    `CE ${fvg.ce} should be close to ${expectedCE}`,
  );
});

// ─── IFVG Detection ────────────────────────────────────────────

suite.test('IFVG: invalidated FVG that flips creates IFVG', () => {
  // Create a bullish FVG, then price drops below its bottom (invalidating it)
  const { candles: fvgCandles } = makeBullishFVGTest(1700000000000);
  let t = fvgCandles[fvgCandles.length - 1].time + 60000;

  // Add candles that drop below the FVG bottom (2005)
  for (let i = 0; i < 5; i++) {
    fvgCandles.push(makeCandle(t, 2010 - i * 3, 2012 - i * 3, 2003 - i * 3, 2008 - i * 3, 200));
    t += 60000;
  }

  const structure = computeStructure(fvgCandles, 'M5', 1995, []);
  // IFVG should exist (the FVG that was invalidated and flipped)
  const ifvgs = structure.ifvgs;
  // Note: IFVG detection depends on implementation — at minimum, the original FVG should be invalidated
  const invalidatedFvgs = structure.fvgs.filter((f) => f.status === 'invalidated');
  suite.expectTrue(
    ifvgs.length > 0 || invalidatedFvgs.length > 0,
    'Should detect either an IFVG or an invalidated FVG after price drops below',
  );
});

// ─── BPR (Balance Price Range) Detection ───────────────────────

suite.test('BPR: price deviates and returns to a level', () => {
  // BPR detection requires specific market structure
  const candles: ReturnType<typeof makeCandle>[] = [];
  let t = 1700000000000;

  // Create a range
  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2000, 2005, 1998, 2002, 100));
    t += 60000;
  }
  // Deviation
  candles.push(makeCandle(t, 2002, 2015, 2000, 2012, 200));
  t += 60000;
  // Return
  candles.push(makeCandle(t, 2012, 2014, 2000, 2003, 150));
  t += 60000;

  const structure = computeStructure(candles, 'M5', 2003, []);
  // BPR detection may or may not trigger depending on implementation
  // Just verify it doesn't crash
  suite.expectTrue(Array.isArray(structure.bprs), 'BPRs should be an array');
});

// ─── Sweep Detection ───────────────────────────────────────────

suite.test('Liquidity sweep: price wicks beyond a level then closes back inside', () => {
  const { candles, sweepLevel } = makeBullishMSSTest(1700000000000);
  const structure = computeStructure(candles, 'M5', 2018, []);

  // After a bullish MSS, the low liquidity should be swept
  const sweptPools = structure.liquidity.filter((p) => p.swept);
  suite.expectTrue(sweptPools.length > 0, 'Should detect at least one swept liquidity pool');
  const sweptBelow = sweptPools.find((p) => p.side === 'below');
  if (sweptBelow) {
    suite.expectNotNull(sweptBelow.sweptAt, 'Swept pool should have sweptAt timestamp');
    suite.expectNotNull(sweptBelow.sweepExtreme, 'Swept pool should have sweepExtreme');
  }
});

// ─── Displacement Detection ────────────────────────────────────

suite.test('Displacement: large candle with body/range > 0.6 and ATR > 0.8', () => {
  const candles: ReturnType<typeof makeCandle>[] = [];
  let t = 1700000000000;

  // Normal candles
  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2000 + i, 2002 + i, 1999 + i, 2001 + i, 100));
    t += 60000;
  }
  // Large displacement candle
  const dispIdx = candles.length;
  candles.push(makeCandle(t, 2010, 2030, 2009, 2028, 300));
  t += 60000;

  const disp = computeDisplacement(candles, dispIdx);
  suite.expectTrue(disp.isDisplacement, 'Should detect displacement');
  suite.expectGreaterThan(disp.bodyRangeRatio, 0.6, 'Body/range ratio should be > 0.6');
  suite.expectGreaterThan(disp.atrMultiple, 0.8, 'ATR multiple should be > 0.8');
});

suite.test('Non-displacement: small doji candle should not be displacement', () => {
  const candles: ReturnType<typeof makeCandle>[] = [];
  let t = 1700000000000;

  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2000 + i, 2002 + i, 1999 + i, 2001 + i, 100));
    t += 60000;
  }
  const dojiIdx = candles.length;
  candles.push(makeCandle(t, 2005, 2006, 2004, 2005, 50));

  const disp = computeDisplacement(candles, dojiIdx);
  suite.expectFalse(disp.isDisplacement, 'Doji should not be displacement');
});

// ─── BOS / CHOCH ───────────────────────────────────────────────

suite.test('BOS: continuation break in direction of bias', () => {
  const candles: ReturnType<typeof makeCandle>[] = [];
  let t = 1700000000000;

  // Uptrend
  for (let i = 0; i < 15; i++) {
    candles.push(makeCandle(t, 2000 + i * 2, 2005 + i * 2, 1998 + i * 2, 2003 + i * 2, 100));
    t += 60000;
  }

  const swings = detectSwings(candles, 2, 2);
  const { events, bias } = detectStructureEvents(candles, swings);
  const bosEvents = events.filter((e) => e.type === 'BOS');
  suite.expectTrue(bosEvents.length > 0 || events.length > 0, 'Should detect structure events in a trend');
});

// ─── Run all tests ─────────────────────────────────────────────

suite.run();
