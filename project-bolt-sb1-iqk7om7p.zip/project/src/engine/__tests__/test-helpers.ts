// Test helpers: synthetic candle generators for deterministic testing.
import { Candle, Tick, Timeframe } from '../types';

export function makeCandle(
  time: number,
  open: number,
  high: number,
  low: number,
  close: number,
  volume: number = 100,
): Candle {
  return {
    time,
    open,
    high,
    low,
    close,
    volume,
    buyVolume: volume * 0.5,
    sellVolume: volume * 0.5,
    hasRealVolume: false,
  };
}

export function makeTick(
  time: number,
  bid: number,
  ask: number,
): Tick {
  const mid = (bid + ask) / 2;
  return {
    time,
    bid,
    ask,
    mid,
    spread: ask - bid,
    volume: 0,
    last: mid,
  };
}

// Generate a series of candles with a simple trend
export function makeTrendingCandles(
  startTime: number,
  count: number,
  intervalMs: number,
  startPrice: number,
  trendPerCandle: number,
): Candle[] {
  const candles: Candle[] = [];
  let price = startPrice;
  for (let i = 0; i < count; i++) {
    const open = price;
    const close = price + trendPerCandle;
    const high = Math.max(open, close) + Math.abs(trendPerCandle) * 0.3;
    const low = Math.min(open, close) - Math.abs(trendPerCandle) * 0.3;
    candles.push(makeCandle(startTime + i * intervalMs, open, high, low, close));
    price = close;
  }
  return candles;
}

// Generate candles that form a sweep + displacement + MSS pattern
// This creates a bullish MSS: price sweeps below a low, then displaces up through a high
export function makeBullishMSSTest(
  startTime: number,
  intervalMs: number = 60000,
): { candles: Candle[]; sweepTime: number; mssTime: number; sweepLevel: number; mssLevel: number } {
  const candles: Candle[] = [];
  let t = startTime;

  // Phase 1: Establish a range with a clear low (2000) and high (2010)
  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2005, 2010, 2000, 2005 + (i % 3), 100));
    t += intervalMs;
  }

  // Phase 2: Sweep below the low (wick to 1995) then close back inside
  const sweepTime = t;
  candles.push(makeCandle(t, 2000, 2002, 1995, 2003, 200)); // sweep low, close back inside
  t += intervalMs;

  // Phase 3: Displacement up — large bullish candle
  for (let i = 0; i < 3; i++) {
    candles.push(makeCandle(t, 2003 + i * 5, 2015 + i * 5, 2002 + i * 5, 2008 + i * 5, 300));
    t += intervalMs;
  }

  // Phase 4: Close above the high (2010) — MSS confirmed
  const mssTime = t;
  candles.push(makeCandle(t, 2012, 2020, 2010, 2018, 250));
  t += intervalMs;

  return {
    candles,
    sweepTime,
    mssTime,
    sweepLevel: 1995,
    mssLevel: 2010,
  };
}

// Generate candles that form a bearish MSS: price sweeps above a high, then displaces down through a low
export function makeBearishMSSTest(
  startTime: number,
  intervalMs: number = 60000,
): { candles: Candle[]; sweepTime: number; mssTime: number; sweepLevel: number; mssLevel: number } {
  const candles: Candle[] = [];
  let t = startTime;

  // Phase 1: Establish a range with a clear high (2010) and low (2000)
  for (let i = 0; i < 10; i++) {
    candles.push(makeCandle(t, 2005, 2010, 2000, 2005 - (i % 3), 100));
    t += intervalMs;
  }

  // Phase 2: Sweep above the high (wick to 2015) then close back inside
  const sweepTime = t;
  candles.push(makeCandle(t, 2010, 2015, 2008, 2007, 200));
  t += intervalMs;

  // Phase 3: Displacement down — large bearish candle
  for (let i = 0; i < 3; i++) {
    candles.push(makeCandle(t, 2007 - i * 5, 2008 - i * 5, 1995 - i * 5, 2002 - i * 5, 300));
    t += intervalMs;
  }

  // Phase 4: Close below the low (2000) — MSS confirmed
  const mssTime = t;
  candles.push(makeCandle(t, 2002, 2005, 1990, 1992, 250));
  t += intervalMs;

  return {
    candles,
    sweepTime,
    mssTime,
    sweepLevel: 2015,
    mssLevel: 2000,
  };
}

// Generate candles that create a bullish FVG (gap between candle i-1 high and i+1 low)
export function makeBullishFVGTest(
  startTime: number,
  intervalMs: number = 60000,
): { candles: Candle[]; fvgTime: number; fvgTop: number; fvgBottom: number } {
  const candles: Candle[] = [];
  let t = startTime;

  // Candle 1: normal range
  candles.push(makeCandle(t, 2000, 2005, 1998, 2003, 100));
  t += intervalMs;

  // Candle 2: large bullish displacement (creates FVG with candle 3)
  const fvgTime = t;
  candles.push(makeCandle(t, 2003, 2020, 2002, 2018, 300));
  t += intervalMs;

  // Candle 3: opens above candle 1's high, leaving a gap
  candles.push(makeCandle(t, 2018, 2025, 2016, 2022, 150));
  t += intervalMs;

  // FVG: between candle 1 high (2005) and candle 3 low (2016)
  return {
    candles,
    fvgTime,
    fvgTop: 2016,
    fvgBottom: 2005,
  };
}

// Generate candles that create a bearish FVG
export function makeBearishFVGTest(
  startTime: number,
  intervalMs: number = 60000,
): { candles: Candle[]; fvgTime: number; fvgTop: number; fvgBottom: number } {
  const candles: Candle[] = [];
  let t = startTime;

  // Candle 1: normal range
  candles.push(makeCandle(t, 2020, 2025, 2018, 2017, 100));
  t += intervalMs;

  // Candle 2: large bearish displacement
  const fvgTime = t;
  candles.push(makeCandle(t, 2017, 2018, 2000, 2002, 300));
  t += intervalMs;

  // Candle 3: opens below candle 1's low, leaving a gap
  candles.push(makeCandle(t, 2002, 2004, 1995, 1998, 150));
  t += intervalMs;

  // FVG: between candle 1 low (2018) and candle 3 high (2004)
  return {
    candles,
    fvgTime,
    fvgTop: 2018,
    fvgBottom: 2004,
  };
}

// Generate a full setup scenario with all ICT elements for testing evaluateSetupState
export function makeFullBullishSetup(
  startTime: number,
  intervalMs: number = 60000,
): {
  candles: Candle[];
  setupCreatedAt: number;
  sweepTime: number;
  displacementTime: number;
  mssTime: number;
  poiTime: number;
  retracementTime: number;
} {
  const candles: Candle[] = [];
  let t = startTime;

  // Phase 1: Establish HTF bullish bias (uptrend)
  for (let i = 0; i < 15; i++) {
    candles.push(makeCandle(t, 2000 + i * 2, 2005 + i * 2, 1998 + i * 2, 2003 + i * 2, 100));
    t += intervalMs;
  }

  const setupCreatedAt = t;

  // Phase 2: Create a liquidity pool below (sweep)
  for (let i = 0; i < 5; i++) {
    candles.push(makeCandle(t, 2030 - i, 2032, 2028 - i, 2031 - i, 100));
    t += intervalMs;
  }

  // Sweep below the recent low
  const sweepTime = t;
  candles.push(makeCandle(t, 2026, 2028, 2020, 2025, 200));
  t += intervalMs;

  // Phase 3: Displacement up
  const displacementTime = t;
  candles.push(makeCandle(t, 2025, 2040, 2024, 2038, 300));
  t += intervalMs;

  // Phase 4: MSS — close above the previous high
  const mssTime = t;
  candles.push(makeCandle(t, 2038, 2045, 2036, 2043, 250));
  t += intervalMs;

  // Phase 5: POI — create a bullish FVG
  const poiTime = t;
  candles.push(makeCandle(t, 2043, 2048, 2042, 2047, 200));
  t += intervalMs;
  candles.push(makeCandle(t, 2047, 2050, 2046, 2049, 150));
  t += intervalMs;

  // Phase 6: Retracement into POI
  const retracementTime = t;
  candles.push(makeCandle(t, 2049, 2050, 2040, 2042, 100));
  t += intervalMs;

  return {
    candles,
    setupCreatedAt,
    sweepTime,
    displacementTime,
    mssTime,
    poiTime,
    retracementTime,
  };
}

// Simple test runner
export class TestSuite {
  private tests: { name: string; fn: () => void | Promise<void> }[] = [];
  private passed = 0;
  private failed = 0;

  test(name: string, fn: () => void | Promise<void>) {
    this.tests.push({ name, fn });
  }

  expectEqual(actual: unknown, expected: unknown, msg?: string) {
    if (actual !== expected) {
      throw new Error(`Expected ${expected} but got ${actual}${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectTrue(actual: boolean, msg?: string) {
    if (!actual) {
      throw new Error(`Expected true but got false${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectFalse(actual: boolean, msg?: string) {
    if (actual) {
      throw new Error(`Expected false but got true${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectNotNull(actual: unknown, msg?: string) {
    if (actual === null || actual === undefined) {
      throw new Error(`Expected non-null but got ${actual}${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectNull(actual: unknown, msg?: string) {
    if (actual !== null && actual !== undefined) {
      throw new Error(`Expected null but got ${actual}${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectGreaterThan(actual: number, expected: number, msg?: string) {
    if (!(actual > expected)) {
      throw new Error(`Expected ${actual} > ${expected}${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectLessThan(actual: number, expected: number, msg?: string) {
    if (!(actual < expected)) {
      throw new Error(`Expected ${actual} < ${expected}${msg ? ` — ${msg}` : ''}`);
    }
  }

  expectArrayLength(actual: unknown[], expected: number, msg?: string) {
    if (actual.length !== expected) {
      throw new Error(`Expected length ${expected} but got ${actual.length}${msg ? ` — ${msg}` : ''}`);
    }
  }

  async run() {
    console.log('\n=== Running Tests ===\n');
    for (const { name, fn } of this.tests) {
      try {
        await fn();
        console.log(`  PASS: ${name}`);
        this.passed++;
      } catch (err) {
        console.log(`  FAIL: ${name}`);
        console.log(`        ${err instanceof Error ? err.message : String(err)}`);
        this.failed++;
      }
    }
    console.log(`\n=== Results: ${this.passed} passed, ${this.failed} failed ===\n`);
    if (this.failed > 0) process.exit(1);
  }
}
