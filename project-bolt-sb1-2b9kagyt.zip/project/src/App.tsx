import { useState, useEffect, useRef } from 'react';
import { MarketSnapshot, Timeframe, Candle, Tick as EngineTick, EngineMode, SetupState } from '@/engine/types';
import { simulateMarket, computePriceState, createFeedState, priceStateFromTick, updateFeedState } from '@/engine/market';
import { runPipeline, createPipelineState } from '@/engine/pipeline';
import { Dashboard } from '@/components/Dashboard';
import { recordSignal, recordSnapshot, recordOutcome } from '@/lib/journal';
import { fetchLatestQuote, fetchTickHistory, quoteToPriceState, fetchFeedStatus } from '@/lib/feed';
import { createOutcome, processOutcome, DEFAULT_OUTCOME_CONFIG, OutcomeResult } from '@/engine/outcome';

const TIMEFRAMES: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D', 'W'];
const TF_MIN: Record<Timeframe, number> = { M1: 1, M5: 5, M15: 15, H1: 60, H4: 240, D: 1440, W: 10080 };

interface SimTick { time: number; price: number; volume: number; buyVolume: number; sellVolume: number; }

function aggregateCandles(ticks: SimTick[], tf: Timeframe): Candle[] {
  const bucketMs = TF_MIN[tf] * 60 * 1000;
  const map = new Map<number, Candle>();
  for (const t of ticks) {
    const bucket = Math.floor(t.time / bucketMs) * bucketMs;
    let c = map.get(bucket);
    if (!c) {
      c = { time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: 0, buyVolume: 0, sellVolume: 0, hasRealVolume: false };
      map.set(bucket, c);
    }
    c.close = t.price;
    c.high = Math.max(c.high, t.price);
    c.low = Math.min(c.low, t.price);
    c.volume += t.volume;
    c.buyVolume += t.buyVolume;
    c.sellVolume += t.sellVolume;
  }
  return Array.from(map.values()).sort((a, b) => a.time - b.time);
}

function ticksFromFeed(feedTicks: EngineTick[]): SimTick[] {
  return feedTicks.map((t) => ({
    time: t.time,
    price: t.mid,
    volume: t.volume,
    buyVolume: t.buyVolume ?? 0,
    sellVolume: t.sellVolume ?? 0,
  }));
}

export function useLiveEngine() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const ticksRef = useRef<SimTick[]>([]);
  const momentumRef = useRef(0);
  const stepRef = useRef(0);
  const lastRecordRef = useRef<string>('');
  const lastSnapshotTimeRef = useRef(0);
  const pipelineStateRef = useRef(createPipelineState('PRODUCTION' as EngineMode));
  const feedRef = useRef(createFeedState('PRODUCTION' as EngineMode, 'MT5_BRIDGE', 'XAUUSD', 5000));
  const modeRef = useRef<'PRODUCTION' | 'DEMO'>('PRODUCTION');
  const lastSetupIdRef = useRef<string | null>(null);
  const lastRealTickRef = useRef<EngineTick | null>(null);
  const outcomeRef = useRef<OutcomeResult | null>(null);
  const outcomeSetupRef = useRef<SetupState | null>(null);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    let mounted = true;

    async function init() {
      const status = await fetchFeedStatus();
      if (!mounted) return;

      if (status.ready) {
        modeRef.current = 'PRODUCTION';
        pipelineStateRef.current = createPipelineState('PRODUCTION' as EngineMode);
        feedRef.current = createFeedState('PRODUCTION' as EngineMode, 'MT5_BRIDGE', 'XAUUSD', 5000);

        const history = await fetchTickHistory(2000);
        if (!mounted) return;
        if (history.length > 0) {
          ticksRef.current = ticksFromFeed(history);
          lastRealTickRef.current = history[history.length - 1];
        }
      } else {
        modeRef.current = 'DEMO';
        pipelineStateRef.current = createPipelineState('DEMO' as EngineMode);
        feedRef.current = createFeedState('DEMO' as EngineMode, 'DEMO_SIM', 'XAUUSD', 5000);

        const now = Date.now();
        const sim = simulateMarket({
          startTime: now - 3 * 24 * 60 * 60 * 1000,
          ticksPerMinute: 20,
          durationMinutes: 3 * 24 * 60,
          basePrice: 2650,
          seed: 42,
        });
        ticksRef.current = [...sim.ticks];
        momentumRef.current = 0;
        stepRef.current = 0;
      }

      startLoop();
    }

    function compute() {
      const ticks = ticksRef.current;
      if (ticks.length === 0) return;
      const lastTick = ticks[ticks.length - 1];
      const now = Date.now();

      let priceState;
      if (modeRef.current === 'PRODUCTION' && lastRealTickRef.current) {
        const feed = updateFeedState(feedRef.current, lastRealTickRef.current.time, now);
        feedRef.current = feed;
        priceState = priceStateFromTick(lastRealTickRef.current, feed, now);
      } else if (modeRef.current === 'PRODUCTION') {
        priceState = computePriceState([], feedRef.current, now);
      } else {
        const quotes = quotesFromTicksLocal(lastTick.price, lastTick.time);
        priceState = computePriceState(quotes, feedRef.current, lastTick.time);
      }

      const candles = {} as Record<Timeframe, Candle[]>;
      for (const tf of TIMEFRAMES) candles[tf] = aggregateCandles(ticks, tf);
      const snap = runPipeline(candles, priceState, now, pipelineStateRef.current);
      setSnapshot(snap);

      const setupId = snap.setup?.setupId ?? null;
      const isExecute = snap.plan.status === 'EXECUTE';

      // ── Outcome Engine: start tracking when EXECUTE is reached ──
      if (isExecute && setupId && setupId !== lastSetupIdRef.current) {
        lastSetupIdRef.current = setupId;
        recordSignal(snap, setupId);
        // Start outcome tracking
        if (snap.setup) {
          outcomeRef.current = createOutcome(setupId, snap.setup.direction);
          outcomeSetupRef.current = snap.setup;
        }
      }

      // Process outcome on every tick when we have an active outcome
      if (outcomeRef.current && outcomeSetupRef.current && lastRealTickRef.current) {
        const m1Candles = candles.M1;
        const currentCandle = m1Candles[m1Candles.length - 1];
        if (currentCandle) {
          // Use the most recent setup state from snapshot
          if (snap.setup) outcomeSetupRef.current = snap.setup;
          outcomeRef.current = processOutcome(
            outcomeRef.current,
            outcomeSetupRef.current,
            currentCandle,
            lastRealTickRef.current,
            DEFAULT_OUTCOME_CONFIG,
            now,
          );

          // If outcome closed/expired/expired, write result to DB
          const o = outcomeRef.current;
          if (o.status === 'closed' || o.status === 'expired' || o.status === 'invalidated') {
            recordOutcome(o);
            outcomeRef.current = null;
            outcomeSetupRef.current = null;
          }
        }
      }

      // Record 60s snapshots for active setups
      if (setupId && snap.setup && now - lastSnapshotTimeRef.current > 60000) {
        lastSnapshotTimeRef.current = now;
        recordSnapshot(snap, setupId);
      }
    }

    function startLoop() {
      compute();

      if (modeRef.current === 'PRODUCTION') {
        interval = setInterval(async () => {
          const quote = await fetchLatestQuote();
          if (!mounted) return;
          if (quote.status === 'CONNECTED' && quote.last != null && quote.bid != null && quote.ask != null) {
            const tick: EngineTick = {
              time: quote.timestamp,
              bid: quote.bid,
              ask: quote.ask,
              mid: (quote.bid + quote.ask) / 2,
              spread: quote.spread ?? quote.ask - quote.bid,
              volume: 0,
              last: quote.last,
            };
            lastRealTickRef.current = tick;
            ticksRef.current.push({
              time: tick.time,
              price: tick.mid,
              volume: 0,
              buyVolume: 0,
              sellVolume: 0,
            });
            if (ticksRef.current.length > 50000) {
              ticksRef.current = ticksRef.current.slice(-30000);
            }
          }
          compute();
        }, 3000);
      } else {
        const tickIntervalMs = 3000;
        const lastSimTick = ticksRef.current[ticksRef.current.length - 1];
        let price = lastSimTick?.price ?? 2650;

        interval = setInterval(() => {
          const regimes = [
            { vol: 0.35, drift: 0.0008 },
            { vol: 0.55, drift: -0.0012 },
            { vol: 0.7, drift: 0.0022 },
            { vol: 0.4, drift: 0.0005 },
          ];
          const regime = regimes[stepRef.current % regimes.length];
          const shock = (Math.random() - 0.5) * 2 * regime.vol;
          momentumRef.current = Math.max(-1.2, Math.min(1.2, momentumRef.current * 0.82 + shock * 0.35 + regime.drift));
          price += momentumRef.current;

          if (Math.random() < 0.004) price += (Math.random() - 0.5) * 4 * regime.vol;

          const buyBias = momentumRef.current > 0
            ? 0.55 + Math.abs(momentumRef.current) * 0.1
            : 0.45 - Math.abs(momentumRef.current) * 0.05;
          const vol = Math.max(0.5, 1 + Math.abs(momentumRef.current) * 3 + Math.random() * 2);
          const buy = vol * Math.min(0.85, Math.max(0.15, buyBias + (Math.random() - 0.5) * 0.2));

          const last = ticksRef.current[ticksRef.current.length - 1];
          ticksRef.current.push({
            time: (last?.time ?? Date.now()) + tickIntervalMs,
            price: Math.round(price * 100) / 100,
            volume: vol,
            buyVolume: buy,
            sellVolume: vol - buy,
          });

          if (ticksRef.current.length > 200000) {
            ticksRef.current = ticksRef.current.slice(-100000);
          }

          stepRef.current++;
          compute();
        }, tickIntervalMs);
      }
    }

    init();

    return () => {
      mounted = false;
      if (interval) clearInterval(interval);
    };
  }, []);

  return snapshot;
}

// Local version of quotesFromTicks for DEMO mode only
function quotesFromTicksLocal(tickPrice: number, tickTime: number) {
  const spread = 0.18 + 0.15;
  return [{
    provider: 'DEMO_SIM',
    bid: Math.round((tickPrice - spread / 2) * 100) / 100,
    ask: Math.round((tickPrice + spread / 2) * 100) / 100,
    last: Math.round(tickPrice * 100) / 100,
    timestamp: tickTime,
    receiveTime: tickTime,
    tickRate: 8,
    quality: 100,
  }];
}

export default function App() {
  const snapshot = useLiveEngine();
  return <Dashboard snapshot={snapshot} />;
}
