// Setup manager: creates and tracks stable setup IDs through the full
// lifecycle (MONITOR -> READY -> EXECUTE -> CLOSED).
// A new setup_id is created once when a distinct setup is detected and
// remains IDENTICAL through all stages until invalidated/expired/closed.

import { SetupState, SetupStage, SetupStatus, SetupStep, Direction, StructureBias, Timeframe, LiquidityPool, StructureEvent, FVG, OrderBlock, BreakerBlock, IFVG, MacroEvent } from './types';

let setupCounter: Record<string, number> = {};

export function generateSetupId(
  symbol: string,
  session: string,
  date: Date,
  direction: Direction,
): string {
  const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
  const dir = direction > 0 ? 'BUY' : direction < 0 ? 'SELL' : 'NEU';
  const key = `${symbol}-${session}-${dateStr}-${dir}`;
  setupCounter[key] = (setupCounter[key] || 0) + 1;
  return `${symbol}-${session}-${dateStr}-${String(setupCounter[key]).padStart(3, '0')}`;
}

export function createSetup(
  setupId: string,
  direction: Direction,
  htfBias: StructureBias,
  htfTimeframe: Timeframe,
  createdAt: number,
): SetupState {
  return {
    setupId,
    direction,
    status: 'MONITOR',
    currentStage: 'HTF_BIAS_CONFIRMED',
    steps: [
      { stage: 'HTF_BIAS_CONFIRMED', completed: true, detail: `${htfBias} bias on ${htfTimeframe}`, timestamp: createdAt },
      { stage: 'LIQUIDITY_TARGET_IDENTIFIED', completed: false, detail: '', timestamp: null },
      { stage: 'LIQUIDITY_SWEPT', completed: false, detail: '', timestamp: null },
      { stage: 'DISPLACEMENT', completed: false, detail: '', timestamp: null },
      { stage: 'MSS', completed: false, detail: '', timestamp: null },
      { stage: 'POI_IDENTIFIED', completed: false, detail: '', timestamp: null },
      { stage: 'RETRACEMENT_INTO_POI', completed: false, detail: '', timestamp: null },
      { stage: 'M1_TRIGGER', completed: false, detail: '', timestamp: null },
      { stage: 'READY', completed: false, detail: '', timestamp: null },
      { stage: 'EXECUTE', completed: false, detail: '', timestamp: null },
    ],
    createdAt,
    updatedAt: createdAt,
    htfBias,
    htfTimeframe,
    liquidityTarget: null,
    sweep: null,
    displacement: null,
    mss: null,
    poi: null,
    poiType: '',
    entryZoneMin: 0,
    entryZoneMax: 0,
    preferredEntry: 0,
    triggerPrice: 0,
    stopLoss: 0,
    targets: [],
    rR: [],
    invalidationReason: '',
    allowReasons: [],
    refuseReasons: [],
    nextMajorNews: null,
  };
}

const STAGE_ORDER: SetupStage[] = [
  'HTF_BIAS_CONFIRMED',
  'LIQUIDITY_TARGET_IDENTIFIED',
  'LIQUIDITY_SWEPT',
  'DISPLACEMENT',
  'MSS',
  'POI_IDENTIFIED',
  'RETRACEMENT_INTO_POI',
  'M1_TRIGGER',
  'READY',
  'EXECUTE',
];

export function advanceStage(setup: SetupState, stage: SetupStage, detail: string, time: number): SetupState {
  const steps = setup.steps.map((s) => {
    if (s.stage === stage) {
      return { ...s, completed: true, detail, timestamp: time };
    }
    return s;
  });

  const stageIdx = STAGE_ORDER.indexOf(stage);
  const currentStage = stageIdx >= 0 ? stage : setup.currentStage;

  let status: SetupStatus = setup.status;
  if (stage === 'EXECUTE') status = 'EXECUTE';
  else if (stage === 'READY') status = 'READY';
  else if (currentStage === 'HTF_BIAS_CONFIRMED' || currentStage === 'LIQUIDITY_TARGET_IDENTIFIED') status = 'MONITOR';
  else status = 'MONITOR';

  return {
    ...setup,
    steps,
    currentStage,
    status,
    updatedAt: time,
  };
}

export function invalidateSetup(setup: SetupState, reason: string, time: number): SetupState {
  const steps = setup.steps.map((s) =>
    s.stage === 'INVALIDATED' ? { ...s, completed: true, detail: reason, timestamp: time } : s,
  );
  return {
    ...setup,
    status: 'NO_TRADE',
    currentStage: 'INVALIDATED',
    steps,
    invalidationReason: reason,
    updatedAt: time,
  };
}

export function expireSetup(setup: SetupState, time: number): SetupState {
  const steps = setup.steps.map((s) =>
    s.stage === 'EXPIRED' ? { ...s, completed: true, detail: 'Setup expired — no trigger within timeout', timestamp: time } : s,
  );
  return {
    ...setup,
    status: 'NO_TRADE',
    currentStage: 'EXPIRED',
    steps,
    updatedAt: time,
  };
}

export function closeSetup(setup: SetupState, time: number): SetupState {
  const steps = setup.steps.map((s) =>
    s.stage === 'CLOSED' ? { ...s, completed: true, detail: 'Trade closed', timestamp: time } : s,
  );
  return {
    ...setup,
    status: 'NO_TRADE',
    currentStage: 'CLOSED',
    steps,
    updatedAt: time,
  };
}

// Check if a setup should be considered the same as a previous one
// (same direction, same HTF bias, not yet expired/closed)
export function isSameSetup(
  current: SetupState | null,
  direction: Direction,
  htfBias: StructureBias,
  htfTimeframe: Timeframe,
  time: number,
  maxAgeMs: number = 4 * 3600 * 1000,
): boolean {
  if (!current) return false;
  if (current.currentStage === 'CLOSED' || current.currentStage === 'INVALIDATED' || current.currentStage === 'EXPIRED') return false;
  if (current.direction !== direction) return false;
  if (current.htfBias !== htfBias) return false;
  if (current.htfTimeframe !== htfTimeframe) return false;
  if (time - current.createdAt > maxAgeMs) return false;
  return true;
}

export function setupProgressPercent(setup: SetupState | null): number {
  if (!setup) return 0;
  const completed = setup.steps.filter((s) => s.completed).length;
  const total = setup.steps.filter((s) => STAGE_ORDER.includes(s.stage)).length;
  return total > 0 ? Math.round((completed / total) * 100) : 0;
}

export function setupProgressSteps(setup: SetupState | null): SetupStep[] {
  if (!setup) return [];
  return setup.steps.filter((s) => STAGE_ORDER.includes(s.stage));
}
