// Master pipeline: orchestrates all engines into a MarketSnapshot.
// Uses the SAME engine for live and backtest — no special backtest logic.

import {
  Candle, MarketSnapshot, Timeframe, PriceState, QualityReport,
  StructureState, MicrostructureState, VolumeProfile, VWAPSet,
  CorrelationState, OptionsState, MacroEvent, NewsItem, GeoEvent,
  LiquidityPool, Scenario, AgentSignal, TradePlan, AlertItem,
  SetupState, EngineMode,
} from './types';
import { computeStructure } from './structure';
import { computeMicrostructure } from './microstructure';
import { computeVolumeProfile, computeVWAPSet, atr } from './indicators';
import {
  detectRegime, computeCorrelations, computeOptionsState,
  generateMacroEvents, generateNews, generateGeoEvents,
} from './context';
import {
  fuseAgents, buildScenarios, detectConflicts, computeEV,
  buildTradePlan, generateAlerts, evaluateSetupState, planToJournal,
} from './decision';
import { computeSessions, getSessionLevels } from './sessions';
import { computeDataQuality, isTradeable } from './quality';

export interface PipelineState {
  mode: EngineMode;
  currentSetup: SetupState | null;
  lastSetupDirection: number | null;
}

export function createPipelineState(mode: EngineMode): PipelineState {
  return { mode, currentSetup: null, lastSetupDirection: null };
}

export function runPipeline(
  candles: Record<Timeframe, Candle[]>,
  price: PriceState,
  currentTime: number,
  state: PipelineState,
): MarketSnapshot {
  const currentPrice = price.median > 0 ? price.median : candles.H1?.[candles.H1.length - 1]?.close ?? 0;

  // Data quality
  const quality = computeDataQuality(price, candles, currentTime);

  // Sessions
  const sessions = computeSessions(candles.H1 ?? [], currentTime);
  const sessionLevels = getSessionLevels(sessions);

  // Structure per timeframe — pass session levels for liquidity
  const tfs: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D', 'W'];
  const structure: Record<Timeframe, StructureState> = {} as Record<Timeframe, StructureState>;
  for (const tf of tfs) {
    structure[tf] = computeStructure(candles[tf] ?? [], tf, currentPrice, sessionLevels);
  }

  // Microstructure from M1
  const microSwings = structure.M5?.swings.map((s) => ({ type: s.type, price: s.price })) ?? [];
  const microstructure: MicrostructureState = computeMicrostructure(candles.M1 ?? [], microSwings);

  // Volume profile from H1 session
  const volumeProfile: VolumeProfile = computeVolumeProfile(candles.H1?.slice(-48) ?? [], 40, sessions.london.start);

  // VWAP — anchored to real day/week/session boundaries
  const vwap: VWAPSet = computeVWAPSet(
    candles.H1 ?? [],
    candles.D ?? [],
    candles.W ?? [],
    sessions.london.start,
    sessions.london.end,
    {
      candles: candles.H1?.slice(-72) ?? [],
      anchorTime: sessions.dailyOpen > 0 ? sessions.dailyOpen : currentTime,
      anchorReason: 'Daily open',
    },
  );

  // Correlations (disabled in production until external feed connected)
  const correlations: CorrelationState = computeCorrelations(candles.H1?.slice(-50) ?? [], state.mode);

  // Options (disabled until options feed connected)
  const options: OptionsState = computeOptionsState(candles.H1?.slice(-50) ?? [], currentPrice, state.mode);

  // Macro, news, geo — empty in production, illustrative in DEMO
  const macro: MacroEvent[] = generateMacroEvents(currentTime, state.mode);
  const news: NewsItem[] = generateNews(currentTime, state.mode);
  const geo: GeoEvent[] = generateGeoEvents(currentTime, state.mode);

  // Regime
  const { regime, label } = detectRegime(candles);

  // Agent fusion (contextual signals only — not the trade trigger)
  const agents: AgentSignal[] = fuseAgents({
    regime,
    structure,
    micro: microstructure,
    correlations,
    options,
    macro,
    news,
    geo,
    price: currentPrice,
    candles,
    sessions,
    quality,
  });

  // Scenarios (for display only)
  const scenarios: Scenario[] = buildScenarios({
    regime, structure, micro: microstructure, correlations, options,
    macro, news, geo, price: currentPrice, candles, sessions, quality,
  }, agents);

  // Conflicts
  const conflicts = detectConflicts(agents);

  // EV
  const main = scenarios[0];
  const entryMid = main ? (main.entry[0] + main.entry[1]) / 2 : currentPrice;
  const ev = main ? computeEV(scenarios, main.invalidation, entryMid) : 0;

  // Setup state machine — this is the actual trade logic
  const setup = evaluateSetupState({
    structure,
    sessions,
    micro: microstructure,
    price: currentPrice,
    candles,
    macro,
    currentSetup: state.currentSetup,
    quality,
  }, currentTime);

  // Update pipeline state
  if (setup) {
    if (setup.status === 'NO_TRADE' && (setup.currentStage === 'INVALIDATED' || setup.currentStage === 'EXPIRED' || setup.currentStage === 'CLOSED')) {
      state.currentSetup = null;
      state.lastSetupDirection = null;
    } else {
      state.currentSetup = setup;
      state.lastSetupDirection = setup.direction;
    }
  }

  // Trade plan from setup state machine
  const plan: TradePlan = buildTradePlan({
    regime, structure, micro: microstructure, correlations, options,
    macro, news, geo, price: currentPrice, candles, sessions, quality,
  }, agents, scenarios, conflicts, ev, setup);
  plan.regimeLabel = label;

  // Alerts
  const alerts: AlertItem[] = generateAlerts(plan, {
    regime, structure, micro: microstructure, correlations, options,
    macro, news, geo, price: currentPrice, candles, sessions, quality,
  });

  return {
    time: currentTime,
    price,
    candles,
    regime,
    regimeLabel: label,
    structure,
    microstructure,
    volumeProfile,
    vwap,
    correlations,
    options,
    macro,
    news,
    geo,
    liquidities: structure.H1?.liquidity ?? [],
    scenarios,
    agents,
    plan,
    alerts,
    quality,
    sessions,
    setup,
  };
}

export { isTradeable, atr, planToJournal };
