// Market structure engine: swing detection, BOS/CHOCH/MSS, FVG, IFVG,
// Order Blocks, Breaker Blocks, Mitigation Blocks, BPR,
// premium/discount dealing ranges, liquidity mapping with persistent sweep state.

import {
  Candle, SwingPoint, StructureEvent, StructureEventType, StructureBias,
  FVG, IFVG, OrderBlock, BreakerBlock, MitigationBlock, BPR,
  LiquidityPool, DealingRange, Timeframe, StructureState, DisplacementInfo,
  LiquidityType, LiquiditySide, FVGStatus, BlockStatus,
} from './types';
import { atr } from './indicators';

// ─── Swing Detection ────────────────────────────────────────────

export function detectSwings(candles: Candle[], leftBars = 3, rightBars = 3, minATR = 0.5): SwingPoint[] {
  const swings: SwingPoint[] = [];
  const atrVal = atr(candles, 14) || 1;
  const minAmp = atrVal * minATR;

  for (let i = leftBars; i < candles.length - rightBars; i++) {
    const c = candles[i];
    let isHigh = true, isLow = true;
    for (let j = i - leftBars; j <= i + rightBars; j++) {
      if (j === i) continue;
      if (candles[j].high >= c.high) isHigh = false;
      if (candles[j].low <= c.low) isLow = false;
    }
    const window = candles.slice(i - leftBars, i + rightBars + 1);
    if (isHigh && c.high - Math.min(...window.map((x) => x.low)) >= minAmp) {
      const cls = classifySwing(candles, i, atrVal);
      swings.push({ time: c.time, price: c.high, type: 'high', class: cls, strength: 0 });
    }
    if (isLow && Math.max(...window.map((x) => x.high)) - c.low >= minAmp) {
      const cls = classifySwing(candles, i, atrVal);
      swings.push({ time: c.time, price: c.low, type: 'low', class: cls, strength: 0 });
    }
  }

  for (let i = 0; i < swings.length; i++) {
    swings[i].strength = computeSwingStrength(swings, i);
  }

  return swings;
}

function classifySwing(candles: Candle[], idx: number, atrVal: number): SwingPoint['class'] {
  const lookback = Math.min(idx, 50);
  const range = candles.slice(Math.max(0, idx - lookback), idx + 1);
  const hi = Math.max(...range.map((c) => c.high));
  const lo = Math.min(...range.map((c) => c.low));
  const span = (hi - lo) / atrVal;
  if (span > 20) return 'major';
  if (span > 10) return 'external';
  if (span > 5) return 'intermediate';
  if (span > 2) return 'internal';
  return 'micro';
}

function computeSwingStrength(swings: SwingPoint[], idx: number): number {
  let strength = 0;
  for (let i = Math.max(0, idx - 5); i <= Math.min(swings.length - 1, idx + 5); i++) {
    const dist = Math.abs(i - idx);
    const clsWeight = { micro: 1, internal: 2, intermediate: 3, external: 4, major: 5 }[swings[i].class];
    strength += clsWeight / (1 + dist);
  }
  return Math.round(strength * 10) / 10;
}

// ─── Displacement ───────────────────────────────────────────────

export function computeDisplacement(candles: Candle[], idx: number): DisplacementInfo {
  const atrVal = atr(candles, 14) || 1;
  if (idx < 0 || idx >= candles.length) {
    return { bodyRangeRatio: 0, atrMultiple: 0, closedBeyond: false, expansion: 0, fvgCreated: false, isDisplacement: false };
  }
  const c = candles[idx];
  const prev = idx > 0 ? candles[idx - 1] : c;
  const range = c.high - c.low;
  const body = Math.abs(c.close - c.open);
  const bodyRangeRatio = range > 0 ? body / range : 0;
  const atrMultiple = atrVal > 0 ? range / atrVal : 0;
  const expansion = atrVal > 0 ? Math.abs(c.close - prev.close) / atrVal : 0;

  const fvgCreated = idx < candles.length - 1 && idx > 0
    ? hasFVG(candles, idx)
    : false;

  const isDisplacement = bodyRangeRatio > 0.6 && atrMultiple > 0.8 && expansion > 0.5;

  return {
    bodyRangeRatio: Math.round(bodyRangeRatio * 100) / 100,
    atrMultiple: Math.round(atrMultiple * 100) / 100,
    closedBeyond: bodyRangeRatio > 0.5,
    expansion: Math.round(expansion * 100) / 100,
    fvgCreated,
    isDisplacement,
  };
}

function hasFVG(candles: Candle[], idx: number): boolean {
  if (idx < 1 || idx >= candles.length - 1) return false;
  const c1 = candles[idx - 1];
  const c3 = candles[idx + 1];
  return c1.high < c3.low || c1.low > c3.high;
}

// ─── Structure Events (BOS / CHOCH / MSS) ───────────────────────
//
// For each swing break we:
//   1. Identify the swing that was broken
//   2. Measure displacement on the break candle
//   3. Determine the prior context (was bias already established?)
//   4. Classify: BOS (continuation), CHOCH (first reversal), MSS (sweep + displacement + reversal)
//
// MSS is NOT a simple breakout — it requires:
//   - A liquidity sweep (price wicks beyond a swing then closes back inside)
//   - Displacement (body/range > 0.6, ATR multiple > 0.8)
//   - A closed candle confirming reversal
//
// BOS: price closes beyond a swing in the direction of the existing bias.
// CHOCH: price closes beyond a swing against the existing bias (first reversal signal).
// MSS: price sweeps liquidity beyond a swing, then reverses with displacement.

export interface StructureContext {
  priorBias: StructureBias;
  priorHighRef: number | null;
  priorLowRef: number | null;
}

export function detectStructureEvents(
  candles: Candle[],
  swings: SwingPoint[],
): { bias: StructureBias; events: StructureEvent[]; lastEvent: StructureEvent | null } {
  if (swings.length < 3 || candles.length < 5) {
    return { bias: 'neutral', events: [], lastEvent: null };
  }

  const atrVal = atr(candles, 14) || 1;
  const events: StructureEvent[] = [];
  let bias: StructureBias = 'neutral';
  let lastBrokenHigh: number | null = null;
  let lastBrokenLow: number | null = null;

  // Walk through candles chronologically and detect breaks of swing levels.
  const swingHighs = swings.filter((s) => s.type === 'high').sort((a, b) => a.time - b.time);
  const swingLows = swings.filter((s) => s.type === 'low').sort((a, b) => a.time - b.time);

  // Track the most recent *confirmed* swing levels that haven't been broken yet.
  let activeHigh: SwingPoint | null = null;
  let activeLow: SwingPoint | null = null;
  let nextHighIdx = 0;
  let nextLowIdx = 0;

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];

    // Update active swing levels: a swing is confirmed after rightBars candles
    // have passed. We use the swing time to determine if it was formed before this candle.
    while (nextHighIdx < swingHighs.length && swingHighs[nextHighIdx].time < c.time) {
      if (swingHighs[nextHighIdx].price > (activeHigh?.price ?? -Infinity) || activeHigh === null) {
        activeHigh = swingHighs[nextHighIdx];
      } else {
        // A lower high was formed — if bias was bullish, this is potential CHOCH territory
        // but we only flag events on actual breaks, not on swing formation.
      }
      nextHighIdx++;
    }
    while (nextLowIdx < swingLows.length && swingLows[nextLowIdx].time < c.time) {
      if (swingLows[nextLowIdx].price < (activeLow?.price ?? Infinity) || activeLow === null) {
        activeLow = swingLows[nextLowIdx];
      }
      nextLowIdx++;
    }

    if (!activeHigh && !activeLow) continue;

    // Check for bullish break (close above active high)
    if (activeHigh && c.close > activeHigh.price) {
      const disp = computeDisplacement(candles, i);
      const sweptLow = activeLow && candles.slice(Math.max(0, i - 3), i + 1).some((x) => x.low < activeLow!.price);
      const reversedUp = c.close > activeHigh.price;

      let eventType: StructureEventType;
      let confirmed = false;
      let context = '';

      if (sweptLow && disp.isDisplacement && reversedUp) {
        // Sweep of low + displacement up = MSS
        eventType = 'MSS';
        confirmed = true;
        context = `Sweep of low ${activeLow!.price} then displacement close above ${activeHigh.price}`;
      } else if (bias === 'bearish' || bias === 'ranging' as StructureBias) {
        // Break against prior bearish bias = CHOCH
        eventType = 'CHOCH';
        confirmed = disp.isDisplacement;
        context = `Close above ${activeHigh.price} against prior ${bias} bias`;
      } else {
        // Break in direction of existing bullish bias = BOS
        eventType = 'BOS';
        confirmed = disp.isDisplacement;
        context = `Continuation close above ${activeHigh.price}`;
      }

      events.push({
        type: eventType,
        direction: 'bullish',
        level: activeHigh.price,
        time: c.time,
        confirmed,
        displacement: disp.atrMultiple,
        closedBeyond: true,
        fvgCreated: disp.fvgCreated,
        context,
      });

      if (confirmed) {
        bias = 'bullish';
        lastBrokenHigh = activeHigh.price;
        activeHigh = null;
      }
    }

    // Check for bearish break (close below active low)
    if (activeLow && c.close < activeLow.price) {
      const disp = computeDisplacement(candles, i);
      const sweptHigh = activeHigh && candles.slice(Math.max(0, i - 3), i + 1).some((x) => x.high > activeHigh!.price);
      const reversedDown = c.close < activeLow.price;

      let eventType: StructureEventType;
      let confirmed = false;
      let context = '';

      if (sweptHigh && disp.isDisplacement && reversedDown) {
        eventType = 'MSS';
        confirmed = true;
        context = `Sweep of high ${activeHigh!.price} then displacement close below ${activeLow.price}`;
      } else if (bias === 'bullish' || bias === 'ranging' as StructureBias) {
        eventType = 'CHOCH';
        confirmed = disp.isDisplacement;
        context = `Close below ${activeLow.price} against prior ${bias} bias`;
      } else {
        eventType = 'BOS';
        confirmed = disp.isDisplacement;
        context = `Continuation close below ${activeLow.price}`;
      }

      events.push({
        type: eventType,
        direction: 'bearish',
        level: activeLow.price,
        time: c.time,
        confirmed,
        displacement: disp.atrMultiple,
        closedBeyond: true,
        fvgCreated: disp.fvgCreated,
        context,
      });

      if (confirmed) {
        bias = 'bearish';
        lastBrokenLow = activeLow.price;
        activeLow = null;
      }
    }
  }

  // Determine final bias from confirmed events
  const confirmedEvents = events.filter((e) => e.confirmed);
  const lastConfirmed = confirmedEvents[confirmedEvents.length - 1] || null;

  if (lastConfirmed) {
    bias = lastConfirmed.direction === 'bullish' ? 'bullish' : 'bearish';
  } else if (events.length > 0) {
    // Check for ranging pattern (alternating breaks)
    const recentEvents = events.slice(-4);
    const bullCount = recentEvents.filter((e) => e.direction === 'bullish').length;
    const bearCount = recentEvents.filter((e) => e.direction === 'bearish').length;
    if (bullCount > 0 && bearCount > 0 && Math.abs(bullCount - bearCount) <= 1) {
      bias = 'ranging';
    }
  }

  return { bias, events, lastEvent: lastConfirmed || events[events.length - 1] || null };
}

// ─── FVG Detection ──────────────────────────────────────────────

export function detectFVGs(candles: Candle[], timeframe: Timeframe): FVG[] {
  const fvgs: FVG[] = [];
  const atrVal = atr(candles, 14) || 1;

  for (let i = 1; i < candles.length - 1; i++) {
    const c1 = candles[i - 1];
    const c3 = candles[i + 1];

    // Bullish FVG: c1.high < c3.low
    if (c1.high < c3.low) {
      const top = c3.low;
      const bottom = c1.high;
      const size = top - bottom;
      const atrRatio = size / atrVal;
      if (atrRatio > 0.3) {
        const fillInfo = analyzeFills(candles, i + 2, top, bottom);
        fvgs.push({
          id: `fvg-${timeframe}-${i}`,
          time: candles[i].time,
          top: Math.round(top * 100) / 100,
          bottom: Math.round(bottom * 100) / 100,
          ce: Math.round(((top + bottom) / 2) * 100) / 100,
          direction: 'bullish',
          size: Math.round(size * 100) / 100,
          atrRatio: Math.round(atrRatio * 100) / 100,
          ageBars: candles.length - i - 1,
          fills: fillInfo.count,
          fillPct: fillInfo.fillPct,
          status: fillInfo.status,
          timeframe,
          quality: Math.round(Math.min(100, atrRatio * 30 + (fillInfo.count === 0 ? 40 : 0)) * 10) / 10,
          mitigatedAt: fillInfo.mitigatedAt,
        });
      }
    }

    // Bearish FVG: c1.low > c3.high
    if (c1.low > c3.high) {
      const top = c1.low;
      const bottom = c3.high;
      const size = top - bottom;
      const atrRatio = size / atrVal;
      if (atrRatio > 0.3) {
        const fillInfo = analyzeFills(candles, i + 2, top, bottom);
        fvgs.push({
          id: `fvg-${timeframe}-${i}`,
          time: candles[i].time,
          top: Math.round(top * 100) / 100,
          bottom: Math.round(bottom * 100) / 100,
          ce: Math.round(((top + bottom) / 2) * 100) / 100,
          direction: 'bearish',
          size: Math.round(size * 100) / 100,
          atrRatio: Math.round(atrRatio * 100) / 100,
          ageBars: candles.length - i - 1,
          fills: fillInfo.count,
          fillPct: fillInfo.fillPct,
          status: fillInfo.status,
          timeframe,
          quality: Math.round(Math.min(100, atrRatio * 30 + (fillInfo.count === 0 ? 40 : 0)) * 10) / 10,
          mitigatedAt: fillInfo.mitigatedAt,
        });
      }
    }
  }

  return fvgs.filter((f) => f.status !== 'invalidated').slice(-20);
}

interface FillInfo {
  count: number;
  fillPct: number;
  status: FVGStatus;
  mitigatedAt: number | null;
}

function analyzeFills(candles: Candle[], fromIdx: number, top: number, bottom: number): FillInfo {
  let count = 0;
  let maxPenetration = 0;
  let mitigatedAt: number | null = null;
  const gapSize = top - bottom;

  for (let i = fromIdx; i < candles.length; i++) {
    const c = candles[i];
    if (c.low <= top && c.high >= bottom) {
      count++;
      // Measure how much of the gap was filled
      const penetration = Math.min(top, c.high) - Math.max(bottom, c.low);
      maxPenetration = Math.max(maxPenetration, penetration / gapSize);
      if (penetration / gapSize >= 0.8 && !mitigatedAt) {
        mitigatedAt = c.time;
      }
    }
  }

  let status: FVGStatus;
  if (count === 0) status = 'fresh';
  else if (maxPenetration < 0.5) status = 'touched';
  else if (maxPenetration < 0.8) status = 'partial_fill';
  else if (maxPenetration < 1.0) status = 'mitigated';
  else status = 'invalidated';

  return { count, fillPct: Math.round(maxPenetration * 100) / 100, status, mitigatedAt };
}

// ─── IFVG Detection ─────────────────────────────────────────────
// An IFVG (Inversion FVG) occurs when price closes completely through
// a FVG in the opposite direction of its origin. The key insight is
// that the VIOLATION (full traversal) is what creates the inversion —
// not just mitigation. A bullish FVG that price closes below becomes
// bearish resistance; a bearish FVG that price closes above becomes
// bullish support. We include invalidated FVGs because the full
// traversal is the inversion signal.

export function detectIFVGs(candles: Candle[], fvgs: FVG[], timeframe: Timeframe): IFVG[] {
  const ifvgs: IFVG[] = [];

  for (const fvg of fvgs) {
    // Include mitigated, partial_fill, AND invalidated FVGs.
    // A fully traversed (invalidated) FVG is the strongest inversion candidate.
    if (fvg.status === 'fresh') continue;

    // Find where price first entered the FVG zone
    const fvgIdx = candles.findIndex((c) => c.time === fvg.time);
    if (fvgIdx < 0 || fvgIdx >= candles.length - 1) continue;

    // Look for a close completely through the FVG in the opposite direction
    // after the FVG was created. This is the inversion candle.
    const scanEnd = Math.min(candles.length, fvgIdx + 20);
    let inversionIdx = -1;

    for (let i = fvgIdx + 1; i < scanEnd; i++) {
      const c = candles[i];
      if (fvg.direction === 'bullish') {
        // Bullish FVG inverted when price closes below its bottom
        if (c.close < fvg.bottom) {
          inversionIdx = i;
          break;
        }
      } else {
        // Bearish FVG inverted when price closes above its top
        if (c.close > fvg.top) {
          inversionIdx = i;
          break;
        }
      }
    }

    if (inversionIdx < 0) continue;

    const invDirection = fvg.direction === 'bullish' ? 'bearish' : 'bullish';
    const ifvg: IFVG = {
      id: `ifvg-${timeframe}-${fvg.id}`,
      time: candles[inversionIdx].time,
      top: fvg.top,
      bottom: fvg.bottom,
      ce: fvg.ce,
      direction: invDirection,
      size: fvg.size,
      timeframe,
      status: 'fresh',
      mitigatedAt: null,
      originFvgId: fvg.id,
    };

    // Check if the IFVG itself has been mitigated (price returned to fill it)
    const invFillInfo = analyzeFills(candles, inversionIdx + 1, fvg.top, fvg.bottom);
    if (invFillInfo.status === 'mitigated' || invFillInfo.status === 'invalidated') {
      ifvg.status = 'mitigated';
      ifvg.mitigatedAt = invFillInfo.mitigatedAt;
    }
    ifvgs.push(ifvg);
  }

  return ifvgs.filter((i) => i.status !== 'invalidated');
}

// ─── Order Blocks ───────────────────────────────────────────────

export function detectOrderBlocks(candles: Candle[], timeframe: Timeframe): OrderBlock[] {
  const obs: OrderBlock[] = [];
  const atrVal = atr(candles, 14) || 1;

  for (let i = 2; i < candles.length - 3; i++) {
    const c = candles[i];
    const after = candles.slice(i + 1, i + 6);
    if (after.length < 3) continue;

    // Bullish OB: last bearish candle before upward displacement
    if (c.close < c.open) {
      const displacement = (Math.max(...after.map((x) => x.high)) - c.low) / atrVal;
      if (displacement > 1.5) {
        const fvgAfter = after.some((_, j) => {
          const ai = i + 1 + j;
          return ai < candles.length - 1 && hasFVG(candles, ai);
        });
        const mitigated = candles.slice(i + 4).some((x) => x.low <= c.high && x.low >= c.low);
        const mitigationTime = mitigated
          ? candles.slice(i + 4).find((x) => x.low <= c.high && x.low >= c.low)?.time ?? null
          : null;
        const score = scoreOB(displacement, true, fvgAfter, c.volume, mitigated);
        obs.push({
          id: `ob-${timeframe}-${i}`,
          time: c.time,
          top: Math.round(c.high * 100) / 100,
          bottom: Math.round(c.low * 100) / 100,
          ce: Math.round(((c.high + c.low) / 2) * 100) / 100,
          direction: 'bullish',
          displacement: Math.min(20, Math.round(displacement * 5)),
          structureBreak: 15,
          fvgAssoc: fvgAfter ? 10 : 5,
          volume: Math.min(15, Math.round((c.volume / (atrVal * 100)) * 10)),
          freshness: mitigated ? 3 : 10,
          premiumDiscount: 7,
          confluence: 8,
          score,
          status: mitigated ? 'mitigated' : 'fresh',
          mitigatedAt: mitigationTime,
          timeframe,
        });
      }
    }

    // Bearish OB: last bullish candle before downward displacement
    if (c.close > c.open) {
      const displacement = (c.high - Math.min(...after.map((x) => x.low))) / atrVal;
      if (displacement > 1.5) {
        const fvgAfter = after.some((_, j) => {
          const ai = i + 1 + j;
          return ai < candles.length - 1 && hasFVG(candles, ai);
        });
        const mitigated = candles.slice(i + 4).some((x) => x.high >= c.low && x.high <= c.high);
        const mitigationTime = mitigated
          ? candles.slice(i + 4).find((x) => x.high >= c.low && x.high <= c.high)?.time ?? null
          : null;
        const score = scoreOB(displacement, true, fvgAfter, c.volume, mitigated);
        obs.push({
          id: `ob-${timeframe}-${i}`,
          time: c.time,
          top: Math.round(c.high * 100) / 100,
          bottom: Math.round(c.low * 100) / 100,
          ce: Math.round(((c.high + c.low) / 2) * 100) / 100,
          direction: 'bearish',
          displacement: Math.min(20, Math.round(displacement * 5)),
          structureBreak: 15,
          fvgAssoc: fvgAfter ? 10 : 5,
          volume: Math.min(15, Math.round((c.volume / (atrVal * 100)) * 10)),
          freshness: mitigated ? 3 : 10,
          premiumDiscount: 7,
          confluence: 8,
          score,
          status: mitigated ? 'mitigated' : 'fresh',
          mitigatedAt: mitigationTime,
          timeframe,
        });
      }
    }
  }

  return obs.filter((o) => o.status === 'fresh' && o.score > 50).slice(-10);
}

function scoreOB(displacement: number, structBreak: boolean, fvg: boolean, volume: number, mitigated: boolean): number {
  const d = Math.min(20, Math.round(displacement * 5));
  const s = structBreak ? 15 : 5;
  const f = fvg ? 12 : 5;
  const v = Math.min(15, Math.round(volume));
  const fr = mitigated ? 3 : 10;
  return Math.min(100, d + s + f + v + fr + 7 + 8);
}

// ─── Breaker Blocks ─────────────────────────────────────────────
// A breaker block is a failed order block that, after being violated,
// flips polarity and acts as a new support/resistance in the opposite direction.

export function detectBreakerBlocks(candles: Candle[], timeframe: Timeframe): BreakerBlock[] {
  const breakers: BreakerBlock[] = [];
  const atrVal = atr(candles, 14) || 1;

  for (let i = 3; i < candles.length - 4; i++) {
    const c = candles[i];
    const before = candles.slice(Math.max(0, i - 4), i);
    const after = candles.slice(i + 1, i + 5);
    if (before.length < 2 || after.length < 2) continue;

    // Bullish breaker: bearish candle that broke below a prior low, then price
    // reversed back above it with displacement — the failed breakdown becomes support.
    const priorLow = Math.min(...before.map((x) => x.low));
    const brokeBelow = c.close < priorLow;
    const reversedUp = after.some((x) => x.close > priorLow);
    const disp = (Math.max(...after.map((x) => x.high)) - c.low) / atrVal;

    if (brokeBelow && reversedUp && disp > 1.0) {
      const mitigated = candles.slice(i + 4).some((x) => x.low <= c.high && x.low >= c.low);
      breakers.push({
        id: `brk-${timeframe}-${i}`,
        time: c.time,
        top: Math.round(c.high * 100) / 100,
        bottom: Math.round(c.low * 100) / 100,
        ce: Math.round(((c.high + c.low) / 2) * 100) / 100,
        direction: 'bullish',
        size: Math.round((c.high - c.low) * 100) / 100,
        timeframe,
        status: mitigated ? 'mitigated' : 'fresh',
        mitigatedAt: mitigated ? candles.slice(i + 4).find((x) => x.low <= c.high && x.low >= c.low)?.time ?? null : null,
      });
    }

    // Bearish breaker: bullish candle that broke above a prior high, then price
    // reversed back below it with displacement.
    const priorHigh = Math.max(...before.map((x) => x.high));
    const brokeAbove = c.close > priorHigh;
    const reversedDown = after.some((x) => x.close < priorHigh);
    const dispDn = (c.high - Math.min(...after.map((x) => x.low))) / atrVal;

    if (brokeAbove && reversedDown && dispDn > 1.0) {
      const mitigated = candles.slice(i + 4).some((x) => x.high >= c.low && x.high <= c.high);
      breakers.push({
        id: `brk-${timeframe}-${i}`,
        time: c.time,
        top: Math.round(c.high * 100) / 100,
        bottom: Math.round(c.low * 100) / 100,
        ce: Math.round(((c.high + c.low) / 2) * 100) / 100,
        direction: 'bearish',
        size: Math.round((c.high - c.low) * 100) / 100,
        timeframe,
        status: mitigated ? 'mitigated' : 'fresh',
        mitigatedAt: mitigated ? candles.slice(i + 4).find((x) => x.high >= c.low && x.high <= c.high)?.time ?? null : null,
      });
    }
  }

  return breakers.filter((b) => b.status === 'fresh').slice(-6);
}

// ─── Mitigation Blocks ──────────────────────────────────────────
// A mitigation block is the last opposite-colored candle before a strong
// directional move that creates an order block. It represents where
// unfilled orders were left behind.

export function detectMitigationBlocks(candles: Candle[], timeframe: Timeframe): MitigationBlock[] {
  const blocks: MitigationBlock[] = [];
  const atrVal = atr(candles, 14) || 1;

  for (let i = 3; i < candles.length - 4; i++) {
    const c = candles[i];
    const after = candles.slice(i + 1, i + 5);
    if (after.length < 2) continue;

    const upMove = (Math.max(...after.map((x) => x.high)) - c.close) / atrVal;
    const downMove = (c.close - Math.min(...after.map((x) => x.low))) / atrVal;

    // Bullish mitigation: last bearish candle before strong up move
    if (c.close < c.open && upMove > 1.2) {
      const mitigated = candles.slice(i + 4).some((x) => x.low <= c.high && x.low >= c.low);
      blocks.push({
        id: `mit-${timeframe}-${i}`,
        time: c.time,
        top: Math.round(c.high * 100) / 100,
        bottom: Math.round(c.low * 100) / 100,
        direction: 'bullish',
        size: Math.round((c.high - c.low) * 100) / 100,
        timeframe,
        status: mitigated ? 'mitigated' : 'fresh',
        mitigatedAt: null,
      });
    }

    // Bearish mitigation: last bullish candle before strong down move
    if (c.close > c.open && downMove > 1.2) {
      const mitigated = candles.slice(i + 4).some((x) => x.high >= c.low && x.high <= c.high);
      blocks.push({
        id: `mit-${timeframe}-${i}`,
        time: c.time,
        top: Math.round(c.high * 100) / 100,
        bottom: Math.round(c.low * 100) / 100,
        direction: 'bearish',
        size: Math.round((c.high - c.low) * 100) / 100,
        timeframe,
        status: mitigated ? 'mitigated' : 'fresh',
        mitigatedAt: null,
      });
    }
  }

  return blocks.filter((b) => b.status === 'fresh').slice(-6);
}

// ─── BPR (Balanced Price Range) ─────────────────────────────────
// A true ICT Balanced Price Range is the overlap zone of two opposing
// FVGs (one bullish, one bearish) whose price ranges intersect. This
// represents a balanced area where buy-side and sell-side imbalances
// equalize — a fair value zone. Price breaking out of the BPR signals
// the direction of the next move.

export function detectBPRs(candles: Candle[], fvgs: FVG[], timeframe: Timeframe): BPR[] {
  const bprs: BPR[] = [];

  const bullishFvgs = fvgs.filter((f) => f.direction === 'bullish' && f.status !== 'invalidated');
  const bearishFvgs = fvgs.filter((f) => f.direction === 'bearish' && f.status !== 'invalidated');

  for (const bull of bullishFvgs) {
    for (const bear of bearishFvgs) {
      const timeDiff = Math.abs(bull.time - bear.time);
      const maxGap = 20 * TF_MIN[timeframe] * 60 * 1000;
      if (timeDiff > maxGap) continue;

      const overlapTop = Math.min(bull.top, bear.top);
      const overlapBottom = Math.max(bull.bottom, bear.bottom);

      if (overlapTop > overlapBottom) {
        const overlapSize = overlapTop - overlapBottom;
        const ce = (overlapTop + overlapBottom) / 2;
        const totalRange = Math.max(bull.top, bear.top) - Math.min(bull.bottom, bear.bottom);
        const deviationPct = totalRange > 0 ? (overlapSize / totalRange) * 100 : 0;

        const direction = bear.time > bull.time ? 'bearish' : 'bullish';
        const bprTime = Math.max(bull.time, bear.time);
        const bprIdx = candles.findIndex((c) => c.time === bprTime);
        let resolved = false;
        if (bprIdx >= 0 && bprIdx < candles.length - 1) {
          for (let i = bprIdx + 1; i < Math.min(candles.length, bprIdx + 30); i++) {
            if (direction === 'bullish' && candles[i].close > overlapTop) { resolved = true; break; }
            if (direction === 'bearish' && candles[i].close < overlapBottom) { resolved = true; break; }
          }
        }

        bprs.push({
          id: `bpr-${timeframe}-${bull.id}-${bear.id}`,
          time: bprTime,
          level: ce,
          direction: direction as 'bullish' | 'bearish',
          deviationPct,
          timeframe,
          status: resolved ? 'resolved' : 'active',
        });
      }
    }
  }

  return bprs.slice(-5);
}

// ─── Dealing Range ──────────────────────────────────────────────

export function computeDealingRange(candles: Candle[], label: string): DealingRange | null {
  if (candles.length < 5) return null;
  const recent = candles.slice(-30);
  const high = Math.max(...recent.map((c) => c.high));
  const low = Math.min(...recent.map((c) => c.low));
  const equilibrium = (high + low) / 2;
  return {
    high: Math.round(high * 100) / 100,
    low: Math.round(low * 100) / 100,
    equilibrium: Math.round(equilibrium * 100) / 100,
    premium: [Math.round(equilibrium * 100) / 100, Math.round(high * 100) / 100],
    discount: [Math.round(low * 100) / 100, Math.round(equilibrium * 100) / 100],
    label,
  };
}

// ─── Liquidity Detection ────────────────────────────────────────
// Liquidity pools are built from swing points and session levels.
// Sweep state is persistent: once a pool is swept, it stays swept even
// if price returns below/above the level. This is critical for tracking
// institutional liquidity grabs.

export function detectLiquidity(
  candles: Candle[],
  swings: SwingPoint[],
  currentPrice: number,
  sessionLevels?: { pdh: number; pdl: number; pwh: number; pwl: number },
): LiquidityPool[] {
  const pools: LiquidityPool[] = [];
  const atrVal = atr(candles, 14) || 1;

  // Build pools from swing points
  const recentHighs = swings.filter((s) => s.type === 'high').slice(-8);
  const recentLows = swings.filter((s) => s.type === 'low').slice(-8);

  // Equal highs/lows (EQH/EQL) — strong liquidity targets
  const addEqual = (points: SwingPoint[], side: LiquiditySide, type: LiquidityType) => {
    for (let i = 0; i < points.length; i++) {
      for (let j = i + 1; j < points.length; j++) {
        if (Math.abs(points[i].price - points[j].price) < atrVal * 0.3) {
          const level = (points[i].price + points[j].price) / 2;
          const swept = checkSweep(candles, level, side);
          pools.push({
            id: `liq-${type}-${i}-${j}`,
            level: Math.round(level * 100) / 100,
            type,
            side,
            distance: Math.round(Math.abs(currentPrice - level) * 100) / 100,
            targetProb: 0.7,
            reactionProb: 0.75,
            consumed: 0,
            horizon: 'intraday',
            time: points[j].time,
            createdAt: points[j].time,
            swept: swept.swept,
            sweptAt: swept.sweptAt,
            sweepExtreme: swept.sweepExtreme,
            rejected: swept.rejected,
            reclaimed: swept.reclaimed,
          });
        }
      }
    }
  };
  addEqual(recentHighs, 'above', 'eqh');
  addEqual(recentLows, 'below', 'eql');

  // Session-based liquidity
  if (sessionLevels) {
    const sessionPools: { level: number; type: LiquidityType; side: LiquiditySide }[] = [
      { level: sessionLevels.pdh, type: 'pdh', side: 'above' },
      { level: sessionLevels.pdl, type: 'pdl', side: 'below' },
      { level: sessionLevels.pwh, type: 'pwh', side: 'above' },
      { level: sessionLevels.pwl, type: 'pwl', side: 'below' },
    ];
    for (const sp of sessionPools) {
      if (sp.level <= 0) continue;
      const swept = checkSweep(candles, sp.level, sp.side);
      pools.push({
        id: `liq-${sp.type}`,
        level: sp.level,
        type: sp.type,
        side: sp.side,
        distance: Math.round(Math.abs(currentPrice - sp.level) * 100) / 100,
        targetProb: 0.6,
        reactionProb: 0.7,
        consumed: 0,
        horizon: 'intraday',
        time: candles[0]?.time ?? Date.now(),
        createdAt: candles[0]?.time ?? Date.now(),
        swept: swept.swept,
        sweptAt: swept.sweptAt,
        sweepExtreme: swept.sweepExtreme,
        rejected: swept.rejected,
        reclaimed: swept.reclaimed,
      });
    }
  }

  // Internal liquidity from swing highs/lows
  for (const s of recentHighs.slice(-4)) {
    const swept = checkSweep(candles, s.price, 'above');
    pools.push({
      id: `liq-bsl-${s.time}`,
      level: s.price,
      type: 'bsl',
      side: 'above',
      distance: Math.round(Math.abs(currentPrice - s.price) * 100) / 100,
      targetProb: 0.55,
      reactionProb: 0.6,
      consumed: 0,
      horizon: 'intraday',
      time: s.time,
      createdAt: s.time,
      swept: swept.swept,
      sweptAt: swept.sweptAt,
      sweepExtreme: swept.sweepExtreme,
      rejected: swept.rejected,
      reclaimed: swept.reclaimed,
    });
  }
  for (const s of recentLows.slice(-4)) {
    const swept = checkSweep(candles, s.price, 'below');
    pools.push({
      id: `liq-ssl-${s.time}`,
      level: s.price,
      type: 'ssl',
      side: 'below',
      distance: Math.round(Math.abs(currentPrice - s.price) * 100) / 100,
      targetProb: 0.55,
      reactionProb: 0.6,
      consumed: 0,
      horizon: 'intraday',
      time: s.time,
      createdAt: s.time,
      swept: swept.swept,
      sweptAt: swept.sweptAt,
      sweepExtreme: swept.sweepExtreme,
      rejected: swept.rejected,
      reclaimed: swept.reclaimed,
    });
  }

  // Deduplicate by level (keep the strongest type)
  const seen = new Map<number, LiquidityPool>();
  for (const p of pools) {
    const key = Math.round(p.level * 10) / 10;
    const existing = seen.get(key);
    if (!existing || p.targetProb > existing.targetProb) {
      seen.set(key, p);
    }
  }

  return Array.from(seen.values()).sort((a, b) => a.distance - b.distance).slice(0, 15);
}

// Persistent sweep detection: once swept, stays swept.
// A sweep is when price goes beyond a level (wicks through it) but then
// closes back on the other side — a liquidity grab.
function checkSweep(
  candles: Candle[],
  level: number,
  side: LiquiditySide,
): { swept: boolean; sweptAt: number | null; sweepExtreme: number | null; rejected: boolean; reclaimed: boolean } {
  let swept = false;
  let sweptAt: number | null = null;
  let sweepExtreme: number | null = null;
  let rejected = false;
  let reclaimed = false;

  for (const c of candles) {
    if (side === 'above') {
      // Buy-side liquidity: price needs to spike above the level
      if (c.high > level) {
        if (!swept) {
          swept = true;
          sweptAt = c.time;
          sweepExtreme = c.high;
        } else {
          sweepExtreme = Math.max(sweepExtreme ?? c.high, c.high);
        }
        // Rejected if candle closes back below the level
        if (c.close < level) {
          rejected = true;
        }
        // Reclaimed if a later candle closes back above
        if (rejected && c.close > level) {
          reclaimed = true;
        }
      }
    } else {
      // Sell-side liquidity: price needs to spike below the level
      if (c.low < level) {
        if (!swept) {
          swept = true;
          sweptAt = c.time;
          sweepExtreme = c.low;
        } else {
          sweepExtreme = Math.min(sweepExtreme ?? c.low, c.low);
        }
        if (c.close > level) {
          rejected = true;
        }
        if (rejected && c.close < level) {
          reclaimed = true;
        }
      }
    }
  }

  return { swept, sweptAt, sweepExtreme, rejected, reclaimed };
}

// ─── Composite Structure ────────────────────────────────────────

export function computeStructure(
  candles: Candle[],
  timeframe: Timeframe,
  currentPrice: number,
  sessionLevels?: { pdh: number; pdl: number; pwh: number; pwl: number },
): StructureState {
  const swings = detectSwings(candles);
  const { bias, events, lastEvent } = detectStructureEvents(candles, swings);
  const fvgs = detectFVGs(candles, timeframe);
  const ifvgs = detectIFVGs(candles, fvgs, timeframe);
  const orderBlocks = detectOrderBlocks(candles, timeframe);
  const breakers = detectBreakerBlocks(candles, timeframe);
  const mitigationBlocks = detectMitigationBlocks(candles, timeframe);
  const bprs = detectBPRs(candles, fvgs, timeframe);
  const dealingRange = computeDealingRange(candles, timeframe);
  const liquidity = detectLiquidity(candles, swings, currentPrice, sessionLevels);

  const premium = dealingRange ? currentPrice > dealingRange.equilibrium : false;
  const discount = dealingRange ? currentPrice < dealingRange.equilibrium : false;
  const noise = computeNoise(candles);

  const lastDisplacement = events.length > 0
    ? computeDisplacement(candles, candles.findIndex((c) => c.time === events[events.length - 1].time))
    : null;

  return {
    bias,
    swings: swings.slice(-12),
    lastEvent,
    events,
    fvgs,
    ifvgs,
    orderBlocks,
    breakers,
    mitigationBlocks,
    bprs,
    dealingRange,
    premium,
    discount,
    liquidity,
    noise,
    displacement: lastDisplacement,
  };
}

function computeNoise(candles: Candle[]): number {
  if (candles.length < 10) return 0.5;
  const recent = candles.slice(-10);
  let reversals = 0;
  for (let i = 1; i < recent.length; i++) {
    if ((recent[i].close > recent[i].open) !== (recent[i - 1].close > recent[i - 1].open)) reversals++;
  }
  return Math.round((reversals / (recent.length - 1)) * 100) / 100;
}
