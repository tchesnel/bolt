// Data quality engine: verifies feed health, tick freshness, candle
// integrity, spread, spikes, and gaps. When quality = INVALID, trading
// is blocked (NO_TRADE mandatory).

import { Candle, PriceState, QualityReport, QualityCheck, Timeframe, TF_MINUTES, FeedState } from './types';

const ABNORMAL_SPREAD_THRESHOLD = 1.5; // USD — abnormally wide for XAUUSD
const STALE_TICK_THRESHOLD_MS = 5000;
const SPIKE_ATR_MULTIPLE = 5;

export function computeDataQuality(
  price: PriceState,
  candles: Record<Timeframe, Candle[]>,
  currentTime: number,
  expectedTimeframes: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D', 'W'],
): QualityReport {
  const checks: QualityCheck[] = [];

  // 1. Feed connected
  const feedConnected = price.feed.status === 'CONNECTED' && !price.stale;
  checks.push({
    name: 'Feed connected',
    passed: feedConnected,
    detail: `Feed status: ${price.feed.status}${price.stale ? ' (stale)' : ''}`,
  });

  // 2. Tick freshness
  const tickAge = price.lastTick ? currentTime - price.lastTick.time : currentTime - price.feed.lastTickAt;
  const tickFresh = tickAge < STALE_TICK_THRESHOLD_MS;
  checks.push({
    name: 'Tick freshness',
    passed: tickFresh,
    detail: tickFresh ? `Last tick ${tickAge}ms ago` : `Stale tick: ${tickAge}ms ago (threshold ${STALE_TICK_THRESHOLD_MS}ms)`,
  });

  // 3. Latency
  const latency = price.feed.feedLatency;
  const latencyOK = latency < 2000;
  checks.push({
    name: 'Feed latency',
    passed: latencyOK,
    detail: latencyOK ? `Latency ${latency}ms` : `High latency: ${latency}ms`,
  });

  // 4. Missing candles — check each timeframe has recent data
  let missingCandles = 0;
  for (const tf of expectedTimeframes) {
    const tfCandles = candles[tf];
    if (!tfCandles || tfCandles.length === 0) {
      missingCandles++;
      checks.push({ name: `${tf} candles`, passed: false, detail: 'No candle data' });
    } else {
      const lastCandle = tfCandles[tfCandles.length - 1];
      const tfMs = TF_MINUTES[tf] * 60 * 1000;
      const gap = currentTime - lastCandle.time;
      const expectedGap = tfMs * 2; // allow 2 bars of gap
      if (gap > expectedGap) {
        missingCandles++;
        checks.push({ name: `${tf} candles`, passed: false, detail: `Last ${tf} candle ${Math.round(gap / 1000 / 60)}min ago` });
      }
    }
  }

  // 5. Duplicate timestamps
  let duplicateTimestamps = 0;
  for (const tf of expectedTimeframes) {
    const tfCandles = candles[tf];
    if (!tfCandles) continue;
    const seen = new Set<number>();
    for (const c of tfCandles) {
      if (seen.has(c.time)) duplicateTimestamps++;
      seen.add(c.time);
    }
  }
  checks.push({
    name: 'Duplicate timestamps',
    passed: duplicateTimestamps === 0,
    detail: duplicateTimestamps === 0 ? 'No duplicates' : `${duplicateTimestamps} duplicate timestamps`,
  });

  // 6. Out-of-order ticks (check candle ordering)
  let outOfOrderTicks = 0;
  for (const tf of expectedTimeframes) {
    const tfCandles = candles[tf];
    if (!tfCandles) continue;
    for (let i = 1; i < tfCandles.length; i++) {
      if (tfCandles[i].time < tfCandles[i - 1].time) outOfOrderTicks++;
    }
  }
  checks.push({
    name: 'Chronological order',
    passed: outOfOrderTicks === 0,
    detail: outOfOrderTicks === 0 ? 'All candles in order' : `${outOfOrderTicks} out-of-order candles`,
  });

  // 7. Abnormal spread
  const abnormalSpread = price.spread > ABNORMAL_SPREAD_THRESHOLD;
  checks.push({
    name: 'Spread normal',
    passed: !abnormalSpread,
    detail: abnormalSpread ? `Abnormal spread: ${price.spread} (threshold ${ABNORMAL_SPREAD_THRESHOLD})` : `Spread ${price.spread}`,
  });

  // 8. Price spikes — detect candles with extreme range vs ATR
  let priceSpikes = 0;
  for (const tf of ['M1', 'M5', 'M15'] as Timeframe[]) {
    const tfCandles = candles[tf];
    if (!tfCandles || tfCandles.length < 14) continue;
    const ranges = tfCandles.slice(-14).map((c) => c.high - c.low);
    const avgRange = ranges.reduce((s, v) => s + v, 0) / ranges.length;
    for (const r of ranges) {
      if (avgRange > 0 && r > avgRange * SPIKE_ATR_MULTIPLE) priceSpikes++;
    }
  }
  checks.push({
    name: 'Price spikes',
    passed: priceSpikes === 0,
    detail: priceSpikes === 0 ? 'No abnormal spikes' : `${priceSpikes} price spikes detected`,
  });

  // 9. History gaps — check for missing bars within each timeframe
  let historyGaps = 0;
  for (const tf of expectedTimeframes) {
    const tfCandles = candles[tf];
    if (!tfCandles || tfCandles.length < 3) continue;
    const tfMs = TF_MINUTES[tf] * 60 * 1000;
    for (let i = 1; i < tfCandles.length; i++) {
      const gap = tfCandles[i].time - tfCandles[i - 1].time;
      if (gap > tfMs * 1.5 && gap < tfMs * 100) {
        // Gap that's not just a weekend/holiday
        historyGaps++;
      }
    }
  }
  checks.push({
    name: 'History gaps',
    passed: historyGaps === 0,
    detail: historyGaps === 0 ? 'No gaps' : `${historyGaps} gaps in history`,
  });

  // Compute overall score
  const passedCount = checks.filter((c) => c.passed).length;
  const score = Math.round((passedCount / checks.length) * 100);

  // Determine status
  let status: QualityReport['status'];
  if (!feedConnected || missingCandles > 2) {
    status = 'INVALID';
  } else if (abnormalSpread || priceSpikes > 2) {
    status = 'OUTLIER';
  } else if (!tickFresh || latency > 1000) {
    status = 'STALE';
  } else if (duplicateTimestamps > 0 || outOfOrderTicks > 0) {
    status = 'CONFLICTING';
  } else if (historyGaps > 0) {
    status = 'RECONSTRUCTED';
  } else {
    status = 'VALID';
  }

  const reason = status === 'INVALID'
    ? 'Feed disconnected or critical data missing — trading blocked'
    : status === 'STALE'
    ? 'Tick data is stale'
    : status === 'OUTLIER'
    ? 'Abnormal spread or price spikes detected'
    : status === 'CONFLICTING'
    ? 'Data integrity issues (duplicates or out-of-order)'
    : status === 'RECONSTRUCTED'
    ? 'History has gaps — data partially reconstructed'
    : 'All quality checks passed';

  return {
    status,
    score,
    reason,
    feedConnected,
    tickFresh,
    latencyMs: latency,
    missingCandles,
    duplicateTimestamps,
    outOfOrderTicks,
    abnormalSpread,
    priceSpikes,
    historyGaps,
    checks,
  };
}

export function isTradeable(quality: QualityReport): boolean {
  return quality.status === 'VALID' || quality.status === 'RECONSTRUCTED';
}
