// Context engines: regime detection, correlations, options, macro, news, geo.
// In PRODUCTION mode: no fabricated data. All external-data indicators
// report available=false when no real feed is connected.

import { Candle, Regime, CorrelationState, OptionsState, MacroEvent, NewsItem, GeoEvent, Timeframe, RollingCorrelation, EngineMode } from './types';
import { adx, atr, realizedVol, autocorr, directionalEfficiency } from './indicators';

export function detectRegime(candles: Record<Timeframe, Candle[]>): { regime: Regime; label: string } {
  const m5 = candles.M5;
  const h1 = candles.H1;
  if (!m5 || m5.length < 20 || !h1 || h1.length < 10) return { regime: 'TRANSITION', label: 'Initialization' };

  const adxVal = adx(h1, 14);
  const rv = realizedVol(h1, 20);
  const ac = autocorr(h1, 1, 30);
  const eff = directionalEfficiency(h1, 20);
  const atrVal = atr(h1, 14);
  const recentRange = Math.max(...h1.slice(-10).map((c) => c.high)) - Math.min(...h1.slice(-10).map((c) => c.low));
  const rangeExpansion = atrVal > 0 ? recentRange / (atrVal * 10) : 1;
  const lastClose = h1[h1.length - 1].close;
  const prevClose = h1[Math.max(0, h1.length - 10)].close;
  const trendStrength = (lastClose - prevClose) / (atrVal * 10);

  let regime: Regime;
  let label: string;

  if (rv > 0.015) {
    regime = 'HIGH_VOLATILITY';
    label = 'High volatility';
  } else if (adxVal > 25 && Math.abs(trendStrength) > 0.5) {
    regime = trendStrength > 0 ? 'TREND_UP' : 'TREND_DOWN';
    label = trendStrength > 0 ? 'Bullish trend' : 'Bearish trend';
  } else if (adxVal < 18 && rangeExpansion < 0.8) {
    regime = 'LOW_VOLATILITY';
    label = 'Low volatility';
  } else if (adxVal < 20 && Math.abs(trendStrength) < 0.3) {
    regime = rangeExpansion > 1.2 ? 'RANGE_EXPANDING' : 'RANGE_BALANCED';
    label = rangeExpansion > 1.2 ? 'Expanding range' : 'Balanced range';
  } else if (ac > 0.2 && eff > 0.4) {
    regime = 'MEAN_REVERSION';
    label = 'Mean reversion';
  } else if (Math.abs(trendStrength) > 0.8 && ac < 0) {
    regime = 'BREAKOUT';
    label = 'Breakout';
  } else if (rv > 0.01 && ac < -0.1) {
    regime = 'FALSE_BREAKOUT';
    label = 'False breakout risk';
  } else {
    regime = 'TRANSITION';
    label = 'Transition / mixed';
  }

  return { regime, label };
}

// ─── Correlations ───────────────────────────────────────────────
// Real DXY, US10Y, real yields, XAGUSD, VIX require external data feeds.
// Until those feeds are connected, this reports available=false and
// the correlation agent stays neutral. No fabricated values.

export function computeCorrelations(_candles: Candle[], _mode: EngineMode = 'PRODUCTION'): CorrelationState {
  return {
    dxy: 0,
    realYields10y: 0,
    nominal10y: 0,
    sp500: 0,
    silver: 0,
    vix: 0,
    regimeNote: 'External data feeds not connected — correlations unavailable',
    broken: false,
    available: false,
    rollingCorr: [
      { asset: 'DXY', window: 20, correlation: 0, change: 0, zScore: 0, divergence: false, regimeBreak: false, available: false },
      { asset: 'US10Y', window: 20, correlation: 0, change: 0, zScore: 0, divergence: false, regimeBreak: false, available: false },
      { asset: 'XAGUSD', window: 20, correlation: 0, change: 0, zScore: 0, divergence: false, regimeBreak: false, available: false },
      { asset: 'VIX', window: 20, correlation: 0, change: 0, zScore: 0, divergence: false, regimeBreak: false, available: false },
    ],
  };
}

// ─── Options ────────────────────────────────────────────────────
// Real options data (IV, skew, gamma, OI by strike, option walls) requires
// a licensed options data feed (CME MDP, OPRA). No such feed here.
// Module is DISABLED — not fabricated from candle OHLC.

export function computeOptionsState(_candles: Candle[], _currentPrice: number, _mode: EngineMode = 'PRODUCTION'): OptionsState {
  return {
    ivATM: 0,
    skew: 'neutral',
    skewChange24h: 0,
    skewPercentile: 0,
    pinning: [],
    walls: [],
    gamma: 0,
    note: 'Options data feed not connected — IV, skew, gamma and OI unavailable. Module disabled.',
    available: false,
  };
}

// ─── Macro events ───────────────────────────────────────────────
// In PRODUCTION: no illustrative events. Returns empty list with available=false.
// A real implementation fetches from a licensed economic calendar API
// (Trading Economics, Investing.com, Bloomberg) via an edge function.

export function generateMacroEvents(_currentTime: number, mode: EngineMode = 'PRODUCTION'): MacroEvent[] {
  if (mode === 'PRODUCTION') return [];
  // DEMO mode: return a few illustrative events for testing
  return [
    { time: _currentTime + 7200000, name: 'CPI [DEMO]', impact: 'high', consensus: '+0.3% m/m', actual: null, currency: 'USD', minutesUntil: 120, country: 'US', previous: '+0.2%', available: false },
    { time: _currentTime + 14400000, name: 'FOMC [DEMO]', impact: 'high', consensus: '—', actual: null, currency: 'USD', minutesUntil: 240, country: 'US', previous: '—', available: false },
  ];
}

// ─── News ───────────────────────────────────────────────────────
// In PRODUCTION: no fabricated headlines. Returns empty list.
// A real implementation ingests from Reuters/Bloomberg/AP or a news API
// via an edge function with source-tier classification and deduplication.

export function generateNews(_currentTime: number, mode: EngineMode = 'PRODUCTION'): NewsItem[] {
  if (mode === 'PRODUCTION') return [];
  return [];
}

// ─── Geopolitical events ────────────────────────────────────────
// In PRODUCTION: no fabricated events. Returns empty list.
// A real implementation ingests from GDELT, UKMTO, official government feeds.

export function generateGeoEvents(_currentTime: number, mode: EngineMode = 'PRODUCTION'): GeoEvent[] {
  if (mode === 'PRODUCTION') return [];
  return [];
}
