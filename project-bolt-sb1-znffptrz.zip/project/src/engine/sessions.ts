// Session engine: computes real session boundaries, daily/weekly opens,
// PDH/PDL/PWH/PWL, Asian/London/NY highs/lows, NDOG/NWOG.
// DST-aware: session times shift for US daylight saving.

import { Candle, SessionInfo, SessionName } from './types';

// Session times in UTC (winter). DST shifts US sessions by 1 hour.
// Asian: 00:00–09:00 UTC (Tokyo)
// London: 08:00–17:00 UTC (London)
// New York: 13:00–22:00 UTC (winter) / 12:00–21:00 UTC (summer/DST)
const SESSION_TIMES = {
  asian: { startH: 0, startM: 0, endH: 9, endM: 0 },
  london: { startH: 8, startM: 0, endH: 17, endM: 0 },
  newyork: { startH: 13, startM: 0, endH: 22, endM: 0 }, // winter
  newyorkDST: { startH: 12, startM: 0, endH: 21, endM: 0 }, // summer
};

// US DST: second Sunday of March to first Sunday of November (approximate)
function isDST(date: Date): boolean {
  const year = date.getUTCFullYear();
  const march = new Date(Date.UTC(year, 2, 1));
  const secondSunday = 1 + (7 - march.getUTCDay()) % 7 + 7;
  const dstStart = Date.UTC(year, 2, secondSunday, 7, 0, 0); // 2am EST = 7am UTC
  const november = new Date(Date.UTC(year, 10, 1));
  const firstSunday = 1 + (7 - november.getUTCDay()) % 7;
  const dstEnd = Date.UTC(year, 10, firstSunday, 6, 0, 0); // 2am EST = 6am UTC
  const t = date.getTime();
  return t >= dstStart && t < dstEnd;
}

function hoursToUTC(date: Date, h: number, m: number): number {
  return Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate(), h, m, 0);
}

function getSessionHighLow(candles: Candle[], startMs: number, endMs: number): { high: number; low: number; open: number } {
  const sessionCandles = candles.filter((c) => c.time >= startMs && c.time < endMs);
  if (sessionCandles.length === 0) return { high: 0, low: 0, open: 0 };
  return {
    high: Math.max(...sessionCandles.map((c) => c.high)),
    low: Math.min(...sessionCandles.map((c) => c.low)),
    open: sessionCandles[0].open,
  };
}

function getDailyOpen(candles: Candle[], dayStartMs: number): number {
  const firstCandle = candles.find((c) => c.time >= dayStartMs);
  return firstCandle?.open ?? 0;
}

function getWeeklyOpen(candles: Candle[], weekStartMs: number): number {
  const firstCandle = candles.find((c) => c.time >= weekStartMs);
  return firstCandle?.open ?? 0;
}

export function detectSession(date: Date): SessionName {
  const dst = isDST(date);
  const nyTimes = dst ? SESSION_TIMES.newyorkDST : SESSION_TIMES.newyork;
  const h = date.getUTCHours();
  if (h >= SESSION_TIMES.london.startH && h < SESSION_TIMES.london.endH) return 'LONDON';
  if (h >= nyTimes.startH && h < nyTimes.endH) return 'NEW_YORK';
  if (h >= SESSION_TIMES.asian.startH && h < SESSION_TIMES.asian.endH) return 'ASIAN';
  return 'OFF';
}

export function computeSessions(candles: Candle[], currentTime: number): SessionInfo {
  const now = new Date(currentTime);
  const dst = isDST(now);
  const nyTimes = dst ? SESSION_TIMES.newyorkDST : SESSION_TIMES.newyork;

  const year = now.getUTCFullYear();
  const month = now.getUTCMonth();
  const day = now.getUTCDate();

  // Today's session boundaries
  const asianStart = Date.UTC(year, month, day, SESSION_TIMES.asian.startH, SESSION_TIMES.asian.startM);
  const asianEnd = Date.UTC(year, month, day, SESSION_TIMES.asian.endH, SESSION_TIMES.asian.endM);
  const londonStart = Date.UTC(year, month, day, SESSION_TIMES.london.startH, SESSION_TIMES.london.startM);
  const londonEnd = Date.UTC(year, month, day, SESSION_TIMES.london.endH, SESSION_TIMES.london.endM);
  const nyStart = Date.UTC(year, month, day, nyTimes.startH, nyTimes.startM);
  const nyEnd = Date.UTC(year, month, day, nyTimes.endH, nyTimes.endM);

  const asian = { ...getSessionHighLow(candles, asianStart, asianEnd), start: asianStart, end: asianEnd };
  const london = { ...getSessionHighLow(candles, londonStart, londonEnd), start: londonStart, end: londonEnd };
  const newyork = { ...getSessionHighLow(candles, nyStart, nyEnd), start: nyStart, end: nyEnd };

  // Previous day: yesterday's full range
  const prevDayStart = Date.UTC(year, month, day - 1, 0, 0, 0);
  const prevDayEnd = Date.UTC(year, month, day, 0, 0, 0);
  const prevDayCandles = candles.filter((c) => c.time >= prevDayStart && c.time < prevDayEnd);
  const pdh = prevDayCandles.length > 0 ? Math.max(...prevDayCandles.map((c) => c.high)) : 0;
  const pdl = prevDayCandles.length > 0 ? Math.min(...prevDayCandles.map((c) => c.low)) : 0;

  // Previous week: last week's full range
  const currentDayOfWeek = now.getUTCDay(); // 0=Sunday
  const daysSinceMonday = currentDayOfWeek === 0 ? 6 : currentDayOfWeek - 1;
  const thisWeekStart = Date.UTC(year, month, day - daysSinceMonday, 0, 0, 0);
  const lastWeekStart = Date.UTC(year, month, day - daysSinceMonday - 7, 0, 0, 0);
  const lastWeekEnd = thisWeekStart;
  const prevWeekCandles = candles.filter((c) => c.time >= lastWeekStart && c.time < lastWeekEnd);
  const pwh = prevWeekCandles.length > 0 ? Math.max(...prevWeekCandles.map((c) => c.high)) : 0;
  const pwl = prevWeekCandles.length > 0 ? Math.min(...prevWeekCandles.map((c) => c.low)) : 0;

  // Daily and weekly open
  const todayStart = Date.UTC(year, month, day, 0, 0, 0);
  const dailyOpen = getDailyOpen(candles, todayStart);
  const weeklyOpen = getWeeklyOpen(candles, thisWeekStart);

  // New Day Opening Gap (NDOG): gap between yesterday's close and today's open
  const prevDayClose = prevDayCandles.length > 0 ? prevDayCandles[prevDayCandles.length - 1].close : 0;
  const ndog = prevDayClose > 0 && dailyOpen > 0 ? Math.round(Math.abs(dailyOpen - prevDayClose) * 100) / 100 : null;

  // New Week Opening Gap (NWOG): gap between last week's close and this week's open
  const prevWeekClose = prevWeekCandles.length > 0 ? prevWeekCandles[prevWeekCandles.length - 1].close : 0;
  const nwog = prevWeekClose > 0 && weeklyOpen > 0 ? Math.round(Math.abs(weeklyOpen - prevWeekClose) * 100) / 100 : null;

  return {
    current: detectSession(now),
    asian,
    london,
    newyork,
    pdh: Math.round(pdh * 100) / 100,
    pdl: Math.round(pdl * 100) / 100,
    pwh: Math.round(pwh * 100) / 100,
    pwl: Math.round(pwl * 100) / 100,
    dailyOpen: Math.round(dailyOpen * 100) / 100,
    weeklyOpen: Math.round(weeklyOpen * 100) / 100,
    ndog,
    nwog,
    isDST: dst,
  };
}

export function getSessionLevels(sessions: SessionInfo): { pdh: number; pdl: number; pwh: number; pwl: number } {
  return {
    pdh: sessions.pdh,
    pdl: sessions.pdl,
    pwh: sessions.pwh,
    pwl: sessions.pwl,
  };
}

export function sessionCandles(candles: Candle[], session: SessionInfo, type: 'asian' | 'london' | 'newyork'): Candle[] {
  const s = session[type];
  const now = new Date(session.dailyOpen > 0 ? session.dailyOpen : Date.now());
  // Not used directly — callers should use session boundaries
  void s; void now;
  return candles;
}
