// Core domain types for the XAU/USD quantitative analysis engine.

export type Timeframe = 'M1' | 'M5' | 'M15' | 'H1' | 'H4' | 'D' | 'W';

export const TF_MINUTES: Record<Timeframe, number> = {
  M1: 1,
  M5: 5,
  M15: 15,
  H1: 60,
  H4: 240,
  D: 1440,
  W: 10080,
};

export type EngineMode = 'PRODUCTION' | 'DEMO';

// ─── Candle / Tick ──────────────────────────────────────────────

export interface Candle {
  time: number; // UTC milliseconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  buyVolume: number;
  sellVolume: number;
  hasRealVolume: boolean;
}

export interface Tick {
  time: number; // UTC milliseconds
  bid: number;
  ask: number;
  mid: number;
  spread: number;
  volume: number;
  buyVolume?: number;
  sellVolume?: number;
  last: number;
}

export interface ProviderQuote {
  provider: string;
  bid: number;
  ask: number;
  last: number;
  timestamp: number;
  receiveTime: number;
  tickRate: number;
  quality: number; // 0-100
}

// ─── Feed state ─────────────────────────────────────────────────

export type FeedStatus = 'CONNECTED' | 'RECONNECTING' | 'DISCONNECTED' | 'STALE' | 'NO_FEED';

export interface FeedState {
  status: FeedStatus;
  mode: EngineMode;
  provider: string;
  lastTickAt: number;
  feedLatency: number;
  heartbeat: number;
  lastHeartbeatAt: number;
  reconnectAttempts: number;
  staleThresholdMs: number;
  symbol: string;
}

export interface PriceState {
  median: number;
  bestBid: number;
  bestAsk: number;
  spread: number;
  maxDivergence: number;
  quality: number;
  stale: boolean;
  quotes: ProviderQuote[];
  time: number;
  feed: FeedState;
  lastTick: Tick | null;
}

// ─── Data quality ───────────────────────────────────────────────

export type DataStatus =
  | 'VALID'
  | 'STALE'
  | 'MISSING'
  | 'OUTLIER'
  | 'CONFLICTING'
  | 'RECONSTRUCTED'
  | 'INVALID';

export interface QualityReport {
  status: DataStatus;
  score: number; // 0-100
  reason: string;
  feedConnected: boolean;
  tickFresh: boolean;
  latencyMs: number;
  missingCandles: number;
  duplicateTimestamps: number;
  outOfOrderTicks: number;
  abnormalSpread: boolean;
  priceSpikes: number;
  historyGaps: number;
  checks: QualityCheck[];
}

export interface QualityCheck {
  name: string;
  passed: boolean;
  detail: string;
}

// ─── Direction ──────────────────────────────────────────────────

export type Direction = -1 | 0 | 1;

// ─── Agent signals ──────────────────────────────────────────────

export interface AgentSignal {
  agent: string;
  direction: Direction;
  confidence: number; // 0-1
  dataQuality: number; // 0-1
  freshness: number; // 0-1
  regimeCompat: number; // 0-1
  weight: number; // dynamic weight 0-1
  note: string;
  raw: number;
  available: boolean;
}

// ─── Regime ─────────────────────────────────────────────────────

export type Regime =
  | 'TREND_UP'
  | 'TREND_DOWN'
  | 'RANGE_BALANCED'
  | 'RANGE_EXPANDING'
  | 'BREAKOUT'
  | 'FALSE_BREAKOUT'
  | 'EVENT_DRIVEN'
  | 'RISK_OFF'
  | 'LIQUIDITY_VACUUM'
  | 'HIGH_VOLATILITY'
  | 'LOW_VOLATILITY'
  | 'MEAN_REVERSION'
  | 'TRANSITION';

// ─── Structure ──────────────────────────────────────────────────

export interface SwingPoint {
  time: number;
  price: number;
  type: 'high' | 'low';
  class: 'micro' | 'internal' | 'intermediate' | 'external' | 'major';
  strength: number;
}

export type StructureBias = 'bullish' | 'bearish' | 'neutral' | 'ranging';

export type StructureEventType = 'BOS' | 'CHOCH' | 'MSS';

export interface StructureEvent {
  type: StructureEventType;
  direction: 'bullish' | 'bearish';
  level: number;
  time: number;
  confirmed: boolean;
  displacement: number;
  closedBeyond: boolean;
  fvgCreated: boolean;
  context: string;
}

export interface DisplacementInfo {
  bodyRangeRatio: number;
  atrMultiple: number;
  closedBeyond: boolean;
  expansion: number;
  fvgCreated: boolean;
  isDisplacement: boolean;
}

// ─── FVG / IFVG ─────────────────────────────────────────────────

export type FVGStatus = 'fresh' | 'touched' | 'partial_fill' | 'mitigated' | 'invalidated';

export interface FVG {
  id: string;
  time: number;
  top: number;
  bottom: number;
  ce: number;
  direction: 'bullish' | 'bearish';
  size: number;
  atrRatio: number;
  ageBars: number;
  fills: number;
  fillPct: number;
  status: FVGStatus;
  timeframe: Timeframe;
  quality: number;
  mitigatedAt: number | null;
}

export interface IFVG {
  id: string;
  time: number;
  top: number;
  bottom: number;
  ce: number;
  direction: 'bullish' | 'bearish';
  size: number;
  timeframe: Timeframe;
  status: 'fresh' | 'mitigated' | 'invalidated';
  mitigatedAt: number | null;
  originFvgId: string;
}

// ─── Order Blocks / Breakers / Mitigation ───────────────────────

export type BlockStatus = 'fresh' | 'mitigated' | 'invalidated';

export interface OrderBlock {
  id: string;
  time: number;
  top: number;
  bottom: number;
  direction: 'bullish' | 'bearish';
  displacement: number;
  structureBreak: number;
  fvgAssoc: number;
  volume: number;
  freshness: number;
  premiumDiscount: number;
  confluence: number;
  score: number;
  status: BlockStatus;
  mitigatedAt: number | null;
  timeframe: Timeframe;
  ce: number;
}

export interface BreakerBlock {
  id: string;
  time: number;
  top: number;
  bottom: number;
  direction: 'bullish' | 'bearish';
  size: number;
  timeframe: Timeframe;
  status: BlockStatus;
  mitigatedAt: number | null;
  ce: number;
}

export interface MitigationBlock {
  id: string;
  time: number;
  top: number;
  bottom: number;
  direction: 'bullish' | 'bearish';
  size: number;
  timeframe: Timeframe;
  status: BlockStatus;
  mitigatedAt: number | null;
}

export interface BPR {
  id: string;
  time: number;
  level: number;
  direction: 'bullish' | 'bearish';
  deviationPct: number;
  timeframe: Timeframe;
  status: 'active' | 'resolved';
}

// ─── Liquidity ──────────────────────────────────────────────────

export type LiquidityType =
  | 'pdh' | 'pdl'
  | 'pwh' | 'pwl'
  | 'asian_high' | 'asian_low'
  | 'london_high' | 'london_low'
  | 'ny_high' | 'ny_low'
  | 'eqh' | 'eql'
  | 'bsl' | 'ssl'
  | 'internal' | 'external'
  | 'round_number'
  | 'session_open'
  | 'daily_open' | 'weekly_open';

export type LiquiditySide = 'above' | 'below';

export interface LiquidityPool {
  id: string;
  level: number;
  type: LiquidityType;
  side: LiquiditySide;
  distance: number;
  targetProb: number;
  reactionProb: number;
  consumed: number;
  horizon: string;
  time: number;
  createdAt: number;
  swept: boolean;
  sweptAt: number | null;
  sweepExtreme: number | null;
  rejected: boolean;
  reclaimed: boolean;
}

// ─── Dealing range ──────────────────────────────────────────────

export interface DealingRange {
  high: number;
  low: number;
  equilibrium: number;
  premium: [number, number];
  discount: [number, number];
  label: string;
}

// ─── Sessions ───────────────────────────────────────────────────

export type SessionName = 'ASIAN' | 'LONDON' | 'NEW_YORK' | 'OFF';

export interface SessionInfo {
  current: SessionName;
  asian: { high: number; low: number; open: number; start: number; end: number };
  london: { high: number; low: number; open: number; start: number; end: number };
  newyork: { high: number; low: number; open: number; start: number; end: number };
  pdh: number;
  pdl: number;
  pwh: number;
  pwl: number;
  dailyOpen: number;
  weeklyOpen: number;
  ndog: number | null;
  nwog: number | null;
  isDST: boolean;
}

// ─── Volume profile / VWAP ──────────────────────────────────────

export interface VolumeNode {
  price: number;
  volume: number;
  buyVolume: number;
  sellVolume: number;
}

export interface VolumeProfile {
  poc: number;
  vah: number;
  val: number;
  nodes: VolumeNode[];
  hvn: number[];
  lvn: number[];
  initialBalance: [number, number];
  valueArea: [number, number];
  available: boolean;
}

export interface AnchoredVWAP {
  value: number;
  anchorTime: number;
  anchorReason: string;
  bands: { upper: number; lower: number; stdDev: number };
}

export interface VWAPSet {
  daily: number;
  weekly: number;
  session: number;
  anchored: AnchoredVWAP;
  bands: { upper: number; lower: number; stdDev: number };
}

// ─── Microstructure ─────────────────────────────────────────────

export interface AbsorptionEvent {
  side: 'buyer' | 'seller';
  zone: [number, number];
  volume: number;
  volumePercentile: number;
  duration: number;
  confidence: number;
  structuralValidation: boolean;
  time: number;
}

export interface ExhaustionEvent {
  side: 'buyer' | 'seller';
  level: number;
  volume: number;
  progression: number;
  confidence: number;
  time: number;
}

export interface IcebergEvent {
  side: 'buyer' | 'seller';
  level: number;
  confidence: number;
  contracts: number;
  held: boolean;
  time: number;
}

export interface SweepEvent {
  side: 'buyer' | 'seller';
  level: number;
  speed: number;
  institutional: boolean;
  liquidityGap: boolean;
  time: number;
}

export interface MicrostructureState {
  ofi: number;
  delta: number;
  cvd: number;
  cvdTrend: 'up' | 'down' | 'flat';
  priceTrend: 'up' | 'down' | 'flat';
  divergence: 'none' | 'bullish' | 'bearish';
  absorption: AbsorptionEvent | null;
  exhaustion: ExhaustionEvent | null;
  iceberg: IcebergEvent | null;
  sweep: SweepEvent | null;
  ofiAvailable: boolean;
  cvdAvailable: boolean;
  absorptionAvailable: boolean;
  icebergAvailable: boolean;
}

// ─── Setup state machine ────────────────────────────────────────

export type SetupStage =
  | 'HTF_BIAS_CONFIRMED'
  | 'LIQUIDITY_TARGET_IDENTIFIED'
  | 'LIQUIDITY_SWEPT'
  | 'DISPLACEMENT'
  | 'MSS'
  | 'POI_IDENTIFIED'
  | 'RETRACEMENT_INTO_POI'
  | 'M1_TRIGGER'
  | 'READY'
  | 'EXECUTE'
  | 'CLOSED'
  | 'INVALIDATED'
  | 'EXPIRED';

export type SetupStatus = 'WAIT' | 'MONITOR' | 'READY' | 'EXECUTE' | 'NO_TRADE';

export interface SetupStep {
  stage: SetupStage;
  completed: boolean;
  detail: string;
  timestamp: number | null;
}

export interface SetupState {
  setupId: string;
  direction: Direction;
  status: SetupStatus;
  currentStage: SetupStage;
  steps: SetupStep[];
  createdAt: number;
  updatedAt: number;
  htfBias: StructureBias;
  htfTimeframe: Timeframe;
  liquidityTarget: LiquidityPool | null;
  sweep: LiquidityPool | null;
  displacement: StructureEvent | null;
  mss: StructureEvent | null;
  poi: FVG | OrderBlock | BreakerBlock | IFVG | null;
  poiType: string;
  entryZoneMin: number;
  entryZoneMax: number;
  preferredEntry: number;
  triggerPrice: number;
  stopLoss: number;
  targets: number[];
  rR: number[];
  invalidationReason: string;
  allowReasons: string[];
  refuseReasons: string[];
  nextMajorNews: MacroEvent | null;
}

// ─── Scenarios ──────────────────────────────────────────────────

export interface Scenario {
  name: string;
  probability: number;
  direction: Direction;
  trigger: string;
  entry: [number, number];
  invalidation: number;
  targets: number[];
  rR: number[];
  note: string;
}

// ─── Macro / News / Geo ─────────────────────────────────────────

export interface MacroEvent {
  time: number;
  name: string;
  impact: 'low' | 'medium' | 'high';
  consensus: string;
  actual: string | null;
  currency: string;
  minutesUntil: number;
  country: string;
  previous: string | null;
  available: boolean;
}

export interface NewsItem {
  id: string;
  time: number;
  publishedAt: number;
  receivedAt: number;
  headline: string;
  source: string;
  sourceLevel: 1 | 2 | 3;
  novelty: number;
  marketImpact: number;
  direction: Direction;
  entities: string[];
  category: string;
  url: string | null;
  available: boolean;
}

export interface GeoEvent {
  eventType: string;
  actors: string[];
  location: string;
  timestamp: number;
  source: string;
  confirmationLevel: number;
  severity: number;
  escalationProbability: number;
  safeHavenImpact: number;
  credibility: number;
  grossImpact: 'bullish' | 'bearish' | 'neutral';
  netImpact: 'bullish' | 'bearish' | 'neutral';
  score: number;
  available: boolean;
}

// ─── Correlations / Options ─────────────────────────────────────

export interface CorrelationState {
  dxy: number;
  realYields10y: number;
  nominal10y: number;
  sp500: number;
  silver: number;
  vix: number;
  regimeNote: string;
  broken: boolean;
  available: boolean;
  rollingCorr: RollingCorrelation[];
}

export interface RollingCorrelation {
  asset: string;
  window: number;
  correlation: number;
  change: number;
  zScore: number;
  divergence: boolean;
  regimeBreak: boolean;
  available: boolean;
}

export interface OptionsState {
  ivATM: number;
  skew: 'bullish' | 'bearish' | 'neutral';
  skewChange24h: number;
  skewPercentile: number;
  pinning: number[];
  walls: number[];
  gamma: number;
  note: string;
  available: boolean;
}

// ─── Trade plan ─────────────────────────────────────────────────

export interface TradePlan {
  status: SetupStatus;
  direction: Direction;
  confidence: number;
  regime: Regime;
  regimeLabel: string;
  horizon: string;
  zone: [number, number];
  trigger: string;
  entry: [number, number];
  stop: number;
  targets: number[];
  rR: number[];
  macro: string;
  geopolitical: string;
  orderFlow: string;
  liquidity: string;
  invalidation: string;
  nextNews: string;
  action: string;
  decisionTree: string[];
  conflicts: string[];
  ev: number;
  scenarios: Scenario[];
  agents: AgentSignal[];
  timestamp: number;
  setupId: string | null;
  setupSteps: SetupStep[];
  allowReasons: string[];
  refuseReasons: string[];
  poiType: string;
  preferredEntry: number;
  triggerPrice: number;
}

export interface AlertItem {
  id: string;
  time: number;
  type: 'context' | 'setup' | 'trigger' | 'validated' | 'invalidated' | 'news' | 'risk' | 'protect' | 'model' | 'feed';
  message: string;
  severity: 'info' | 'warning' | 'critical';
}

export interface JournalEntry {
  id: string;
  time: number;
  direction: Direction;
  status: string;
  confidence: number;
  regime: string;
  entry: number;
  stop: number;
  targets: number[];
  outcome: 'pending' | 'win' | 'loss' | 'void' | 'tp1' | 'tp2' | 'tp3' | 'sl' | 'breakeven' | 'expired' | 'invalidated';
  reasoning: string;
  conflicts: string[];
  ev: number;
  setupId: string | null;
  mfe: number | null;
  mae: number | null;
  rRealized: number | null;
}

// ─── Structure state ────────────────────────────────────────────

export interface StructureState {
  bias: StructureBias;
  swings: SwingPoint[];
  lastEvent: StructureEvent | null;
  events: StructureEvent[];
  fvgs: FVG[];
  ifvgs: IFVG[];
  orderBlocks: OrderBlock[];
  breakers: BreakerBlock[];
  mitigationBlocks: MitigationBlock[];
  bprs: BPR[];
  dealingRange: DealingRange | null;
  premium: boolean;
  discount: boolean;
  liquidity: LiquidityPool[];
  noise: number;
  displacement: DisplacementInfo | null;
}

// ─── Market snapshot ────────────────────────────────────────────

export interface MarketSnapshot {
  time: number;
  price: PriceState;
  candles: Record<Timeframe, Candle[]>;
  regime: Regime;
  regimeLabel: string;
  structure: Record<Timeframe, StructureState>;
  microstructure: MicrostructureState;
  volumeProfile: VolumeProfile;
  vwap: VWAPSet;
  correlations: CorrelationState;
  options: OptionsState;
  macro: MacroEvent[];
  news: NewsItem[];
  geo: GeoEvent[];
  liquidities: LiquidityPool[];
  scenarios: Scenario[];
  agents: AgentSignal[];
  plan: TradePlan;
  alerts: AlertItem[];
  quality: QualityReport;
  sessions: SessionInfo;
  setup: SetupState | null;
}
