import { useState, useEffect, useRef } from 'react';
import { MarketSnapshot, Timeframe, Candle, Tick as EngineTick, EngineMode } from '@/engine/types';
import { simulateMarket, quotesFromTicks, computePriceState, createFeedState } from '@/engine/market';
import { runPipeline, createPipelineState } from '@/engine/pipeline';
import { Dashboard } from '@/components/Dashboard';
import { recordSignal, recordSnapshot } from '@/lib/journal';
import { fetchLatestQuote, fetchTickHistory, quoteToPriceState, fetchFeedStatus } from '@/lib/feed';

const TIMEFRAMES: Timeframe[] = ['M1', 'M5', 'M15', 'H1', 'H4', 'D', 'W'];
const TF_MIN: Record<Timeframe, number> = { M1: 1, M5: 5, M15: 15, H1: 60, H4: 240, D: 1440, W: 10080 };

interface SimTick { time: number; price: number; volume: number; buyVolume: number; sellVolume: number; }

function aggregateCandles(ticks: SimTick[], tf: Timeframe): Candle[] {
  const bucketMs = TF_MIN[tf] * 60 * 1000;
  const map = new Map<number, Candle>();
  for (const t of ticks) {
    const bucket = Math.floor(t.time / bucketMs) * bucketMs;
    let c = map.get(bucket);
    if (!c) {
      c = { time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: 0, buyVolume: 0, sellVolume: 0, hasRealVolume: false };
      map.set(bucket, c);
    }
    c.close = t.price;
    c.high = Math.max(c.high, t.price);
    c.low = Math.min(c.low, t.price);
    c.volume += t.volume;
    c.buyVolume += t.buyVolume;
    c.sellVolume += t.sellVolume;
  }
  return Array.from(map.values()).sort((a, b) => a.time - b.time);
}

function ticksFromFeed(feedTicks: EngineTick[]): SimTick[] {
  return feedTicks.map((t) => ({
    time: t.time,
    price: t.mid,
    volume: t.volume,
    buyVolume: t.buyVolume ?? 0,
    sellVolume: t.sellVolume ?? 0,
  }));
}

export function useLiveEngine() {
  const [snapshot, setSnapshot] = useState<MarketSnapshot | null>(null);
  const ticksRef = useRef<SimTick[]>([]);
  const momentumRef = useRef(0);
  const stepRef = useRef(0);
  const lastRecordRef = useRef<string>('');
  const lastRecordTimeRef = useRef(0);
  const lastSnapshotTimeRef = useRef(0);
  const pipelineStateRef = useRef(createPipelineState('PRODUCTION' as EngineMode));
  const feedRef = useRef(createFeedState('PRODUCTION' as EngineMode, 'MT5_BRIDGE', 'XAUUSD', 5000));
  const modeRef = useRef<'PRODUCTION' | 'DEMO'>('PRODUCTION');
  const lastSetupIdRef = useRef<string | null>(null);

  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    let mounted = true;

    async function init() {
      // Check if real feed is available
      const status = await fetchFeedStatus();
      if (!mounted) return;

      if (status.ready) {
        modeRef.current = 'PRODUCTION';
        pipelineStateRef.current = createPipelineState('PRODUCTION' as EngineMode);
        feedRef.current = createFeedState('PRODUCTION' as EngineMode, 'MT5_BRIDGE', 'XAUUSD', 5000);

        // Load historical ticks from database
        const history = await fetchTickHistory(2000);
        if (!mounted) return;
        if (history.length > 0) {
          ticksRef.current = ticksFromFeed(history);
        }
      } else {
        // Fallback to DEMO simulation
        modeRef.current = 'DEMO';
        pipelineStateRef.current = createPipelineState('DEMO' as EngineMode);
        feedRef.current = createFeedState('DEMO' as EngineMode, 'DEMO_SIM', 'XAUUSD', 5000);

        const now = Date.now();
        const sim = simulateMarket({
          startTime: now - 3 * 24 * 60 * 60 * 1000,
          ticksPerMinute: 20,
          durationMinutes: 3 * 24 * 60,
          basePrice: 2650,
          seed: 42,
        });
        ticksRef.current = [...sim.ticks];
        momentumRef.current = 0;
        stepRef.current = 0;
      }

      startLoop();
    }

    function compute() {
      const ticks = ticksRef.current;
      if (ticks.length === 0) return;
      const lastTick = ticks[ticks.length - 1];
      const quotes = quotesFromTicks(lastTick.price, lastTick.time, Math.random);
      const priceState = computePriceState(quotes, feedRef.current, lastTick.time);
      const candles = {} as Record<Timeframe, Candle[]>;
      for (const tf of TIMEFRAMES) candles[tf] = aggregateCandles(ticks, tf);
      const snap = runPipeline(candles, priceState, lastTick.time, pipelineStateRef.current);
      setSnapshot(snap);

      // Record signal to journal only when a NEW setup reaches EXECUTE (1 setup = 1 row)
      const setupId = snap.setup?.setupId ?? null;
      const isExecute = snap.plan.status === 'EXECUTE';

      if (isExecute && setupId && setupId !== lastSetupIdRef.current) {
        lastSetupIdRef.current = setupId;
        recordSignal(snap, setupId);
      }

      // Record 60s snapshots for active setups
      const nowMs = Date.now();
      if (setupId && snap.setup && nowMs - lastSnapshotTimeRef.current > 60000) {
        lastSnapshotTimeRef.current = nowMs;
        recordSnapshot(snap, setupId);
      }
    }

    function startLoop() {
      compute();

      if (modeRef.current === 'PRODUCTION') {
        // Poll the edge function every 3 seconds for real ticks
        interval = setInterval(async () => {
          const quote = await fetchLatestQuote();
          if (!mounted) return;
          if (quote.status === 'CONNECTED' && quote.last != null) {
            ticksRef.current.push({
              time: quote.timestamp,
              price: quote.last,
              volume: 0,
              buyVolume: 0,
              sellVolume: 0,
            });
            // Keep memory bounded
            if (ticksRef.current.length > 50000) {
              ticksRef.current = ticksRef.current.slice(-30000);
            }
          }
          compute();
        }, 3000);
      } else {
        // DEMO mode: continue simulated random walk
        const tickIntervalMs = 3000;
        const lastSimTick = ticksRef.current[ticksRef.current.length - 1];
        let price = lastSimTick?.price ?? 2650;

        interval = setInterval(() => {
          const regimes = [
            { vol: 0.35, drift: 0.0008 },
            { vol: 0.55, drift: -0.0012 },
            { vol: 0.7, drift: 0.0022 },
            { vol: 0.4, drift: 0.0005 },
          ];
          const regime = regimes[stepRef.current % regimes.length];
          const shock = (Math.random() - 0.5) * 2 * regime.vol;
          momentumRef.current = Math.max(-1.2, Math.min(1.2, momentumRef.current * 0.82 + shock * 0.35 + regime.drift));
          price += momentumRef.current;

          if (Math.random() < 0.004) price += (Math.random() - 0.5) * 4 * regime.vol;

          const buyBias = momentumRef.current > 0
            ? 0.55 + Math.abs(momentumRef.current) * 0.1
            : 0.45 - Math.abs(momentumRef.current) * 0.05;
          const vol = Math.max(0.5, 1 + Math.abs(momentumRef.current) * 3 + Math.random() * 2);
          const buy = vol * Math.min(0.85, Math.max(0.15, buyBias + (Math.random() - 0.5) * 0.2));

          const last = ticksRef.current[ticksRef.current.length - 1];
          ticksRef.current.push({
            time: (last?.time ?? Date.now()) + tickIntervalMs,
            price: Math.round(price * 100) / 100,
            volume: vol,
            buyVolume: buy,
            sellVolume: vol - buy,
          });

          if (ticksRef.current.length > 200000) {
            ticksRef.current = ticksRef.current.slice(-100000);
          }

          stepRef.current++;
          compute();
        }, tickIntervalMs);
      }
    }

    init();

    return () => {
      mounted = false;
      if (interval) clearInterval(interval);
    };
  }, []);

  return snapshot;
}

export default function App() {
  const snapshot = useLiveEngine();
  return <Dashboard snapshot={snapshot} />;
}
