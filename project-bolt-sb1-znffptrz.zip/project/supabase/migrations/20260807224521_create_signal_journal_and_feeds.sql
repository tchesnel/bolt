/*
# Create signal journal, snapshots, and price tick tables

## Purpose
This migration creates three tables that form the data backbone of the
XAU/USD quantitative analysis engine:

1. `signal_journal` — one immutable row per setup prediction. Written ONCE
   when a setup reaches EXECUTE. Never updated by the frontend; outcome
   columns are filled by the server-side outcome engine only.
2. `signal_snapshots` — periodic snapshots (every 60s) of an active setup's
   state, so we can track how a setup evolves without duplicating journal
   rows. Linked to the journal via `setup_id`.
3. `price_ticks` — real XAU/USD tick data streamed from the MT5 bridge edge
   function. The frontend reads recent ticks to build live candles.

## New Tables

### signal_journal
- `id` (uuid, primary key)
- `setup_id` (text, unique — the engine's internal setup identifier, so
  each setup maps to exactly one immutable prediction row)
- `created_at` (timestamptz, when the signal was generated)
- `direction` (text: BUY, SELL, or NEUTRAL)
- `status` (text: WAIT, READY, EXECUTE, NO_TRADE, MONITOR)
- `confidence` (numeric 0-1)
- `regime` (text, market regime label)
- `entry_price` (numeric, planned entry midpoint)
- `stop_price` (numeric, stop-loss level)
- `tp1`, `tp2`, `tp3` (numeric, take-profit targets)
- `rr1`, `rr2`, `rr3` (numeric, risk-reward ratios)
- `ev` (numeric, expected value in R multiples)
- `regime_label` (text, human-readable regime)
- `scenario_main_prob`, `scenario_alt_prob`, `scenario_neutral_prob` (numeric 0-1)
- `conflicts` (text[])
- `decision_tree` (text[])
- `agent_raws` (jsonb)
- `agent_weights` (jsonb)
- `microstructure_ofi` (numeric)
- `microstructure_cvd` (numeric)
- `microstructure_divergence` (text)
- `has_absorption` (boolean)
- `has_sweep` (boolean)
- `has_exhaustion` (boolean)
- `structure_h1_bias` (text)
- `structure_d_bias` (text)
- `premium_discount` (text)
- `next_news_minutes` (integer)
- `outcome` (text, default 'pending' — filled by outcome engine only)
- `outcome_time` (timestamptz)
- `outcome_price` (numeric)
- `mfe` (numeric, max favorable excursion)
- `mae` (numeric, max adverse excursion)
- `r_realized` (numeric, realized R multiple)

### signal_snapshots
- `id` (uuid, primary key)
- `setup_id` (text, references signal_journal.setup_id)
- `created_at` (timestamptz)
- `status` (text, current setup status)
- `current_stage` (text, current setup stage)
- `price` (numeric, current price at snapshot time)
- `mfe` (numeric, running MFE)
- `mae` (numeric, running MAE)
- `metadata` (jsonb, arbitrary snapshot data)

### price_ticks
- `id` (bigint, generated identity primary key)
- `created_at` (timestamptz)
- `bid` (numeric)
- `ask` (numeric)
- `last` (numeric)
- `spread` (numeric)
- `provider` (text, e.g. 'FP_MARKETS', 'MT5_BRIDGE')
- `quality` (integer 0-100)

## Security
- Enable RLS on ALL three tables.
- `signal_journal`: anon/authenticated can SELECT and INSERT only.
  UPDATE and DELETE are denied to anon/authenticated — only the service
  role (server-side outcome engine) can modify or delete rows.
- `signal_snapshots`: anon/authenticated can SELECT and INSERT only.
  No UPDATE or DELETE for anon/authenticated.
- `price_ticks`: anon/authenticated can SELECT and INSERT only.
  No UPDATE or DELETE for anon/authenticated.

This prevents a frontend client from modifying or deleting the learning
history. Only the server-side outcome engine (using the service role key)
can update outcome columns.

## Important Notes
1. `signal_journal.setup_id` has a UNIQUE constraint — inserting a duplicate
   setup_id will fail, enforcing 1 setup = 1 immutable prediction.
2. The frontend writes snapshots every 60s to `signal_snapshots`, not
   duplicate journal rows.
3. `price_ticks` is append-only — the MT5 bridge edge function inserts ticks,
   the frontend reads them.
*/

-- ─── signal_journal ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signal_journal (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setup_id text UNIQUE,
  created_at timestamptz DEFAULT now(),
  direction text NOT NULL,
  status text NOT NULL,
  confidence numeric(5,4) NOT NULL,
  regime text NOT NULL,
  entry_price numeric(12,4),
  stop_price numeric(12,4),
  tp1 numeric(12,4),
  tp2 numeric(12,4),
  tp3 numeric(12,4),
  rr1 numeric(5,2),
  rr2 numeric(5,2),
  rr3 numeric(5,2),
  ev numeric(8,4),
  regime_label text,
  scenario_main_prob numeric(5,4),
  scenario_alt_prob numeric(5,4),
  scenario_neutral_prob numeric(5,4),
  conflicts text[] DEFAULT '{}',
  decision_tree text[] DEFAULT '{}',
  agent_raws jsonb DEFAULT '{}',
  agent_weights jsonb DEFAULT '{}',
  microstructure_ofi numeric(8,4),
  microstructure_cvd numeric(12,2),
  microstructure_divergence text,
  has_absorption boolean DEFAULT false,
  has_sweep boolean DEFAULT false,
  has_exhaustion boolean DEFAULT false,
  structure_h1_bias text,
  structure_d_bias text,
  premium_discount text,
  next_news_minutes integer,
  outcome text NOT NULL DEFAULT 'pending',
  outcome_time timestamptz,
  outcome_price numeric(12,4),
  mfe numeric(12,4),
  mae numeric(12,4),
  r_realized numeric(8,4)
);

ALTER TABLE signal_journal ENABLE ROW LEVEL SECURITY;

-- anon/authenticated can SELECT (read the journal for display)
DROP POLICY IF EXISTS "anon_select_signals" ON signal_journal;
CREATE POLICY "anon_select_signals" ON signal_journal FOR SELECT
  TO anon, authenticated USING (true);

-- anon/authenticated can INSERT (create new signal predictions)
DROP POLICY IF EXISTS "anon_insert_signals" ON signal_journal;
CREATE POLICY "anon_insert_signals" ON signal_journal FOR INSERT
  TO anon, authenticated WITH CHECK (true);

-- NO UPDATE or DELETE policies for anon/authenticated.
-- Only the service role (server-side) can update outcomes or delete.

CREATE INDEX IF NOT EXISTS idx_signal_journal_created ON signal_journal (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_signal_journal_outcome ON signal_journal (outcome);
CREATE INDEX IF NOT EXISTS idx_signal_journal_direction ON signal_journal (direction);
CREATE INDEX IF NOT EXISTS idx_signal_journal_setup_id ON signal_journal (setup_id);

-- ─── signal_snapshots ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS signal_snapshots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setup_id text,
  created_at timestamptz DEFAULT now(),
  status text,
  current_stage text,
  price numeric(12,4),
  mfe numeric(12,4),
  mae numeric(12,4),
  metadata jsonb DEFAULT '{}'
);

ALTER TABLE signal_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_snapshots" ON signal_snapshots;
CREATE POLICY "anon_select_snapshots" ON signal_snapshots FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_snapshots" ON signal_snapshots;
CREATE POLICY "anon_insert_snapshots" ON signal_snapshots FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_signal_snapshots_setup_id ON signal_snapshots (setup_id);
CREATE INDEX IF NOT EXISTS idx_signal_snapshots_created ON signal_snapshots (created_at DESC);

-- ─── price_ticks ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS price_ticks (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  bid numeric(12,4) NOT NULL,
  ask numeric(12,4) NOT NULL,
  last numeric(12,4) NOT NULL,
  spread numeric(10,4) NOT NULL,
  provider text NOT NULL DEFAULT 'MT5_BRIDGE',
  quality integer NOT NULL DEFAULT 100
);

ALTER TABLE price_ticks ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_ticks" ON price_ticks;
CREATE POLICY "anon_select_ticks" ON price_ticks FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_ticks" ON price_ticks;
CREATE POLICY "anon_insert_ticks" ON price_ticks FOR INSERT
  TO anon, authenticated WITH CHECK (true);

CREATE INDEX IF NOT EXISTS idx_price_ticks_created ON price_ticks (created_at DESC);
