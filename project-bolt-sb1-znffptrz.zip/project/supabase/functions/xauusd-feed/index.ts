import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface MT5Quote {
  bid: number;
  ask: number;
  last: number;
  timestamp: number;
}

interface BridgeConfig {
  bridgeUrl: string;
  symbol: string;
}

function getConfig(): BridgeConfig | null {
  const bridgeUrl = Deno.env.get("MT5_BRIDGE_URL");
  if (!bridgeUrl) return null;
  return {
    bridgeUrl,
    symbol: Deno.env.get("MT5_SYMBOL") || "XAUUSD",
  };
}

async function fetchFromBridge(config: BridgeConfig): Promise<MT5Quote | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(`${config.bridgeUrl}/quote?symbol=${config.symbol}`, {
      signal: controller.signal,
      headers: { "Accept": "application/json" },
    });
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (typeof data.bid !== "number" || typeof data.ask !== "number") return null;
    return {
      bid: data.bid,
      ask: data.ask,
      last: data.last ?? (data.bid + data.ask) / 2,
      timestamp: data.timestamp ?? Date.now(),
    };
  } catch {
    return null;
  }
}

async function fetchFromFallback(): Promise<MT5Quote | null> {
  // Fallback: Twelve Data API (free tier, no key needed for basic quotes)
  const apiKey = Deno.env.get("TWELVE_DATA_API_KEY");
  if (!apiKey) return null;
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const resp = await fetch(
      `https://api.twelvedata.com/price?symbol=XAU/USD&apikey=${apiKey}`,
      { signal: controller.signal },
    );
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data = await resp.json();
    if (data.status === "error" || !data.price) return null;
    const price = parseFloat(data.price);
    if (isNaN(price)) return null;
    // Simulate realistic spread (0.15-0.35 USD for XAU/USD)
    const spread = 0.15 + Math.random() * 0.20;
    return {
      bid: price - spread / 2,
      ask: price + spread / 2,
      last: price,
      timestamp: Date.now(),
    };
  } catch {
    return null;
  }
}

async function storeTick(supabase: any, quote: MT5Quote, provider: string, quality: number) {
  const { error } = await supabase
    .from("price_ticks")
    .insert({
      bid: quote.bid,
      ask: quote.ask,
      last: quote.last,
      spread: quote.ask - quote.bid,
      provider,
      quality,
    });
  if (error) console.error("Failed to store tick:", error.message);
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const url = new URL(req.url);
    const action = url.searchParams.get("action") || "quote";
    const limit = parseInt(url.searchParams.get("limit") || "1");

    // ─── GET /quote — fetch latest tick from bridge or fallback ───
    if (action === "quote" || action === "latest") {
      const config = getConfig();
      let quote: MT5Quote | null = null;
      let provider = "UNKNOWN";
      let quality = 0;

      if (config) {
        quote = await fetchFromBridge(config);
        if (quote) {
          provider = "MT5_BRIDGE";
          quality = 100;
        }
      }

      if (!quote) {
        quote = await fetchFromFallback();
        if (quote) {
          provider = "TWELVE_DATA";
          quality = 60;
        }
      }

      if (!quote) {
        return new Response(
          JSON.stringify({
            status: "DISCONNECTED",
            message: "No price feed available. Configure MT5_BRIDGE_URL or TWELVE_DATA_API_KEY.",
            bid: null,
            ask: null,
            last: null,
            spread: null,
            provider: null,
            quality: 0,
            timestamp: Date.now(),
          }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      // Store tick in database
      await storeTick(supabase, quote, provider, quality);

      return new Response(
        JSON.stringify({
          status: "CONNECTED",
          bid: quote.bid,
          ask: quote.ask,
          last: quote.last,
          spread: quote.ask - quote.bid,
          provider,
          quality,
          timestamp: quote.timestamp,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── GET /history — fetch recent ticks from database ───
    if (action === "history") {
      const { data, error } = await supabase
        .from("price_ticks")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(Math.min(limit, 5000));

      if (error) {
        return new Response(
          JSON.stringify({ error: error.message }),
          { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }

      return new Response(
        JSON.stringify({
          status: "CONNECTED",
          ticks: (data || []).reverse().map((t: any) => ({
            time: new Date(t.created_at).getTime(),
            bid: parseFloat(t.bid),
            ask: parseFloat(t.ask),
            last: parseFloat(t.last),
            spread: parseFloat(t.spread),
            provider: t.provider,
            quality: t.quality,
          })),
          count: data?.length || 0,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // ─── GET /status — check feed connectivity ───
    if (action === "status") {
      const config = getConfig();
      const hasFallback = !!Deno.env.get("TWELVE_DATA_API_KEY");
      return new Response(
        JSON.stringify({
          mt5Bridge: !!config,
          twelveData: hasFallback,
          symbol: config?.symbol || "XAUUSD",
          ready: !!config || hasFallback,
        }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    return new Response(
      JSON.stringify({ error: "Unknown action. Use ?action=quote|history|status" }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
